#include "JustPlay.h"

CJustPlay::CJustPlay()
{
	SetTypeID<CJustPlay>();
}

CJustPlay::CJustPlay(const CJustPlay& Obj) :
	CEffect(Obj)
{
}

CJustPlay::~CJustPlay()
{
}

bool CJustPlay::Init(CGameObject* Obj)
{
	CEffect::Init(Obj);

	if (!m_Animation->FindAnimInfo(m_Name))
		return false;

	SetAnimation(m_Name);

	//Ʈ���� ����Ʈ�� ������ ���̾�� default
	m_RenderLayer = ERenderLayer::Default;

	return true;
}


bool CJustPlay::LoadResource()
{
	if (!LoadCSVPreset(TEXT("SFX/RocketLauncherTrail.csv")))
		return false;

	if (!LoadCSVPreset(TEXT("SFX/AstroTailSFX.csv")))
		return false;

	if (!LoadCSVPreset(TEXT("UI/Interface.csv")))
		return false;

	return true;
}