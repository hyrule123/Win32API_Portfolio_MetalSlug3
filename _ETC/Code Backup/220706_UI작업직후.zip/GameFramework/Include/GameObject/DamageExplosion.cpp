#include "DamageExplosion.h"

#include "../Collision/ColliderCircle.h"

#include "../Scene/Scene.h"


CDamageExplosion::CDamageExplosion():
	m_Damage(),
	m_CurrentSize(),
	m_Coll()
{
	SetTypeID<CDamageExplosion>();
}

CDamageExplosion::CDamageExplosion(const CDamageExplosion& Obj):
	CExplosion(Obj),
	m_Damage(Obj.m_Damage),
	m_CurrentSize(Obj.m_CurrentSize)
{
	for (int i = 0; i < (int)EExplosionSize::Max; ++i)
	{
		m_SizeName[i] = Obj.m_SizeName[i];
	}

	if (Obj.m_Coll)
	{
		m_Coll = AddCollider<CColliderCircle>("ExplosionCollider");
		
		//���� ����
		*m_Coll = *Obj.m_Coll;
	}
}

CDamageExplosion::~CDamageExplosion()
{
}


bool CDamageExplosion::Init(CGameObject* Obj)
{
	CExplosion::Init(Obj);

	SetDir(0.f, -1.f);
	SetMaxSpeed(10.f);


	//2������ ��Ƽ���� ����
	AddNotify<CDamageExplosion>(m_Name, 2, this, &CDamageExplosion::Frame2Notify);


	//�浹ü ����
	m_Coll = AddCollider<CColliderCircle>("ExplosionColl");
	m_Coll->SetCollisionProfile(ECollisionChannel::PlayerAttack);

	if (m_Name == m_SizeName[(int)EExplosionSize::Small])
	{
		m_CurrentSize = EExplosionSize::Small;

		m_Coll->SetOffset(0.f, -17.f);
		m_Coll->SetRadius(17.f);
	}

	else if (m_Name == m_SizeName[(int)EExplosionSize::Midium])
	{
		m_CurrentSize = EExplosionSize::Midium;

		m_Coll->SetOffset(0.f, -25.f);
		m_Coll->SetRadius(25.f);

		m_Pos += m_Dir * 10.f;

	}
	else if (m_Name == m_SizeName[(int)EExplosionSize::Big])
	{
		m_CurrentSize = EExplosionSize::Big;

		m_Coll->SetOffset(0.f, -40.f);
		m_Coll->SetRadius(40.f);

		m_Pos += m_Dir * 20.f;

	}


	return true;
}

void CDamageExplosion::Update(float DeltaTime)
{
	CExplosion::Update(DeltaTime);

	AddForce(10.f);
}


void CDamageExplosion::SetEssential(const Vector2& Pos, int Damage)
{

	m_Pos = Pos;

	m_Damage = Damage;

	m_isReady = true;
}

void CDamageExplosion::CollisionBegin(CCollider* Src, CCollider* Dest)
{
	Dest->GetOwnerObj()->InflictDamage(m_Damage);
}

void CDamageExplosion::Frame2Notify()
{
	//�ڽ��� �浹ü ����
	ClearCollider();
}
