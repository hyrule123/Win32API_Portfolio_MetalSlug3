#pragma once
#include "Enemy.h"

class CUFO :
    public CEnemy
{
	friend class CScene;

protected:
	CUFO();
	CUFO(const CUFO& Obj);
	virtual ~CUFO();
public:
	virtual bool LoadResource();
	virtual bool Init(CGameObject* Obj = nullptr);


public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	int InflictDamage(int Damage);

protected:
	void CollBeginMouse(const Vector2& Point, class CCollider* Col);
};

