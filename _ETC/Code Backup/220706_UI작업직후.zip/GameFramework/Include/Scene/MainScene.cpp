#include "MainScene.h"
#include "../Input.h"

//����ϴ� ���ӿ�����Ʈ
#include "../GameObject/AstroSlug.h"
#include "../GameObject/AstroSlugSFX.h"
#include "../GameObject/PlayerSpace.h"
#include "../GameObject/Explosion.h"
#include "../GameObject/Enemy.h"
#include "../GameObject/UFO.h"
#include "../GameObject/BackgroundSpace.h"
#include "../GameObject/PistolHit.h"
#include "../GameObject/Shotgun.h"
#include "../GameObject/AstroBomb.h"
#include "../GameObject/Pistol.h"
#include "../GameObject/RocketLauncher.h"
#include "../GameObject/Laser.h"
#include "../GameObject/AstroHMG.h"
#include "../GameObject/PlayerHMG.h"
#include "../GameObject/SpaceIntro.h"
#include "../GameObject/JustPlay.h"


//����ϴ� UI
#include "../UI/WindowSpace.h"
#include "../UI/WidgetFadeInOut.h"

#include "SceneResource.h"

//Camera ó��
#include "Camera.h"

//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"


CMainScene::CMainScene()
{
}

CMainScene::~CMainScene()
{
}

bool CMainScene::Init()
{
	CScene::Init();

	//ī�޶� �غ�
	GetCamera()->SetRes((float)ORIGINAL_GAME_RES_WIDTH, 
		(float)ORIGINAL_GAME_RES_HEIGHT);
	GetCamera()->SetWorldRes(ORIGINAL_GAME_RES_WIDTH, 
		ORIGINAL_GAME_RES_HEIGHT * 2.f);
	GetCamera()->SetTargetPivot(0.5f, 0.8f);

	//����
	CWindowSpace* WindowSpace = CreateWidgetWindow<CWindowSpace>("WindowSpace");



	//��׶��� 
	m_BackGround = CreateObject<CBackgroundSpace>("BackGround");
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontSilver.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontGold.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/TimeNumber.csv"));


	//���� ���
	GetSceneResource()->LoadSound("SFX", "MainTheme", true, "MS3_Into_The_Cosmos.mp3");
	
	//���ҽ� �̸� �ε�
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontSilver.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontGold.csv"));
	m_SceneResource->LoadTexture("AmmoHUD", TEXT("UI/AmmoHUD.bmp"));
	m_SceneResource->SetColorKey("AmmoHUD");


	CreateOriginalObj<CPlayerSpace>("PlayerSpace");
	CreateOriginalObj<CAstroSlug>("AstroSlug");
	CreateOriginalObj<CAstroSlugSFX>("AstroSlugSFX");
	CreateOriginalObj<CExplosion>("Explosion");
	CreateOriginalObj<CPistolHit>("PistolHit");
	CreateOriginalObj<CShotgun>("Shotgun");
	CreateOriginalObj<CPistol>("Pistol");
	CreateOriginalObj<CRocketLauncher>("RocketLauncher");
	CreateOriginalObj<CAstroBomb>("AstroBomb");
	CreateOriginalObj<CLaser>("Laser");
	CreateOriginalObj<CPlayerHMG>("PlayerHMG");
	CreateOriginalObj<CAstroHMG>("AstroHMG");
	CreateOriginalObj<CUFO>("UFO");
	CreateOriginalObj<CSpaceIntro>("SpaceIntro");
	CreateOriginalObj<CJustPlay>("JustPlay");

	CreateObject<CSpaceIntro>("SpaceIntro");












	//CreateObject<CUFO>("UFO");
	//CAstroSlug* Player = CreateObject<CAstroSlug>("AstroSlug");
	////CPlayerSpace* Player = CreateObject<CPlayerSpace>("PlayerSpace");

	////GetCamera()->SetTargetObj(Player);
	//Player->SetPhysicsSimulate(false);
	//Player->SetPos(100.f, 100.f);



	////���� ����
	//CEnemy* Enemy = CreateObject<CEnemy>("Enemy");
	//Enemy->SetPos(200.f, 200.f);
	
	////CreateWidgetWindow<CWindowEnemyHP>("EnemyHPBarWindow");


	



	return true;
}


void CMainScene::SetScrollMapSpeed(float Speed)
{
	if(m_BackGround)
		m_BackGround->SetSpeed(Speed);
}

void CMainScene::SetScrollMapSpeedSoft(float AdjustSpeed, float SpeedPerSec)
{
	if (m_BackGround)
		m_BackGround->SetSpeedSoft(AdjustSpeed, SpeedPerSec);
}




