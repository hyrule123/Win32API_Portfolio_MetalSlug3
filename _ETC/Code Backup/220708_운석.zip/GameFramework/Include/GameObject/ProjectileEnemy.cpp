#include "ProjectileEnemy.h"

#include "../GameManager.h"

#include "../Collision/ColliderBox.h"


CProjectileEnemy::CProjectileEnemy():
	m_ProjectileType(),
	m_vecProjectileName{},
	m_Coll()
{
	SetTypeID<CProjectileEnemy>();
}

CProjectileEnemy::CProjectileEnemy(const CProjectileEnemy& Obj) :
	CProjectile(Obj),
	m_ProjectileType(Obj.m_ProjectileType),
	m_Coll()
{
	int size = (int)EProjectileEnemy::End;
	for (int i = 0; i < size; ++i)
	{
		m_vecProjectileName[i] = Obj.m_vecProjectileName[i];
	}
}

CProjectileEnemy::~CProjectileEnemy()
{
}

bool CProjectileEnemy::LoadResource()
{
	if (!LoadCSVPreset(TEXT("Enemy/UFOProjectile.csv")))
		return false;


	m_vecProjectileName[(int)EProjectileEnemy::UFOLaser] = "UFO_Projectile";

	return true;
}

bool CProjectileEnemy::Init(CGameObject* Obj)
{
	CProjectile::Init(Obj);
	
	//���ʿ��� �����ǹǷ� ���� ���ش�.
	SetCullingDelete(ECullingDelete::Top, false);



	return true;
}

void CProjectileEnemy::Start()
{
	m_Start = true;
	if (m_Coll)
		m_Coll->SetCollisionProfile(ECollisionChannel::EnemyAttack);
}

void CProjectileEnemy::Update(float DeltaTime)
{
	CProjectile::Update(DeltaTime);

	switch (m_ProjectileType)
	{
	case EProjectileEnemy::UFOLaser:
	{
		//�ִϸ��̼� ����� ����� ������ �����°��� ����
		Vector2 Size = m_Animation->GetAnimSize();
		if(Size.y > 30.f)
			m_Coll->SetOffset(0.f, Size.y);

	}
		break;
	}

}

void CProjectileEnemy::PostUpdate(float DeltaTime)
{
	CProjectile::PostUpdate(DeltaTime);
}

void CProjectileEnemy::Render(HDC hDC, float DeltaTime)
{
	CProjectile::Render(hDC, DeltaTime);
}

void CProjectileEnemy::SetEssential(EProjectileEnemy Type, Vector2 Dir, Vector2 Pos)
{
	m_ProjectileType = Type;
	m_Dir = Dir;
	m_Pos = Pos;

	SetAnimation(m_vecProjectileName[(int)m_ProjectileType]);

	//Ÿ�Ժ� ���� ����
	switch (m_ProjectileType)
	{
	case EProjectileEnemy::UFOLaser:
	{
		SetMaxSpeed(300.f);

		m_Coll = AddCollider<CColliderBox>("UFOLaserColl");
		m_Coll->SetPivot(0.5f, 0.3f);
		m_Coll->SetSize(4.f, 20.f);
		m_Coll->SetCollisionBeginFunc< CProjectileEnemy>(this, &CProjectileEnemy::CollisionBegin);
		//m_MyAnimation = m_Animation->FindAnimInfo(m_vecProjectileName[(int)m_ProjectileType])->

	}
		break;
	}


	m_isReady = true;
}



void CProjectileEnemy::CollisionBegin(CCollider* Src, CCollider* Dest)
{
	Dest->GetOwnerObj()->InflictDamage(1);
}


