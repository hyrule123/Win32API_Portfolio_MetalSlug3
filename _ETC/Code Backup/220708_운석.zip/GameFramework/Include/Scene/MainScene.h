#pragma once

#include "Scene.h"

enum ESpacePhase
{
    ESPhase0,
    ESPhase1_Wait,
    ESPhase2_Wait,
    ESPhase3_Wait,
    ESPhase4_UFOSpawn1,
    ESPhase5_UFOPhase2,
    ESPhase6_1_Wait,
    ESPhase7_Meteor
};


class CMainScene :
    public CScene
{
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();
public:
	virtual bool Init();
    virtual void Update(float DeltaTime);
    virtual void PostUpdate(float DeltaTime);
    virtual void Render(HDC hDC, float DeltaTime);

protected:
    class CBackgroundSpace* m_BackGround;


private://Phase ���� ���� �޼ҵ� ����
    UINT8 m_PhaseFlags;
    CooltimeChecker m_Timer0;
    CooltimeChecker m_Timer1;
    CooltimeChecker m_Timer2;

    INT16 m_Counter;
    INT16 m_KeyMonsterCounter;
    bool m_FirstPhaseEnter;
public:
    void GotoNextPhase();//���� ������ ���Խ� �ݵ�� �� �Լ��� ���� �����Ұ�
    bool CheckFirstEnter();  //���̽� ù���� Ȯ�ο� �Լ�
private:
    void PhaseUpdate(float DeltaTime);

private://Phase 1
    void Phase0(float DeltaTime);


public:
    void SetScrollMapSpeed(float Speed);
    void SetScrollMapSpeedSoft(float AdjustSpeed, float SpeedPerSec);
    void KeyMonsterDead();


};

