#pragma once
#include "WidgetWindow.h"
class CWindowStart :
    public CWidgetWindow
{
    friend class CScene;

protected:
    CWindowStart();
    virtual ~CWindowStart();
public:
    virtual bool Init();

private:
    void StartButtonClickCallback();
    void EditButtonClickCallback();
};

