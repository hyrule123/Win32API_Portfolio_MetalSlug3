#include "WindowMonsterHP.h"

//���α׷��� ��
#include "ProgressBar.h"

//����
#include "WidgetNumber.h"

//�̹��� �ε��
#include "../Scene/SceneManager.h"
#include "../Scene/SceneResource.h"
#include "../Resource/Texture/Texture.h"

//���� ��ġ ������
#include "../Scene/Scene.h"
#include "../GameObject/Monster.h"

//CGameObject�� ��ġ�� �����ؾ� �ϹǷ� Camera �ʿ�
#include "../Scene/Camera.h"

CWindowMonsterHP::CWindowMonsterHP():
	m_Monster(nullptr),
	m_Offset(0.f, 100.f)
{
}

CWindowMonsterHP::CWindowMonsterHP(const CWindowMonsterHP& widget):
	CWidgetWindow(widget),
	m_Monster(widget.m_Monster)
{
}

CWindowMonsterHP::~CWindowMonsterHP()
{
}

bool CWindowMonsterHP::Init()
{
	if (!CWidgetWindow::Init())
		return false;


	SetSize(200.f, 100.f);
	m_Monster = (CMonster*)m_Scene->FindObject("Monster");
	m_MonsterHPMax = m_Monster->GetHP();

	if (m_Monster)
		SetPos(m_Monster->GetPos());

	m_Bar = CreateWidget<CProgressBar>("MonsterHPBar"); 
	//�켱 �ؽ�ó �ε��� ���ְ�
	m_Scene->GetSceneResource()->LoadTexture("BarBack", TEXT("Bar/BarBack.bmp"));
	m_Bar->SetTexture(EProgressBar_TextureType::Back, "BarBack");

	m_Scene->GetSceneResource()->LoadTexture("Bar", TEXT("Bar/BarDefault.bmp"));
	m_Bar->SetTexture(EProgressBar_TextureType::Bar, "Bar");

	m_Bar->SetBarFrameSize(200.f, 50.f);
	m_Bar->SetPadding(10.f);

	

	//�������� �߰� ����//////////////////////////////////////////
	m_Number = CreateWidget<CWidgetNumber>("MonsterHPNum");
	//�ִϸ��̼� �ε�
	m_Scene->GetSceneResource()->CreateAnimationSequence("Number", "Number", TEXT("UI/Number.bmp"));
	//�÷�Ű�� ����
	m_Scene->GetSceneResource()->SetColorKey("Number",163,73,164);

	//���� ��������Ʈ ��ǥ �߰�
	for (int i = 0; i < 10; ++i)
	{
		m_Scene->GetSceneResource()->AddAnimationSpriteFrame("Number",
			i * 17.f, 0.f, 16.f, 16.f);
	}

	//WidgetNumber Ŭ������ �ѹ� �̹����� ���.
	m_Number->SetNumberImage("Number");
	
	//4�� ũ�� �׷���.
	m_Number->SetScale(4.f);

	//������ ��ġ + 100 ��ġ�� �׷���
	m_Number->SetOffset(0.f, 100.f);
///////////////////////////////////////////////////////////////

	return true;
}



void CWindowMonsterHP::SetOffset(const Vector2& Offset)
{
	m_Offset = Offset;
}

void CWindowMonsterHP::Update(float DeltaTime)
{

	CWidgetWindow::Update(DeltaTime);

	if (!m_Monster->GetActive())
	{
		m_Monster = nullptr;
		SetActive(false);
	}



	if (m_Monster)
	{
		SetPos(m_Monster->GetPos() - m_Scene->GetCamera()->GetPos() + m_Offset);
		m_Bar->SetValue(m_Monster->GetHP() / m_MonsterHPMax);

		m_Number->SetNumber((int)m_Monster->GetHP());
	}
}

void CWindowMonsterHP::PostUpdate(float DeltaTime)
{

	CWidgetWindow::PostUpdate(DeltaTime);

	if (!m_Monster->GetActive())
	{
		m_Monster = nullptr;
		SetActive(false);
	}
}

void CWindowMonsterHP::Render(HDC hDC, float DeltaTime)
{
	if (!m_Monster->GetActive())
	{
		m_Monster = nullptr;
		SetActive(false);
	}

	CWidgetWindow::Render(hDC, DeltaTime);
}


