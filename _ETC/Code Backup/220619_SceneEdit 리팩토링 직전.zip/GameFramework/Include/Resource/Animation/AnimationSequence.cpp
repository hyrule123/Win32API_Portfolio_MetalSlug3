#include "AnimationSequence.h"
#include "../Texture/Texture.h"

CAnimationSequence::CAnimationSequence() :
	m_Texture(nullptr)
{
}

CAnimationSequence::~CAnimationSequence()
{
}

CTexture* CAnimationSequence::GetTexture() const
{
	return m_Texture;
}

ETextureType CAnimationSequence::GetTextureType() const
{
	return m_Texture->GetTextureType();
}

//Frame�� ������ ������ ������ �Լ�.
const Sprite_FrameData& CAnimationSequence::GetFrameData(int index) const
{
	return m_vecFrame[index];
}

std::vector<Sprite_FrameData> CAnimationSequence::GetFrameDataAll()
{
	return m_vecFrame;
}

size_t CAnimationSequence::GetFrameCount() const
{
	return m_vecFrame.size();
}

void CAnimationSequence::AddSpriteFrame(
	const Vector2& start, const Vector2& end, const Vector2& Offset)
{
	Sprite_FrameData Frame = {};


	Frame.Start = start;
	Frame.End = end;

	m_vecFrame.push_back(Frame);

}

void CAnimationSequence::AddSpriteFrame(
	float PosX, float PosY, 
	float SizeX, float SizeY, 
	float OffsetX, float OffsetY)
{
	Sprite_FrameData Frame = {};


	Frame.Start.x = PosX;
	Frame.Start.y = PosY;
	Frame.End.x = PosX + SizeX;
	Frame.End.y = PosY + SizeY;

	m_vecFrame.push_back(Frame);
}



void CAnimationSequence::AddFrameFrame()
{
	int FrameNum = m_Texture->GetTextureNumbers();

	for (int i = 0; i < FrameNum; ++i)
	{
		Vector2 size = m_Texture->GetTextureSize(i);

		Sprite_FrameData Data;

		//Vector2 ����ü�� �ʱ�ȭ�� �� 0, 0���� �ʱ�ȭ�ǹǷ� Start�� ���� ���ص� ��.
		Data.End = size;

		m_vecFrame.push_back(Data);
	}

}
