#pragma once

#include "../../GameInfo.h"


class CAnimationManager
{
	friend class CResourceManager;

private:
	std::unordered_map<std::string, class CAnimationSequence*> m_mapSequence;

	CAnimationManager();
	~CAnimationManager();
	bool Init();

private:
	class CAnimationSequence* FindAnimSequence(const std::string& Name);
	void ReleaseAnimation(const std::string& Name);

	bool CreateAnimationSequence(const std::string& Name, class CTexture* Tex);

	bool AddAnimationSpriteFrame(const std::string& Name,
		const Vector2& start, const Vector2& end);
	bool AddAnimationSpriteFrame(const std::string& Name,
		float PosX, float PosY, float SizeX, float SizeY);
	bool AddAnimationFrameFrame(const std::string& Name);



};

