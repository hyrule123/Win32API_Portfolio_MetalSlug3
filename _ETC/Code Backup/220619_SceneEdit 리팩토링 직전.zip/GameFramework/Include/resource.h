//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// GameFramework.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDI_ICON1                       101
#define IDD_DIALOG_TILEMAPEDIT          104
#define IDD_DIALOG_ANIMEDIT             104
#define IDC_EDIT_COUNTX                 1005
#define IDC_EDIT_COUNTY                 1006
#define IDC_EDIT_SIZEX                  1007
#define IDC_EDIT_SIZEY                  1008
#define IDC_BUTTON_CREATE               1009
#define IDC_BUTTON_QUIT                 1010
#define IDC_LIST_ANIMSEQ                1011
#define IDC_LIST_SPRITE_FRAME           1012
#define IDC_BUTTON_LOADCSV              1013
#define IDC_BUTTON_ADDFRAME             1014
#define IDC_LIST_TEXTURENAME            1015
#define IDC_COMBO_OPTION                1016
#define IDC_LIST_FILENAME               1016
#define IDC_BUTTON_SAVE                 1017
#define IDC_BUTTON_LOAD                 1018
#define IDC_EDIT_FRAME_STARTX           1019
#define IDC_EDIT_FRAME_STARTY           1020
#define IDC_EDIT_FRAME_ENDX             1021
#define IDC_EDIT_FRAME_ENDY             1022
#define IDC_CHECK_RENDER                1023
#define IDC_CHECK_SIDECOLL              1024
#define IDC_BUTTON_LOADBKGRND           1025
#define IDC_BUTTON_ADDANIMSEQ           1028
#define IDC_EDIT_FRAME_ANIMSEQNAME      1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
