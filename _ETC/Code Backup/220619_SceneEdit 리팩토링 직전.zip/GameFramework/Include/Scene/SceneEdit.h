#pragma once
#include "Scene.h"


class CSceneEdit :
    public CScene
{
	friend class CSceneManager;
	friend class CSceneEditDlg;

protected:
	CSceneEdit();
	virtual ~CSceneEdit();
public:
	bool Init();

private:
	class CSceneEditDlg* m_EditorDlg;
public:
	void CreateTileMap(int CountX, int CountY, int SizeX, int SizeY);
	void SetTileTexture(class CTexture* Texture);




public://�� �̵� ���� �Լ�
	void OpenTileMapEditor();
	void DeleteDlg();



	void ChangeFrame();


};

