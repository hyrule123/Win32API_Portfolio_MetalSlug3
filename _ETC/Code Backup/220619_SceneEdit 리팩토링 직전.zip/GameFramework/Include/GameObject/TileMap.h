#pragma once

#include "GameObject.h"


class CTileMap :
	public CGameObject
{
	friend class CScene;

protected:
	CTileMap();
	CTileMap(const CTileMap& Obj);
	virtual ~CTileMap();
public:
	virtual bool Init(class CGameObject* Obj = nullptr);


private:
	std::vector<class CTile*>	m_vecTile;
	CSharedPtr<class CTexture>	m_TileTexture;
	int		m_CountX;
	int		m_CountY;
	Vector2	m_TileSize;
	int		m_StartX;
	int		m_StartY;
	int		m_EndX;
	int		m_EndY;



public:
	int GetCountX()	const;
	int GetCountY()	const;


public:
	void SetTileRender(const Vector2& Pos, bool Render);
	void SetTileSideColl(const Vector2& Pos, bool SideColl);
	void ChangeTileOption(const Vector2& Pos, ETileOption Option);
	void SetTileFrame(const Vector2& Pos, const Vector2& Start,
		const Vector2& End);
	class CTile* GetTile(const Vector2& Pos);
	class CTile* GetTile(int Index);
	class CTile* GetTile(int IndexX, int IndexY);
	int GetTileIndexX(float x);
	int GetTileIndexY(float y);
	int GetTileIndex(const Vector2& Pos);
	int GetTileOriginIndexX(float _x);
	int GetTileOriginIndexY(float _y);


public:

	//Ÿ�� ���� ����
	bool CreateTile(int CountX, int CountY, const Vector2& TileSize);
	void SetTileTexture(const std::string& Name);
	void SetTileTexture(class CTexture* Texture);
	void SetTileTexture(const std::string& Name, const std::tstring& FileName,
		const std::string& PathName = TEXTURE_PATH);
	void SetTileTextureFullPath(const std::string& Name, const std::tstring& FullPath);
	void SetTileTexture(const std::string& Name, const std::vector<std::tstring>& vecFileName,
		const std::string& PathName = TEXTURE_PATH);
	void SetTileTextureFullPath(const std::string& Name, const std::vector<std::tstring>& vecFullPath);



	bool SetTileColorKey(unsigned char r, unsigned char g, unsigned char b,
		int Index = 0);
	bool SetTileColorKeyAll(unsigned char r, unsigned char g, unsigned char b);

public:
	virtual void Save(FILE* File);
	virtual void Load(FILE* File);


public:
	virtual void Update(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);
};

