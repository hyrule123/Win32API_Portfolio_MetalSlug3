#include "Effect.h"

#include "../Resource/Animation/Animation.h"
#include "../Resource/Animation/AnimationInfo.h"

CEffect::CEffect():
	m_Duration(0.f),
	m_Time(0.f),
	m_EffectType(EEffectType::Once)
{
	m_RenderLayer = ERenderLayer::Effect;
}

CEffect::CEffect(const CEffect& Obj):
	CGameObject(Obj),
	m_Duration(Obj.m_Duration),
	m_Time(0.f),
	m_EffectType(Obj.m_EffectType)
{
}

CEffect::~CEffect()
{
}

bool CEffect::Init(CGameObject* Obj)
{
	//������ �ִϸ��̼� �ϳ� �ϴ� ����
	CreateAnimation();

	//�ִϸ��̼ǿ� �ִϸ��̼� ���� �Լ��� ���
	m_Animation->SetCurrentAnimEndFunc<CEffect>(this, &CEffect::EffectEnd);



	return true;
}

void CEffect::Update(float DeltaTime)
{
	CGameObject::Update(DeltaTime);


	if (m_EffectType == EEffectType::Duration)
	{
		m_Time += DeltaTime;

		if (m_Time > m_Duration)
		{
			SetActive(false);
		}
	}
	

}

void CEffect::PostUpdate(float DeltaTime)
{
	CGameObject::PostUpdate(DeltaTime);
}

void CEffect::Render(HDC hDC, float DeltaTime)
{
	CGameObject::Render(hDC, DeltaTime);
}

void CEffect::EffectEnd()
{
	//���� �ѹ��� ����̶�� �ٷ� false
	if (m_EffectType == EEffectType::Once)
	{
		SetActive(false);
	}
}

EEffectType CEffect::GetEffect() const
{
	return m_EffectType;
}

void CEffect::SetEffect(EEffectType Type)
{
	m_EffectType = Type;

	if (Type == EEffectType::Loop)
	{
		m_Animation->SetLoop();
	}
}

void CEffect::SetDuration(float Duration)
{
	m_Duration = Duration;
}
