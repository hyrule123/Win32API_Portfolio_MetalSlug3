#pragma once
#include "GameObject.h"

class CEffect: public CGameObject
{
	friend class CScene;

protected:
	CEffect();
	CEffect(const CEffect& Obj);
	virtual ~CEffect();

protected:
	EEffectType m_EffectType;
	float m_Duration;
	float m_Time;


public:
	virtual bool Init(CGameObject* Obj = nullptr);
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

protected:
	void EffectEnd();

public:
	EEffectType GetEffect() const;

	void SetEffect(EEffectType Type);

	void SetDuration(float Duration);

};

