#include "Player.h"
#include "../GameManager.h"
#include "../input.h"
#include "../Scene/Scene.h"
#include "Bullet.h"
#include "TornadoBullet.h"
#include "SolBullet.h"

#include "../Scene/SceneResource.h"

//�浹ü
#include "../Collision/ColliderBox.h"


CPlayer::CPlayer()
{
	SetTypeID<CPlayer>();


}

CPlayer::CPlayer(const CPlayer& Obj):
	CCharacter(Obj)
{
}

CPlayer::~CPlayer()
{
	CInput::GetInst()->DeleteBindClass<CPlayer>(this);
}

bool CPlayer::Init(CGameObject* Obj)
{
	CCharacter::Init(Obj);

	//Player�� �ּҸ� CGameManager�� ����Ѵ�.
	CGameManager::GetInst()->SetPlayer((CPlayer*)this);

	return true;
}

void CPlayer::Update(float DeltaTime)
{
	CCharacter::Update(DeltaTime);
}

void CPlayer::PostUpdate(float DeltaTime)
{
	CCharacter::PostUpdate(DeltaTime);



	//��Ÿ�� ���
	CheckSkillCoolTime((int)EPlayerSkill::End, DeltaTime);

}

void CPlayer::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);

}

float CPlayer::InflictDamage(float Damage)
{
	CCharacter::InflictDamage(Damage);

	return Damage;
}

