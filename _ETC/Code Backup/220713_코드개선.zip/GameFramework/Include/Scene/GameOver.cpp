#include "GameOver.h"

#include "StartScene.h"
#include "../Input.h"

#include "SceneManager.h"
#include "SceneResource.h"

//�ε��� ��
#include "SceneEdit.h"
#include "MainScene.h"

//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"

//���ȭ��
#include "../GameObject\Background.h"

#include "../UI/WindowGameOver.h"

#include "../UI/WidgetTextImage.h"


//ī�޶�

CGameOver::CGameOver()
{
}

CGameOver::~CGameOver()
{

}

bool CGameOver::Init()
{
	CScene::Init();

	//���ҽ� �ε�
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontSilver.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontGold.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/ScoreNumber.csv"));

	m_SceneResource->LoadTexture("GameOver0", TEXT("UI/GameOver0.bmp"));
	m_SceneResource->LoadTexture("GameOver1", TEXT("UI/GameOver1.bmp"));

	//���ȭ��
	CBackground* Back = CreateObject<CBackground>("BackGround");
	Back->SetTexture("GameOver0");



	//������ ȣ��
	CreateWidgetWindow<CWindowGameOver>("WindowGameOver");


	return true;
}

void CGameOver::DeathGameOver()
{
}



