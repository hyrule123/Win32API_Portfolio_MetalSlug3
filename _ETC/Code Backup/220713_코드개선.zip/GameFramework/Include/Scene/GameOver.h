#pragma once
#include "Scene.h"
class CGameOver :
    public CScene
{
    friend class CSceneManager;

protected:
    CGameOver();
    virtual ~CGameOver();

public:
    bool Init();
    void DeathGameOver();


};

