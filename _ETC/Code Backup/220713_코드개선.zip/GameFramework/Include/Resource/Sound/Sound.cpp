#include "Sound.h"

#include "../../PathManager.h"

CSound::CSound():
	m_System(nullptr),
	m_ChannelGroup(nullptr),
	m_Channel(nullptr),
	m_isLoop(false)
{
	SetTypeID<CSound>();
}

CSound::~CSound()
{

	if (m_Sound)
		m_Sound->release();

}

void CSound::Init()
{
}

bool CSound::GetLoop() const
{
	return m_isLoop;
}

bool CSound::GetPlaying() const
{
	bool Playing = false;

	if (m_Channel)
	{
		//�ٵ� �ű⼭ ��� ���� ���
		m_Channel->isPlaying(&Playing);
	}

	return Playing;
}

void CSound::Play()
{
	m_System->playSound(m_Sound, m_ChannelGroup, false, &m_Channel);
	//m_isPlaying = true;

}

void CSound::Stop()
{
	//ä�ο� �Ҵ�Ǿ� ���� ���
	if (m_Channel)
	{
		bool Playing = false;

		//�ٵ� �ű⼭ ��� ���� ���
		m_Channel->isPlaying(&Playing);
		if (Playing)
		{
			//����� ���߰� ä�ΰ��� ������ �����Ѵ�.
			m_Channel->stop();
			m_Channel = nullptr;
		}
	}
}

void CSound::Pause()
{
	if (m_Channel)
	{
		bool Playing = false;

		m_Channel->isPlaying(&Playing);
		if (Playing)
		{
			m_Channel->setPaused(true);
			//m_isPlaying = false;
		}
	}

}

void CSound::Resume()
{
	if (m_Channel)
	{
		bool Playing = false;

		m_Channel->isPlaying(&Playing);
		if (Playing)
		{
			m_Channel->setPaused(false);
			//m_isPlaying = true;
		}
	}
}

void CSound::FadeIn(float Duration)
{
	if (!m_Channel)
		return;

	bool Playing = false;

	m_Channel->isPlaying(&Playing);
	if (Playing)
	{
		m_Channel->setPaused(true);
		//m_isPlaying = false;
	}

	unsigned long long dspclock;
	int rate;
	FMOD_RESULT result;

	result = m_Channel->getSystemObject(&m_System);                        // OPTIONAL : Get System object
	if (result != FMOD_OK)
		return;


	result = m_System->getSoftwareFormat(&rate, 0, 0);                // Get mixer rate
	if (result != FMOD_OK)
		return;

	result = m_Channel->getDSPClock(0, &dspclock);                    // Get the reference clock, which is the parent channel group
	if (result != FMOD_OK)
		return;

	result = m_Channel->addFadePoint(dspclock, 0.0f);                 // Add a fade point at 'now' with full volume.
	if (result != FMOD_OK)
		return;

	result = m_Channel->addFadePoint(dspclock + (unsigned __int64)(rate * Duration), 1.0f);    // Add a fade point 5 seconds later at 0 volume.
	if (result != FMOD_OK)
		return;

	Playing = false;

	m_Channel->isPlaying(&Playing);
	if (Playing)
	{
		m_Channel->setPaused(false);
		//m_isPlaying = true;
	}
}

void CSound::FadeOut(float Duration)
{
	if (!m_Channel)
		return;

	unsigned long long dspclock;
	int rate;
	FMOD_RESULT result;

	result = m_Channel->getSystemObject(&m_System);                        // OPTIONAL : Get System object

	if (result != FMOD_OK)
		return;

	result = m_System->getSoftwareFormat(&rate, 0, 0);                // Get mixer rate
	if (result != FMOD_OK)
		return;

	result = m_Channel->getDSPClock(0, &dspclock);                    // Get the reference clock, which is the parent channel group
	if (result != FMOD_OK)
		return;


	result = m_Channel->addFadePoint(dspclock, 1.0f);                 // Add a fade point at 'now' with full volume.
	if (result != FMOD_OK)
		return;


	result = m_Channel->addFadePoint(dspclock + (unsigned __int64)(rate * Duration), 0.0f);    // Add a fade point 5 seconds later at 0 volume.
	if (result != FMOD_OK)
		return;


	result = m_Channel->setDelay(0, dspclock + (unsigned __int64)(rate * Duration), true);     // Add a delayed stop command at 5 seconds ('stopchannels = true')
	if (result != FMOD_OK)
		return;


}

bool CSound::LoadSound(FMOD::System* System, FMOD::ChannelGroup* Group, bool Loop, const char* FileName, const std::string& PathName)
{
	m_System = System;
	m_ChannelGroup = Group;
	m_isLoop = Loop;

	//�ּҸ� �޾ƿ´�.
	char FullPath[MAX_PATH] = {};
	const PathInfo* Info = CPathManager::GetInst()->FindPath(PathName);
	if (Info)
	{
		strcpy_s(FullPath, Info->PathMultiByte);
	}
	strcat_s(FullPath, FileName);


	//���� ���θ� Ȯ���ϰ� �����Ѵ�.
	FMOD_MODE Mode = FMOD_DEFAULT;
	if (Loop)
	{
		Mode = FMOD_LOOP_NORMAL;
	}


	//���� �������� ���ڷ� �Ѱܼ� ���带 ����� �����ϸ� false�� ��ȯ�Ѵ�.
	if (FMOD_OK != m_System->createSound(FullPath, Mode, nullptr, &m_Sound))
	{
		return false;
	}


	return true;
}
