#include "CUFO.h"

#include "../Scene/SceneManager.h"
#include "../GameManager.h"
#include "../GameObject/Player.h"



//���ҽ� �ε�
#include "../Scene/SceneResource.h"
#include "../Resource/Texture/Texture.h"


//����Ʈ
#include "Effect.h"

//�浹ü
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderCircle.h"

//��ġ ��� ī�޶�
#include "../Scene/Camera.h"

//���� ������Ʈ
#include "../UI/WidgetComponent.h"

//ü�¹�, ü�� ����
#include "../UI/ProgressBar.h"
#include "../UI/WidgetNumber.h"


CUFO::CUFO()
{
	SetTypeID<CUFO>();
}

CUFO::CUFO(const CUFO& Obj) :
	CEnemy(Obj)
{
}

CUFO::~CUFO()
{
}

bool CUFO::LoadResource()
{
	CreateAnimation();

	if (!LoadCSVPreset(TEXT("Enemy/UFO.csv")))
		return false;

	return true;
}

bool CUFO::Init(CGameObject* Obj)
{
	CCharacter::Init(Obj);

	SetPos(100.f, 50.f);
	SetSize(52.f, 30.f);

	SetAnimation("UFO_Main");

	CColliderBox* Coll = AddCollider<CColliderBox>("UFO");
	Coll->SetPivot(0.5f, 0.f);
	Coll->SetSize(m_Size.x, m_Size.y - 10.f);

	return true;
}


void CUFO::Update(float DeltaTime)
{
	CCharacter::Update(DeltaTime);
}

void CUFO::PostUpdate(float DeltaTime)
{
	CCharacter::PostUpdate(DeltaTime);

	////ü�� Ȯ��
	//if (m_HP <= 0.f)
	//	SetActive(false);
}

void CUFO::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);
}


int CUFO::InflictDamage(int Damage)
{
	int DMG = CCharacter::InflictDamage(Damage);



	//�ϴ� �������� ����
	DMG = 0;

	m_HP -= DMG;

	StartReaction(0.2f, false, EReactionChannel::HitReaction);


	return DMG;
}

void CUFO::CollBeginMouse(const Vector2& Point, CCollider* Col)
{
	CEffect* Effect = m_Scene->CreateObject<CEffect>("BulletSFX");

	Effect->AddAnimationInfo("BulletSFX", 0.1f);
	Effect->SetRenderLayer(ERenderLayer::EffectLow);

	Effect->SetPivot(0.5f, 0.5f);
	Effect->SetPos(Point);

}