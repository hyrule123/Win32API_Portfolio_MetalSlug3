#pragma once
#include "Effect.h"
class CExplosion :
    public CEffect
{
	friend class CScene;

protected:
	CExplosion();
	CExplosion(const CExplosion& Obj);
	virtual ~CExplosion();

public:
	virtual bool LoadResource();
	virtual bool Init(CGameObject* Obj = nullptr);
	bool SetSFX(const std::string& Name);


public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);
};

