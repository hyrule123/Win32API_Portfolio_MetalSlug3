#pragma once
#include "Projectile.h"
class CHMG :
    public CProjectile
{
    friend class CScene;

protected:
    CHMG();
    CHMG(const CHMG& Obj);
    virtual ~CHMG();

public:
    bool Init(CGameObject* Obj = nullptr);
    bool LoadResource();


private:
    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

