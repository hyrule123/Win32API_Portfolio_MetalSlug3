#include "PlayerSpace.h"
#include "../GameManager.h"
#include "../input.h"
#include "../Scene/Scene.h"

#include "../Scene/SceneResource.h"

//�¿� �ִϸ��̼� ��� ���� �Է� Ȯ�ο�
#include "../Input.h"

//�浹ü
#include "../Collision/ColliderBox.h"

#include "Pistol.h"




CPlayerSpace::CPlayerSpace():
	m_DirTime(),
	m_DirTimeMax(0.2f),
	m_Tolerance(0.03f),
	m_CurrentAct(EDirAction::Idle_Pistol),
	m_PrevAct(EDirAction::Idle_Pistol),
	m_CurrentDir(EDirSpace::Mid),
	m_CurrentWeapon(EWeapon::Pistol),
	m_NoActionChange(false)
{
	SetTypeID<CPlayerSpace>();

	m_RenderLayer = ERenderLayer::Player;
	m_DirTimeMaxHalf = m_DirTimeMax / 2.f;
	m_HP = 1;
}

CPlayerSpace::CPlayerSpace(const CPlayerSpace& Obj) :
	CPlayer(Obj),
	m_DirTime(Obj.m_DirTime),
	m_DirTimeMax(Obj.m_DirTimeMax),
	m_Tolerance(Obj.m_Tolerance),
	m_CurrentAct(Obj.m_CurrentAct),
	m_PrevAct(Obj.m_PrevAct),
	m_CurrentDir(Obj.m_CurrentDir),
	m_CurrentWeapon(Obj.m_CurrentWeapon),
	m_NoActionChange(Obj.m_NoActionChange)
{
	int iMax = (int)EDirSpace::MAX;
	int jMax = (int)EDirAction::MAX;
	for (int i = 0; i < iMax; ++i)
	{
		for (int j = 0; j < jMax; ++j)
		{
			m_vecAnimName[i][j] = Obj.m_vecAnimName[i][j];
		}
	}
}

CPlayerSpace::~CPlayerSpace()
{
	CInput::GetInst()->DeleteBindClass<CPlayerSpace>(this);
}

bool CPlayerSpace::LoadResource()
{
	/////////////////// �ִϸ��̼� ���� ///////////////////
	CreateAnimation();
	if(!LoadCSVPreset(TEXT("Player/PlayerSpace.csv")))
		return false;
	RegisterAnimName();

	return true;
}

bool CPlayerSpace::Init(CGameObject* Obj)
{
	CPlayer::Init(Obj);


	//��ġ ����
	SetPos(50.f, 50.f);
	SetSize(22.f, 50.f);
	SetDir(1.f, 0.f);
	SetPivot(0.5f, 1.f);
	SetScale(1.f);
	SetMaxVelocity(200.f);
	SetDeAccel(1.f);



	//�Է� �ʱ�ȭ
	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveLeft", 
		EInput_Type::Push,
		this, &CPlayerSpace::MoveLeft);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveRight", 
		EInput_Type::Push,
		this, &CPlayerSpace::MoveRight);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveUp", 
		EInput_Type::Push,
		this, &CPlayerSpace::MoveUp);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveDown", 
		EInput_Type::Push,
		this, &CPlayerSpace::MoveDown);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("GunFire", 
		EInput_Type::Down,
		this, &CPlayerSpace::FireGun);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Bomb", 
		EInput_Type::Push,
		this, &CPlayerSpace::FireBomb);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Debug1",
		EInput_Type::Down,
		this, &CPlayerSpace::ChangeRifleHMG);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Debug2",
		EInput_Type::Down,
		this, &CPlayerSpace::ChangeRifleShotgun);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Debug3",
		EInput_Type::Down,
		this, &CPlayerSpace::ChangeRifleRocket);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Debug4",
		EInput_Type::Down,
		this, &CPlayerSpace::RifleDrop);


	//��ų ����
	m_vecCooltime.resize((size_t)EPlayerSkill::End);
	m_vecCooltime[(int)EWeapon::Pistol].Cooltime = 0.1f;



	//���� ���� EndFunction ���
	for (int i = (int)EDirSpace::Left2; i < (int)EDirSpace::MAX; ++i)
	{
		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Attack_Pistol], 
			this, &CPlayerSpace::AttackEnd);

		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Attack_HMG], 
			this, &CPlayerSpace::AttackEnd);
		
		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Attack_Rocket],
			this, &CPlayerSpace::AttackEnd);

		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Attack_Shotgun],
			this, &CPlayerSpace::AttackEnd);

		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Rifle_Drop],
			this, &CPlayerSpace::RifleDropEnd);

		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Death],
			this, &CPlayerSpace::DeathEnd);

		SetEndFunction(
			m_vecAnimName[i][(int)EDirAction::Slug_Ejection],
			this, &CPlayerSpace::SlugEjectionEnd);
	}
	
	////�浹ü ����
	CColliderBox* m_Collider = AddCollider<CColliderBox>("PlayerBox");

	m_Collider->SetSize(m_Size);
	m_Collider->SetCollisionProfile(ECollisionChannel::Player);
	m_Collider->SetPivot(0.5f, 1.f);

	return true;
}



void CPlayerSpace::ComputeCurrentDir(float DeltaTime)
{
	//�������� ���� ��� �������� ���ƿ�
	if (fabs(m_MoveDist.x) <= FLT_EPSILON)
	{
		if (m_DirTime > m_Tolerance)
			m_DirTime -= DeltaTime;
		else if (m_DirTime < -m_Tolerance)
			m_DirTime += DeltaTime;
	};


	//������� ������ �� �������� ���� ����� ��������. ���� Ȯ��
	//10�� ���ѵ� ������ �ٲپ �Ҽ����� �� �ٲ��ص�
	//����ü�� �°� ������
	//ex)-0.25f(�� ����) -> -2.5f -> -2 + 2(�ִ񰪸�ŭ �����ذ�)
	//->�ε����� �´� ���� ����
	// 
	m_CurrentDir = (EDirSpace)
		((int)(m_DirTime * 10.f) + (int)(m_DirTimeMax * 10.f));


	if (m_CurrentDir > EDirSpace::Right2)
		m_CurrentDir = EDirSpace::Right2;
	else if (m_CurrentDir < EDirSpace::Left2)
		m_CurrentDir = EDirSpace::Left2;

}

void CPlayerSpace::ComputeCurrentAct(float DeltaTime)
{
	//�� �Ƚ����� ���̵� ���(�� ������ �� �߻� �޼ҵ忡�� �׼� �����)
	if (!m_NoActionChange)
	{
		if (m_CurrentWeapon == EWeapon::Pistol)
			m_CurrentAct = EDirAction::Idle_Pistol;
		else
			m_CurrentAct = EDirAction::Idle_Rifle;
	}
}


void CPlayerSpace::MoveLeft()
{
	if (m_DirTime > 0.f)
		m_DirTime -= DELTA_TIME * 2.f;
	else
		m_DirTime -= DELTA_TIME;

	if (m_DirTime <= -1.f * m_DirTimeMax)//�ִ��� ����(+������)
		m_DirTime = -1.f * (m_DirTimeMax + m_Tolerance);
	SetDir(-1.f, 0.f);
	MoveDir(m_Dir);
}

void CPlayerSpace::MoveRight()
{
	if (m_DirTime < 0.f)
		m_DirTime += DELTA_TIME * 2.f;
	else
		m_DirTime += DELTA_TIME;


	if (m_DirTime >= m_DirTimeMax)//�ִ��� ����
		m_DirTime = m_DirTimeMax + m_Tolerance;

	SetDir(1.f, 0.f);
	MoveDir(m_Dir);
}




void CPlayerSpace::MoveUp()
{
	SetDir(0.f, -1.f);
	MoveDir(m_Dir);
}

void CPlayerSpace::MoveDown()
{
	SetDir(0.f, 1.f);
	MoveDir(m_Dir);
}

void CPlayerSpace::FireGun()
{
	CPlayer::FireGun(); //���Է� ���� 1 ����
}

void CPlayerSpace::FireGunCheck()
{
	//��Ÿ���̰ų� �Է��� ������ ���ٸ� return
	if (m_vecCooltime[(int)EWeapon::Pistol].isCooltime 
		|| m_AttackBuffer == 0)
		return;

	if (m_NoActionChange)
		return;

	//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ����
	EnterSkillCoolTIme((int)EWeapon::Pistol);

	m_AttackBuffer = 0; //���� �ʱ�ȭ

	switch (m_CurrentWeapon)
	{
	case EWeapon::Pistol:
	{
		m_CurrentAct = EDirAction::Attack_Pistol;
		CPistol* Pistol = m_Scene->CreateObject<CPistol>("Pistol");
		Pistol->SetEssential(Vector2(0.f, -1.f), Vector2(m_Pos.x, m_Pos.y - 80.f));
		break;
	}
	case EWeapon::HMG:
		m_CurrentAct = EDirAction::Attack_HMG;
		break;
	case EWeapon::ShotGun:
		m_CurrentAct = EDirAction::Attack_Shotgun;
		break;
	case EWeapon::Rocket:
		m_CurrentAct = EDirAction::Attack_Rocket;
		break;
	case EWeapon::Laser:
		m_CurrentAct = EDirAction::Attack_Rocket;
		break;
	default:
		break;
	}

	m_NoActionChange = true;
}

void CPlayerSpace::FireBomb()
{
}

void CPlayerSpace::FireNotify()
{
	////��ų ���� ����
	//CProjectile* Bullet = m_Scene->CreateObject<CProjectile>("PlayerBullet", this);
	//Bullet->SetMaxVelocityDir(1000.f, m_Dir);
	//Bullet->SetPos(m_Pos);
	//Bullet->SetDamage(20.f);
}

void CPlayerSpace::RifleDrop()
{
	if (m_CurrentWeapon == EWeapon::Pistol)
		return;

	m_CurrentAct = EDirAction::Rifle_Drop;

	//�� �߻� ���¸� true�� �����Ͽ� �ѹ߻� �Ұ����ϰ� �ϰ� ���� ����
	m_NoActionChange = true;
	m_CurrentWeapon = EWeapon::Pistol;
}

void CPlayerSpace::RifleDropEnd()
{
	m_NoActionChange = false;
}

void CPlayerSpace::ChangeRifleHMG()
{
	m_CurrentWeapon = EWeapon::HMG;
}

void CPlayerSpace::ChangeRifleShotgun()
{
	m_CurrentWeapon = EWeapon::ShotGun;
}

void CPlayerSpace::ChangeRifleRocket()
{
	m_CurrentWeapon = EWeapon::Rocket;
}

void CPlayerSpace::ChangePistol()
{
	m_CurrentWeapon = EWeapon::Pistol;
}

void CPlayerSpace::Death()
{
	m_CurrentAct = EDirAction::Death;
	m_NoActionChange = true;
	SetMaxVelocity(0.f);
}

void CPlayerSpace::DeathEnd()
{
	//�ٷ� �����ϱ� �׷��������� ����..
	//���� Ÿ�̸Ӱ����� �ϳ� ���� �� �� �ð��� �����ؾ� �ҵ�.
	SetActive(false);
}

void CPlayerSpace::SlugEjection()
{
	m_CurrentAct = EDirAction::Slug_Ejection;
	StartReaction(3.f, true, EReactionChannel::InvincibleReaction);
	m_NoActionChange = true;
}

void CPlayerSpace::SlugEjectionEnd()
{
	m_CurrentAct = EDirAction::Idle_Pistol;
	m_NoActionChange = false;
}

int CPlayerSpace::InflictDamage(int Damage)
{
	m_HP -= Damage;

	return Damage;
}




void CPlayerSpace::Update(float DeltaTime)
{
	CPlayer::Update(DeltaTime);

	FireGunCheck();


	if (m_HP <= 0)
		Death();
}

void CPlayerSpace::PostUpdate(float DeltaTime)
{
	CPlayer::PostUpdate(DeltaTime);

	if (m_HP <= 0)
		SetActive(false);

	//m_Pos = m_PrevPos;

	ComputeCurrentDir(DeltaTime);
	ComputeCurrentAct(DeltaTime);

	char txt[64] = {};


	CGameManager::GetInst()->DebugTextOut("DirTime", m_DirTime);
	CGameManager::GetInst()->DebugTextOut("Current Dir", (int)m_CurrentDir);


	//���� ��� �������� �̾ ����ϰ�
	//�ٸ� ��� ���� ���
	if (m_CurrentAct == m_PrevAct)
	{
		ChangeAnimContinue(
			m_vecAnimName[(int)m_CurrentDir][(int)m_CurrentAct]
		);
	}
	else
	{
		ChangeAnimation(
			m_vecAnimName[(int)m_CurrentDir][(int)m_CurrentAct]
		);
	}


	//���� �׼� ������Ʈ
	m_PrevAct = m_CurrentAct;
}

void CPlayerSpace::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);

}



void CPlayerSpace::AttackEnd()
{
	if (m_CurrentWeapon == EWeapon::Pistol)
	{
		m_CurrentAct = EDirAction::Idle_Pistol;
	}
	else
	{
		m_CurrentAct = EDirAction::Idle_Rifle;
	}

	m_NoActionChange = false;
}

void CPlayerSpace::RegisterAnimName()
{
	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Idle_Pistol]
		= "Left2_Idle_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Idle_Pistol]
		= "Left1_Idle_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Idle_Pistol]
		= "Mid_Idle_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Idle_Pistol]
		= "Right1_Idle_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Idle_Pistol]
		= "Right2_Idle_Pistol";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Attack_Pistol]
		= "Left2_Attack_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Attack_Pistol]
		= "Left1_Attack_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Attack_Pistol]
		= "Mid_Attack_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Attack_Pistol]
		= "Right1_Attack_Pistol";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Attack_Pistol]
		= "Right2_Attack_Pistol";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Idle_Rifle]
		= "Left2_Idle_Rifle";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Idle_Rifle]
		= "Left1_Idle_Rifle";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Idle_Rifle]
		= "Mid_Idle_Rifle";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Idle_Rifle]
		= "Right1_Idle_Rifle";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Idle_Rifle]
		= "Right2_Idle_Rifle";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Attack_HMG]
		= "Left2_Attack_HMG";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Attack_HMG]
		= "Left1_Attack_HMG";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Attack_HMG]
		= "Mid_Attack_HMG";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Attack_HMG]
		= "Right1_Attack_HMG";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Attack_HMG]
		= "RIght2_Attack_HMG";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Attack_Shotgun]
		= "Left2_Attack_Shotgun";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Attack_Shotgun]
		= "Left1_Attack_Shotgun";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Attack_Shotgun]
		= "Mid_Attack_Shotgun";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Attack_Shotgun]
		= "Right1_Attack_Shotgun";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Attack_Shotgun]
		= "RIght2_Attack_Shotgun";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Attack_Rocket]
		= "Left2_Attack_Rocket";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Attack_Rocket]
		= "Left1_Attack_Rocket";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Attack_Rocket]
		= "Mid_Attack_Rocket";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Attack_Rocket]
		= "Right1_Attack_Rocket";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Attack_Rocket]
		= "RIght2_Attack_Rocket";


	m_vecAnimName
		[(int)EDirSpace::Left2][(int)EDirAction::Rifle_Drop]
		= "Left2_Rifle_Drop";
	m_vecAnimName
		[(int)EDirSpace::Left1][(int)EDirAction::Rifle_Drop]
		= "Left1_Rifle_Drop";
	m_vecAnimName
		[(int)EDirSpace::Mid][(int)EDirAction::Rifle_Drop]
		= "Mid_Rifle_Drop";
	m_vecAnimName
		[(int)EDirSpace::Right1][(int)EDirAction::Rifle_Drop]
		= "Right1_Rifle_Drop";
	m_vecAnimName
		[(int)EDirSpace::Right2][(int)EDirAction::Rifle_Drop]
		= "Right2_Rifle_Drop";

	for (int i = 0; i < (int)EDirSpace::MAX; ++i)
	{
		m_vecAnimName
			[i][(int)EDirAction::Slug_Ejection]
			= "Slug_Ejection";
	}

	for (int i = 0; i < (int)EDirSpace::MAX; ++i)
	{
		m_vecAnimName
			[i][(int)EDirAction::Death]
			= "Death";
	}
}
