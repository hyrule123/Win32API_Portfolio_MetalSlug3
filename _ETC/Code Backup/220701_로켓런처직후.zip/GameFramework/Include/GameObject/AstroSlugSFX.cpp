#include "AstroSlugSFX.h"

#include "../Scene/Scene.h"

#include "PlayerSpace.h"

CAstroSlugSFX::CAstroSlugSFX()
{
	SetTypeID<CAstroSlugSFX>();
}

CAstroSlugSFX::CAstroSlugSFX(const CAstroSlugSFX& Obj):
	CEffect(Obj)
{
	//���� �ܰ迡�� �����Ǵ� ����
	//bool m_isReady;
}

CAstroSlugSFX::~CAstroSlugSFX()
{
}

bool CAstroSlugSFX::LoadResource()
{
	CEffect::LoadResource();

	if (!LoadCSVPreset(TEXT("Player/AstroSlugSFX.csv")))
		return false;

	if (!LoadCSVPreset(TEXT("Player/SlugOut.csv")))
		return false;

	return true;
}

bool CAstroSlugSFX::Init(CGameObject* Obj)
{
	CEffect::Init(Obj);

	if (!m_Animation->FindAnimInfo(m_Name))
		return false;

	SetAnimation(m_Name);


	m_isReady = true;

	return true;
}

bool CAstroSlugSFX::SetSFX(const std::string& Name)
{
	if (!m_Animation->FindAnimInfo(Name))
		return false;

	SetAnimation(Name);

	m_isReady = true;

	return true;
}


void CAstroSlugSFX::Update(float DeltaTime)
{
	CEffect::Update(DeltaTime);

	if (!m_isReady)
		SetActive(false);
}

void CAstroSlugSFX::PostUpdate(float DeltaTime)
{
	CEffect::PostUpdate(DeltaTime);
}

void CAstroSlugSFX::Render(HDC hDC, float DeltaTime)
{
	CEffect::Render(hDC, DeltaTime);
}
