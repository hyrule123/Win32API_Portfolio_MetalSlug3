#include "JustPlay.h"

CJustPlay::CJustPlay()
{
	SetTypeID<CJustPlay>();
}

CJustPlay::CJustPlay(const CJustPlay& Obj) :
	CEffect(Obj)
{
}

CJustPlay::~CJustPlay()
{
}

bool CJustPlay::Init(CGameObject* Obj)
{
	CEffect::Init();

	if (!m_Animation->FindAnimInfo(m_Name))
		return false;

	SetAnimation(m_Name);

	//Ʈ���� ����Ʈ�� ������ ���̾�� default
	m_RenderLayer = ERenderLayer::Default;

	return true;
}

bool CJustPlay::LoadResource()
{
	if (!LoadCSVPreset(TEXT("SFX/RocketLauncherTrail.csv")))
		return false;

	return true;
}