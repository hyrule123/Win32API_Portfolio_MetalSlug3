#include "EnemyProjectile.h"


#include "../Collision/ColliderBox.h"
#include "../../Include/Scene/Scene.h"


CEnemyProjectile::CEnemyProjectile()
{
	SetTypeID<CEnemyProjectile>();
}

CEnemyProjectile::CEnemyProjectile(const CEnemyProjectile& Obj) :
	CProjectile(Obj)
{
}

CEnemyProjectile::~CEnemyProjectile()
{
}

bool CEnemyProjectile::Init(CGameObject* Obj)
{
	CProjectile::Init(Obj);

	m_MaxVelocity = 800.f;
	m_Damage = 10;

	SetSize(5.f, 30.f);
	SetPivot(0.5f, 0.5f);

	//�浹ü ����
	CColliderBox* Coll = AddCollider<CColliderBox>("EnemyBullet");

	Coll->SetCollisionProfile(ECollisionChannel::PlayerAttack);
	Coll->SetSize(m_Size);

	//ȣ�� �Լ� ����
	Coll->SetColliderBeginFunction(this, &CEnemyProjectile::CollisionBegin);


	return true;
}

bool CEnemyProjectile::LoadResource()
{
	SetTexture("EnemyProjectile", TEXT("SFX/EnemyProjectileSpace.bmp"));
	SetColorKey(0, 248, 0);

	return true;
}



void CEnemyProjectile::CollisionBegin(CCollider* Src, CCollider* Dest)
{
	////CPistolHit* Effect = m_Scene->CreateObject<CPistolHit>("BulletSFX");

	////�ణ �����ϰ� �ǰ�����Ʈ ǥ��
	//Effect->SetPos(Src->GetHitPoint() + (rand() % 5));

	//Dest->GetOwnerObj()->InflictDamage(m_Damage);

	SetActive(false);
}