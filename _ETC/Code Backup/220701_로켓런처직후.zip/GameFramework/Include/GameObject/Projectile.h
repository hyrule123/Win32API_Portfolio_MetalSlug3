#pragma once
#include "GameObject.h"

class CProjectile :
    public CGameObject
{
    friend class CScene;
    
protected:
    float m_Distance;
    int m_Damage;
    bool m_isReady;
    

protected:
    CProjectile();
    CProjectile(const CProjectile& Obj);
    virtual ~CProjectile();

public:
    bool Init(CGameObject* Obj = nullptr);
    void Update(float DeltaTime);
    void PostUpdate(float DeltaTime);
    void Render(HDC hDC, float DeltaTime);
    void SetDamage(int Damage);


    virtual void SetEssential(Vector2 Dir, Vector2 Pos);
    virtual void SetEssential(float DirX, float DirY, float PosX, float PosY);

private:
    //â ���� �Ѿ�� �ı�(�ӽ�)
    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

