#pragma once
#include "Collider.h"

#include "../GameInfo.h"

class CColliderCircle :
    public CCollider
{
    friend class CGameObject;
    friend class CCollisionManager;

protected:
    CColliderCircle();
    CColliderCircle(const CColliderCircle& col);
    virtual ~CColliderCircle();

protected:
    CircleInfo m_Info;


public:
    virtual void SetFixedPos(const Vector2& Pos);
    CircleInfo GetInfo() const;
    void SetRadius(float Rad);
    virtual bool Collision(CCollider* Dest);
    virtual bool CollisionPoint(const Vector2& Point);


protected:
    virtual bool Init();
    virtual void Update(float DeltaTime);
    virtual void PostUpdate(float DeltaTime);
    virtual void Render(HDC hDC, float DeltaTime);


};

