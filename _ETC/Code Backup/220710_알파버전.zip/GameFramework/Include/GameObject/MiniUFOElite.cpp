#include "MiniUFOElite.h"

#include "Player.h"

#include "../Scene/MainScene.h"

//�߻�ü
#include "ProjectileEnemy.h"

//����Ʈ
#include "Effect.h"

//�浹ü
#include "../Collision/ColliderBox.h"

//��ġ ��� ī�޶�


CMiniUFOElite::CMiniUFOElite():
	m_HitTimer(),
	m_MainScene(),
	m_SerialFire()
{
	SetTypeID<CMiniUFOElite>();
}

CMiniUFOElite::CMiniUFOElite(const CMiniUFOElite& Obj) :
	CMiniUFO(Obj),
	m_HitTimer(Obj.m_HitTimer),
	m_MainScene(Obj.m_MainScene),
	m_SerialFire(Obj.m_SerialFire)
{
}

CMiniUFOElite::~CMiniUFOElite()
{
}

bool CMiniUFOElite::LoadResource()
{
	CreateAnimation();

	if (!LoadCSVPreset(TEXT("Enemy/MiniUFOElite.csv")))
		return false;

	return true;
}

bool CMiniUFOElite::Init(CGameObject* Obj)
{
	CMiniUFO::Init(Obj);


	m_HP = 200;
		
	int RandWeapon = rand() % ((int)EItemList::Bomb + 1);
	SetItemDrop((EItemList)RandWeapon);

	return true;
}


void CMiniUFOElite::Update(float DeltaTime)
{
	CMiniUFO::Update(DeltaTime);
		
}

void CMiniUFOElite::PostUpdate(float DeltaTime)
{
	CMiniUFO::PostUpdate(DeltaTime);


}


void CMiniUFOElite::SetEssential(float DestPosX)
{
	m_MoveToDest.x = DestPosX;
}

void CMiniUFOElite::Start()
{
	m_Start = true;


}


void CMiniUFOElite::Routine(float DeltaTime)
{
	switch (m_Routine)
	{
	case (UINT8)EMiniUFORoutine::Delay:
	{
		if (CheckFirstEnter())
		{
			m_Timer.InitCooltime(0.5f);
			m_Timer.EnterCooltime();
		}
		if (m_Timer.UpdateCooltime(DeltaTime))
			GoNextRoutine();

		break;
	}

	case (UINT8)EMiniUFORoutine::Moveto:
	{
		if (CheckFirstEnter())
		{
			float RandX = (float)(rand() % (ORIGINAL_GAME_RES_WIDTH - 40) + 40);
			float RandY = (float)(rand() % 60 + 40);
			MoveToDest(true, EMoveToMethod::AddForce, Vector2(RandX, RandY));
		}

		//�̵� ����Ǹ� ���� ��ƾ����
		if (!m_MoveToOn)
			GoNextRoutine();
	}
	break;

	case (UINT8)EMiniUFORoutine::Wait:
	{
		if (CheckFirstEnter())
		{
			//0~1�ʰ� ���
			m_Timer.InitCooltime((float)(rand()% 11 + 10) / 10.f);
			m_Timer.EnterCooltime();
		}
		if (m_Timer.UpdateCooltime(DeltaTime))
			GoNextRoutine();

		break;
	}

	case (UINT8)EMiniUFORoutine::Attack:
	{
		if (CheckFirstEnter())
		{
			//�ִϸ��̼��� ����ϸ� �˾Ƽ� �� �߻���
			m_SerialFire = 3;
			ChangeAnimation("AttackSFX", true);
		}

		//�ٽ� ó������ ���ư���.
		m_Routine = 0;
		m_FirstEnter = true;
	}
	break;
	}
}


void CMiniUFOElite::AttackEndFunc()
{
	//���� �߻�
	CPlayer* Player = m_Scene->GetPlayer();
	if (Player)
	{
		Vector2 Dir = (Player->GetPos() - m_Pos).Normalize();
		CProjectileEnemy* Proj = m_Scene->CreateObject< CProjectileEnemy>("MiniUFOProj");
		Proj->SetEssential(EProjectileEnemy::MiniUFOAttack, Dir, m_Pos);
	}

	--m_SerialFire;
	if (m_SerialFire <= 0)
		StopAnimation("AttackSFX");
}

void CMiniUFOElite::MiniUFOEliteDeathEndFunc()
{
	SetActive(false);
}
