#include "AnimationManager.h"

#include "AnimationSequence.h"

#include "../Texture/Texture.h"

CAnimationManager::CAnimationManager()
{
}

CAnimationManager::~CAnimationManager()
{

}

bool CAnimationManager::Init()
{



	return true;
}

CAnimationSequence* CAnimationManager::FindAnimSequence(const std::string& Name)
{
	auto iter = m_mapSequence.find(Name);

	if (iter == m_mapSequence.end())
		return nullptr;


	return iter->second;
}

void CAnimationManager::ReleaseAnimation(const std::string& Name)
{
	auto iter = m_mapSequence.find(Name);

	if (iter == m_mapSequence.end())
		return;

	if (iter->second->GetRefCount() == 1)
		m_mapSequence.erase(iter);
}

bool CAnimationManager::CreateAnimationSequence(const std::string& Name, CTexture* Tex)
{
	CAnimationSequence* Seq = FindAnimSequence(Name);

	if (Seq)
		return false;

	Seq = new CAnimationSequence;

	Seq->m_Texture = Tex;
	Seq->SetName(Name);

	m_mapSequence.insert(std::make_pair(Name, Seq));

	return true;
}

bool CAnimationManager::AddAnimationSpriteFrame(const std::string& Name, const Vector2& start, const Vector2& end)
{
	CAnimationSequence* Seq = FindAnimSequence(Name);

	if (!Seq)
		return false;

	Seq->AddSpriteFrame(start, end);

	return true;
}

bool CAnimationManager::AddAnimationSpriteFrame(const std::string& Name, float PosX, float PosY, float SizeX, float SizeY)
{
	CAnimationSequence* Seq = FindAnimSequence(Name);

	if (!Seq)
		return false;

	Seq->AddSpriteFrame(PosX, PosY, SizeX, SizeY);

	return true;
}

bool CAnimationManager::AddAnimationFrameFrame(const std::string& Name)
{
	CAnimationSequence* Seq = FindAnimSequence(Name);

	if (!Seq)
		return false;

	Seq->AddFrameFrame();

	return true;
}

