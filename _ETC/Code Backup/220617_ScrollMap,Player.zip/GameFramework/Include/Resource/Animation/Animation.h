#pragma once

#include "../../GameInfo.h"
#include "AnimationInfo.h"

class CAnimation
{
	friend class CGameObject;

private:
	class CGameObject* m_OwnerObj;
	class CScene* m_Scene;
	std::unordered_map<std::string, CAnimationInfo*> m_mapAnimationInfo;
	CAnimationInfo* m_CurrentAnimation;
	std::function<void()> m_CurrentAnimationEndFunc;
	bool m_CurrentAnimationNotifyInitCheck;

private:
	CAnimation();
	~CAnimation();

public:
	void Update(float DeltaTime);



	void PlayCurrentAnimAgain();


	//���� ������� �ִϸ��̼��� �������θ� true�� ��ȯ
	void SetLoop();

	int CurrentFrameNum()	const;
	CAnimationInfo* FindAnimInfo(const std::string& AnimInfoName);
	void AddAnimation(const std::string& AnimInfoName, const std::string& AnimSeqToUse, 
		bool Loop = true,
		float PlayTime = 1.f, float PlayScale = 1.f, bool Reverse = false);

	void SetPlayTime(const std::string& AnimInfoName, float PlayTime);
	void SetPlayScale(const std::string& AnimInfoName, float PlayScale);
	void SetPlayLoop(const std::string& AnimInfoName, bool Loop);

	//�ѹ��� ����� ����. �ٸ� �ִϸ��̼����� ��ü�Ǹ� �ʱ�ȭ.
	void SetPlayReverse(const std::string& AnimInfoName, bool Reverse, bool Once);

	void SetCurrentAnimation(const std::string& AnimInfoName);
	void ChangeAnimation(const std::string& AnimInfoName);
	bool CheckCurrentAnimation(const std::string& AnimInfoName);




	//����ϸ� ��� �ִϸ��̼� ����� ���� ��� ���������� ȣ��ȴ�.
	template <typename T>
	void SetCurrentAnimEndFunc(T* Obj, void(T::* Func)())
	{
		m_CurrentAnimationEndFunc = std::bind(Func, Obj);
	}


	template <typename T>
	void SetEndFunction(const std::string& AnimInfoName,T* Obj, void (T::* Func)(), bool once = false)
	{
		CAnimationInfo* Info = FindAnimInfo(AnimInfoName);

		if (!Info)
			return;

		Info->SetEndFunction<T>(Obj, Func);
		Info->m_EndFuncOnce = once;
	}

	template <typename T>
	void AddNotify(const std::string& AnimInfoName, int Frame, T* Obj, void(T::* Func)())
	{
		CAnimationInfo* Info = FindAnimInfo(AnimInfoName);

		if (!Info)
			return;

		Info->SetNotify(Frame, Obj, Func);
	}


};

