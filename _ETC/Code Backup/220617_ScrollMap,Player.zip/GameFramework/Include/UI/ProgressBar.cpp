
#include "ProgressBar.h"
#include "WidgetWindow.h"

//�ؽ�ó �ε�
#include "../Resource/Texture/Texture.h"
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"


//HBRUSH �������� �뵵
#include "../GameManager.h"

CProgressBar::CProgressBar()	:
	m_Dir(EProgressBar_Dir::LeftToRight),
	m_Value(1.f),
	m_Padding(10.f)
{
}

CProgressBar::CProgressBar(const CProgressBar& widget) :
	CWidget(widget)
{
}

CProgressBar::~CProgressBar()
{
}



bool CProgressBar::Init()
{
	return true;
}



void CProgressBar::SetBarFrameSize(float SizeX, float SizeY)
{
	m_Size.x = SizeX;
	m_Size.y = SizeY;

	//�е��� �⺻ 10���� ��������.
	SetPadding(10.f);
}

void CProgressBar::SetBarFrameSize(const Vector2& Size)
{
	m_Size = Size;

	SetPadding(10.f);
}

void CProgressBar::SetPadding(float Padding)
{
	//x�� y �� ª�� ���� ������ �����Ͱ� ��.
	float ShortArea = (m_Size.x > m_Size.y ? m_Size.y : m_Size.x) / 2.f;
	m_Padding = Padding;

	//���� �е��� ���̰� ª�� ���� �ݺ��� ��� ������ �е����� �ٿ���
	if (m_Padding > ShortArea)
	{
		m_Padding = ShortArea - 1.f;
	}
}

bool CProgressBar::SetTexture(EProgressBar_TextureType Type, const std::string& Name)
{
	CTexture* Texture = m_Scene->GetSceneResource()->FindTexture(Name);

	if (!Texture)
		return false;

	m_Texture[(int)Type] = Texture;
	return true;
}

void CProgressBar::SetBarDir(EProgressBar_Dir Dir)
{
	m_Dir = Dir;
}

void CProgressBar::SetValue(float Value)
{
	m_Value = Value;

	if (m_Value > 1.f)
		m_Value = 1.f;

	else if (m_Value < 0.f)
		m_Value = 0.f;
}

void CProgressBar::AddValue(float Value)
{
	m_Value += Value;

	if (m_Value > 1.f)
		m_Value = 1.f;

	else if (m_Value < 0.f)
		m_Value = 0.f;
}




void CProgressBar::Update(float DeltaTime)
{

	//���� ����� �ʱ�ȭ�ϰ�
	m_BarPos.LT = m_Pos + m_Padding;
	m_BarPos.RB = m_Pos + m_Size - m_Padding;
	Vector2 m_BarSize = (m_BarPos.RB - m_BarPos.LT) * m_Value;

	//�׷��� ���� �����Ѵ�.
	switch (m_Dir)
	{
	case EProgressBar_Dir::LeftToRight:
		m_BarPos.RB.x = m_BarPos.LT.x + m_BarSize.x;
		break;
	case EProgressBar_Dir::RightToLeft:
		m_BarPos.LT.x = m_BarPos.RB.x - m_BarSize.x;
		break;
	case EProgressBar_Dir::BottomToTop:
		m_BarPos.LT.y = m_BarPos.RB.y - m_BarSize.y;
		break;
	case EProgressBar_Dir::TopToBottom:
		m_BarPos.RB.y = m_BarPos.LT.y + m_BarSize.y;
		break;
	}
}

void CProgressBar::PostUpdate(float DeltaTime)
{
}

void CProgressBar::Render(HDC hDC, float DeltaTime)
{
	
	for (int i = 0; i < (int)EProgressBar_TextureType::End; ++i)
	{
		Vector2	RenderPos;
		Vector2 RenderSize;

		switch ((EProgressBar_TextureType)i)
		{
		case EProgressBar_TextureType::Back:
			RenderPos = m_Pos;
			RenderSize = m_Size;
			break;
		case EProgressBar_TextureType::Bar:
			RenderPos = m_BarPos.LT;
			RenderSize = m_BarPos.RB - m_BarPos.LT;
			break;

		}

		RenderPos += m_Owner->GetPos() + m_Offset;


		if (m_Texture[i])
		{
			Vector2 TexSize = m_Texture[i]->GetTextureSize();

			if (m_Texture[i]->GetTextureType() == ETextureType::Sprite)
			{
				if (m_Texture[i]->GetColorKeyEnable())
				{
					TransparentBlt(hDC, 
						(int)RenderPos.x, (int)RenderPos.y,
						(int)RenderSize.x, (int)RenderSize.y,
						m_Texture[i]->GetDC(),
						0, 0, 
						(int)TexSize.x, (int)TexSize.y,
						m_Texture[i]->GetColorKey());
				}

				else
				{
					StretchBlt(hDC,
						(int)RenderPos.x, (int)RenderPos.y,
						(int)RenderSize.x, (int)RenderSize.y,
						m_Texture[i]->GetDC(),
						0, 0,
						(int)TexSize.x, (int)TexSize.y,
						SRCCOPY);
				}
			}

			else//�������� ���� ó������ ����
			{
			}
		}

		else//�ؽ�ó �������
		{
			//Ʋ�� �����
			HBRUSH Brush = CGameManager::GetInst()->GetBrush(EBrushType::Yellow);

			//�ٴ� ������
			if (i == (int)EProgressBar_TextureType::Bar)
			{
				Brush = CGameManager::GetInst()->GetBrush(EBrushType::Red);
			}

			HBRUSH PrevBrush = (HBRUSH)SelectObject(hDC, Brush);

			Rectangle(hDC,
				(int)RenderPos.x,
				(int)RenderPos.y,
				(int)(RenderPos.x + RenderSize.x),
				(int)(RenderPos.y + RenderSize.y));

			SelectObject(hDC, PrevBrush);

		}
	}
}

void CProgressBar::Render(HDC hDC, const Vector2& Pos, float DeltaTime)
{
}
