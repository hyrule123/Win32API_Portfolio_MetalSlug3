#pragma once
#include "GameObject.h"

class CBullet :
    public CGameObject
{
    friend class CScene;

private:
    float m_Distance;
    bool m_isSet;

    float m_Damage;
    

protected:
    CBullet();
    CBullet(const CBullet& Obj);
    virtual ~CBullet();

public:
    bool Init(CGameObject* Obj = nullptr);
    void Update(float DeltaTime);
    void PostUpdate(float DeltaTime);
    void Render(HDC hDC, float DeltaTime);

    void SetDamage(float Damage);

    
    //â ���� �Ѿ�� �ı�(�ӽ�)
    bool DestroyCheck();

    void SetSpeedDir(float _x, Vector2 Dir);

    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

