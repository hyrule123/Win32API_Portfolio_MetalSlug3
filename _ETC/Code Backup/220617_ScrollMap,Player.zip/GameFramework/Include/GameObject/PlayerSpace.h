#pragma once
#include "Player.h"

//���� �׼�
enum class EAction
{
	IdlePistol,
	IdleRifle,
	AttackPistol,
	AttackRifle,
	ObtainRifle,
	DrolRifle
};


class CPlayerSpace :
	public CPlayer
{
	friend class CScene;

protected:
	std::vector<class CColliderBox*> m_Collider;

	//���� �¿� ����� �ൿ�� �����ϴ� ����(���� �Լ��� �̿��ؼ��� ����)
	int m_CurrentDir;
	int m_CurrentAct;
	bool m_isMoving;
protected:
	void SetCurrentDir(EDirection Dir);
	void SetCurrentAct(EAction Act);



protected:
	CPlayerSpace();
	CPlayerSpace(const CPlayerSpace& Obj);
	virtual ~CPlayerSpace();

public:
	virtual bool Init(CGameObject* Obj = nullptr);
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	virtual float InflictDamage(float Damage);



private:
	void MoveLeft();
	void MoveRight();
	void MoveSideStop();
	void ReturnMid();


	void MoveUp();
	void MoveDown();



	void FireGun();
	void FireBomb();
	void FireNotify();
	void AttackEnd();
};

