#pragma once

#include "Character.h"

class CMonster : public CCharacter
{
	friend class CScene;

protected:
	CMonster();
	CMonster(const CMonster& Obj);
	virtual ~CMonster();
public:
	virtual bool Init(CGameObject* Obj = nullptr);

protected:
	float m_BulletDuration;
	float m_BulletDurationTimer;
	int m_InhancedFireCycle;
	int m_InhancedFireCount;



protected:
	float m_HP;
	float m_HPMax;
public:
	float GetHP()	const;


public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	float InflictDamage(float Damage);

protected:
	void CollBeginMouse(const Vector2& Point, class CCollider* Col);
};