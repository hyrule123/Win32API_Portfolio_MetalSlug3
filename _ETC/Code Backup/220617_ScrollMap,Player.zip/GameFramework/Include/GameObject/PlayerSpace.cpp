#include "PlayerSpace.h"
#include "../GameManager.h"
#include "../input.h"
#include "../Scene/Scene.h"
#include "Bullet.h"

#include "../Scene/SceneResource.h"

//�¿� �ִϸ��̼� ��� ���� �Է� Ȯ�ο�
#include "../Input.h"

//�浹ü
#include "../Collision/ColliderBox.h"




CPlayerSpace::CPlayerSpace():
	m_isMoving(false)
{
	SetTypeID<CPlayerSpace>();
}

CPlayerSpace::CPlayerSpace(const CPlayerSpace& Obj) :
	CPlayer(Obj)
{
}

CPlayerSpace::~CPlayerSpace()
{
	CInput::GetInst()->DeleteBindClass<CPlayerSpace>(this);

}

bool CPlayerSpace::Init(CGameObject* Obj)
{
	CPlayer::Init(Obj);

	//Player�� �ּҸ� CGameManager�� ����Ѵ�.
	CGameManager::GetInst()->SetPlayer(this);


	//��ġ ����
	SetPos(50.f, 50.f);
	SetSize(10.f, 20.f);
	SetDir(1.f, 0.f);
	SetPivot(0.5f, 1.f);
	SetScale(1.f);
	SetSpeed(150.f);



	//�Է� �ʱ�ȭ
	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveLeft", 
		Input_Type::Push,
		this, &CPlayerSpace::MoveLeft);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveRight", 
		Input_Type::Push,
		this, &CPlayerSpace::MoveRight);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveUp", 
		Input_Type::Push,
		this, &CPlayerSpace::MoveUp);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveDown", 
		Input_Type::Push,
		this, &CPlayerSpace::MoveDown);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveLeft", 
		Input_Type::Up,
		this, &CPlayerSpace::MoveSideStop);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("MoveRight", 
		Input_Type::Up,
		this, &CPlayerSpace::MoveSideStop);


	CInput::GetInst()->AddBindFunction<CPlayerSpace>("GunFire", 
		Input_Type::Push,
		this, &CPlayerSpace::FireGun);

	CInput::GetInst()->AddBindFunction<CPlayerSpace>("Bomb", 
		Input_Type::Push,
		this, &CPlayerSpace::FireBomb);




	//��ų ����
	m_SkillCoolTimeSet.resize((size_t)EPlayerSkill::End);
	m_SkillCoolTimeSet[(int)EPlayerSkill::BasicAttack].CoolTime = 0.5f;



	/////////////////// �ִϸ��̼� ���� ///////////////////
	CreateAnimation();

	//���� �ִϸ��̼��� CGameObject�� m_Animation�� ��� ����Ѵ�.
	AddAnimation("PlayerSpace_Mid_Idle_Pistol", 
		"PlayerSpace_Mid_Idle_Pistol");
	vecDirectionPushBack(EDirection::Mid, "PlayerSpace_Mid_Idle_Pistol");


	//���� �̵� & �����(���ڸ��� ���ƿ��� ���
	AddAnimation(
		"PlayerSpace_Left_Idle_Pistol", 
		"PlayerSpace_Left_Idle_Pistol", 
		false, 0.2f);
	vecDirectionPushBack(EDirection::Left, 
		"PlayerSpace_Left_Idle_Pistol");

	
	
	//���� �̵� & �����
	AddAnimation(
		"PlayerSpace_Right_Idle_Pistol", 
		"PlayerSpace_Right_Idle_Pistol", 
		false, 0.2f);
	vecDirectionPushBack(EDirection::Right, "PlayerSpace_Right_Idle_Pistol");

	//���� ���� ���� �ڼ��� �߰� �������Ƿ�
	SetCurrentAct(EAction::IdlePistol);

	////�浹ü ����
	//m_Collider = AddCollider<CColliderBox>("PlayerBox");
	//m_Collider->SetCollisionProfile(ECollisionChannel::Player);



	return true;
}


void CPlayerSpace::SetCurrentDir(EDirection Dir)
{
	m_CurrentDir = (int)Dir;
}

void CPlayerSpace::SetCurrentAct(EAction Act)
{
	m_CurrentAct = (int)Act;
}



void CPlayerSpace::Update(float DeltaTime)
{
	CPlayer::Update(DeltaTime);
}

void CPlayerSpace::PostUpdate(float DeltaTime)
{
	CPlayer::PostUpdate(DeltaTime);
}

void CPlayerSpace::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);

}


float CPlayerSpace::InflictDamage(float Damage)
{
	CCharacter::InflictDamage(Damage);

	return Damage;
}




void CPlayerSpace::MoveLeft()
{
	SetCurrentDir(EDirection::Left);
	ChangeAnimation(m_vecDirection
		[m_CurrentDir][m_CurrentAct]);
	SetDir(-1.f, 0.f);
	MoveDir(m_Dir);

}

void CPlayerSpace::MoveRight()
{
	SetCurrentDir(EDirection::Right);
	ChangeAnimation(m_vecDirection
		[m_CurrentDir][m_CurrentAct]);
	SetDir(1.f, 0.f);
	MoveDir(m_Dir);

}

void CPlayerSpace::MoveSideStop()
{
	//Ȥ�ó� ����Ű�� ������ �ִ� ���¶�� ����ġ�� ���ư��� �ִϸ��̼��� 
	//������� �ʴ´�.
	if (
		CInput::GetInst()->FindKeyState(VK_LEFT)->Push ||
		CInput::GetInst()->FindKeyState(VK_RIGHT)->Push
		)
		return;

	//1ȸ ����� ����
	m_Animation->SetPlayReverse
	(m_vecDirection[m_CurrentDir][m_CurrentAct], true, true);

	//1ȸ EndFunction ����
	m_Animation->SetEndFunction<CPlayerSpace>(
		m_vecDirection[m_CurrentDir][m_CurrentAct], this,
		&CPlayerSpace::ReturnMid
		, true);

	m_Animation->PlayCurrentAnimAgain();
	
	m_Dir.x = 0.f;
}

void CPlayerSpace::ReturnMid()
{
	
	SetCurrentDir(EDirection::Mid);
	ChangeAnimation(m_vecDirection[m_CurrentDir][m_CurrentAct]);
	
}


void CPlayerSpace::MoveUp()
{
	SetDir(0.f, -1.f);
	MoveDir(m_Dir);
}

void CPlayerSpace::MoveDown()
{
	SetDir(0.f, 1.f);
	MoveDir(m_Dir);
}

void CPlayerSpace::FireGun()
{
	//��Ÿ���̸� �׳� return
	if (m_SkillCoolTimeSet[(int)EPlayerSkill::BasicAttack].isCoolTime)
		return;

	//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ�
	EnterSkillCoolTIme((int)EPlayerSkill::BasicAttack);


	//���� �ִϸ��̼� ȣ��!(���� �Ѿ� �߻�� FireNotify���� ����)
	//ChangeAnimation(m_vecDirection[m_isRightDir][2]);
}

void CPlayerSpace::FireBomb()
{
}

void CPlayerSpace::FireNotify()
{
	//��ų ���� ����
	CBullet* Bullet = m_Scene->CreateObject<CBullet>("PlayerBullet", this);
	Bullet->SetSpeedDir(1000.f, m_Dir);
	Bullet->SetPos(m_Pos);
	Bullet->SetDamage(20.f);
}

void CPlayerSpace::AttackEnd()
{
	//ChangeAnimation(m_vecDirection[m_isRightDir][0]);
}
