#include "Monster.h"
#include "Bullet.h"
#include "../Scene/SceneManager.h"
#include "../GameManager.h"
#include "../GameObject/Player.h"


//���ҽ� �ε�
#include "../Scene/SceneResource.h"
#include "../Resource/Texture/Texture.h"


//����Ʈ
#include "Effect.h"

//�浹ü
#include "../Collision/ColliderBox.h"
#include "../Collision/ColliderCircle.h"

//��ġ ��� ī�޶�
#include "../Scene/Camera.h"

//���� ������Ʈ
#include "../UI/WidgetComponent.h"

//ü�¹�, ü�� ����
#include "../UI/ProgressBar.h"
#include "../UI/WidgetNumber.h"


CMonster::CMonster() :
	m_BulletDuration(1.f),
	m_BulletDurationTimer(0.f),
	m_InhancedFireCycle(3),
	m_InhancedFireCount(0),
	m_HP(100),
	m_HPMax(m_HP)
{
	SetTypeID<CMonster>();
}

CMonster::CMonster(const CMonster& Obj):
	CCharacter(Obj),
	m_BulletDuration(Obj.m_BulletDuration),
	m_BulletDurationTimer(Obj.m_BulletDurationTimer),
	m_InhancedFireCycle(Obj.m_InhancedFireCycle),
	m_InhancedFireCount(Obj.m_InhancedFireCount)
{
}

CMonster::~CMonster()
{
}

bool CMonster::Init(CGameObject* Obj)
{
	CCharacter::Init(Obj);

	SetTexture("Monster", TEXT("pepe.bmp"));
	SetColorKey();

	m_Dir = Vector2(0.f, 1.f);
	m_Speed = 400.f;
	m_BulletDuration = 0.3f;
	m_BulletDurationTimer = 0.f;
	m_InhancedFireCycle = 3;
	m_InhancedFireCount = 0;

	SetPos(200.f, 170.f);
	SetSize(50.f, 50.f);
	SetPivot(0.5f, 0.5f);
	SetScale(1.f);

	//�浹ü ����
	//CColliderBox* Coll = AddCollider<CColliderBox>("MonsterBox");
	//Coll->SetCollisionProfile(ECollisionChannel::Monster);
	//Coll->SetExtent(m_Size.x, m_Size.y);
	////Coll->SetOffset(Vector2(10.f, 10.f));
	CColliderCircle* Coll = AddCollider<CColliderCircle>("MonsterBox");
	Coll->SetCollisionProfile(ECollisionChannel::Monster);
	Coll->SetRadius(m_Size.x * m_Pivot.x);
	//Coll->SetOffset(Vector2(10.f, 10.f));
	Coll->SetCollisionBeginMouse(this, &CMonster::CollBeginMouse);


	//���� ������Ʈ ����
	CreateWidgetComponent();
	CProgressBar* HPBar = m_WidgetComponent->CreateWidget<CProgressBar>("MonsterHPBar");

	HPBar->SetBarFrameSize(40.f, 20.f);
	HPBar->SetPadding(3.f);
	HPBar->SetOffset(-20.f, -40.f);

	m_Scene->GetSceneResource()->LoadTexture("BarBack", TEXT("Bar/BarBack.bmp"));
	HPBar->SetTexture(EProgressBar_TextureType::Back, "BarBack");

	m_Scene->GetSceneResource()->LoadTexture("Bar", TEXT("Bar/BarDefault.bmp"));
	HPBar->SetTexture(EProgressBar_TextureType::Bar, "Bar");


	//�������� �߰� ����//////////////////////////////////////////
	CWidgetNumber* Number = m_WidgetComponent->CreateWidget<CWidgetNumber>("MonsterHPNum");
	//�ִϸ��̼� �ε�
	m_Scene->GetSceneResource()->CreateAnimationSequence("Number", "Number", TEXT("UI/Number.bmp"));
	//�÷�Ű�� ����
	m_Scene->GetSceneResource()->SetColorKey("Number", 163, 73, 164);
	
	//���� ��������Ʈ ��ǥ �߰�
	for (int i = 0; i < 10; ++i)
	{
		m_Scene->GetSceneResource()->AddAnimationSpriteFrame("Number",
			i * 17.f, 0.f, 16.f, 16.f);
	}
	//WidgetNumber Ŭ������ �ѹ� �̹����� ���.
	Number->SetNumberImage("Number");
	Number->SetScale(1.f);

	//������ ��ġ + 100 ��ġ�� �׷���
	Number->SetOffset(-20.f, 30.f);
	///////////////////////////////////////////////////////////////


	return true;
}

float CMonster::GetHP() const
{
	return m_HP;
}

void CMonster::Update(float DeltaTime)
{
	CCharacter::Update(DeltaTime);

	//m_Dir�� -1�� �����ټ��� ������, Ȥ�ó� ��� ������ �������� �з�����
	//��� ��ġ�� 0 ���ϰ� �Ǿ� -1 ���ϱ⸦ �ݺ��ؼ� ���ڸ����� ������ ������ �߻��Ҽ��� �ִ�.
	if (m_Pos.y - (m_Size.y * m_Pivot.y) <= 500)
		m_Dir = Vector2(0.f, 1.f);
	else if (m_Pos.y + (m_Size.y * m_Pivot.y) >= 1000)
		m_Dir = Vector2(0.f, -1.f);


	//���� �̵�
	//MoveDir(m_Dir);

}

void CMonster::PostUpdate(float DeltaTime)
{
	CCharacter::PostUpdate(DeltaTime);

	//ü�� Ȯ��
	if (m_HP <= 0.f)
		SetActive(false);



	m_WidgetComponent->FindWidget<CProgressBar>("MonsterHPBar")->SetValue(m_HP / m_HPMax);
	m_WidgetComponent->FindWidget<CWidgetNumber>("MonsterHPNum")->SetNumber((int)m_HP);

	m_BulletDurationTimer += DeltaTime;
	if (m_BulletDurationTimer > m_BulletDuration)
	{
		CBullet* Bullet = CSceneManager::GetInst()->GetScene()->CreateObject<CBullet>("Bullet", this);

		Bullet->SetDamage(20.f);
		Bullet->SetSpeedDir(1000.f, Vector2(-1.f, 0.f));

		++m_InhancedFireCount;
		if (m_InhancedFireCount == m_InhancedFireCycle)
		{

			CGameObject* Player = m_Scene->FindObject("Player");

			if (Player)
			{
				float angle = m_Pos.Angle(Player->GetPos());
				Vector2 Dir;
				Dir.x = cosf(angle);
				Dir.y = sinf(angle);

				Bullet->SetSpeedDir(1000.f, Dir);
			}

			m_InhancedFireCount = 0;
		}

		Bullet->SetPos(m_Pos);

		m_BulletDurationTimer = 0.f;
	}



}

void CMonster::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);
}


float CMonster::InflictDamage(float Damage)
{
	float DMG = CCharacter::InflictDamage(Damage);

	m_HP -= DMG;

	return DMG;
}

void CMonster::CollBeginMouse(const Vector2& Point, CCollider* Col)
{
	CEffect* Effect = m_Scene->CreateObject<CEffect>("BulletSFX");

	Effect->AddAnimation("BulletSFX", "BulletSFX", true, 0.2f);
	Effect->SetRenderLayer(ERenderLayer::Effect);

	Effect->SetPivot(0.5f, 0.5f);
	Effect->SetPos(Point);

}
