#pragma once

#include "Widget.h"

enum class EProgressBar_TextureType
{
    Back,
    Bar,
    End
};

enum class EProgressBar_Dir
{
    LeftToRight,
    RightToLeft,
    BottomToTop,
    TopToBottom,
    End
};

class CProgressBar :
    public CWidget
{
    friend class CWidgetWindow;

protected:
    CProgressBar();
    CProgressBar(const CProgressBar& widget);
    virtual ~CProgressBar();

protected:
    CSharedPtr<class CTexture>  m_Texture[(int)EProgressBar_TextureType::End];
    EProgressBar_Dir    m_Dir;
    float               m_Value;    // 0 ~ 1 ������ ��

    //���� ���� ǥ�� ��ġ
    BoxInfo             m_BarPos;


protected:
    //�е�
    float m_Padding;
public:
    //���� ���� �е�(Ʋ�� ���� ���� ����)
    void SetPadding(float Padding);


public:
    //���α׷��� �� Ʋ�� ������.
    void SetBarFrameSize(float SizeX, float SizeY);
    void SetBarFrameSize(const Vector2& Size);



    bool SetTexture(EProgressBar_TextureType Type, const std::string& Name);
    void SetBarDir(EProgressBar_Dir Dir);
    void SetValue(float Value);
    void AddValue(float Value);



public:
    virtual bool Init();
    virtual void Update(float DeltaTime);
    virtual void PostUpdate(float DeltaTime);
    virtual void Render(HDC hDC, float DeltaTime);
    virtual void Render(HDC hDC, const Vector2& Pos, float DeltaTime);
};

