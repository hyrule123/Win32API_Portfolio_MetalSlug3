#include "Explosion.h"

#include "../Scene/Scene.h"

CExplosion::CExplosion():
	m_SizeName{}
{
	SetTypeID<CExplosion>();
}

CExplosion::CExplosion(const CExplosion& Obj) :
	CEffect(Obj),
	m_SizeName{}
{
	//���� �ܰ迡�� �����Ǵ� ����
	//bool m_isReady;
}

CExplosion::~CExplosion()
{
}

bool CExplosion::LoadResource()
{
	CEffect::LoadResource();

	if (!LoadCSVPreset(TEXT("SFX/Explosion.csv")))
		return false;

	m_SizeName[(int)EExplosionSize::Small] = "Rocket_SmallExplosion";
	m_SizeName[(int)EExplosionSize::Midium] = "Rocket_MidExplosion";
	m_SizeName[(int)EExplosionSize::Big] = "Rocket_BigExplosion";

	return true;
}

bool CExplosion::Init(CGameObject* Obj)
{
	CEffect::Init(Obj);

	if (!m_Animation->FindAnimInfo(m_Name))
		return false;

	SetAnimation(m_Name);

	if (m_Name == "BigExplosion")
		m_RenderLayer = ERenderLayer::EffectHigh;

	m_isReady = true;
	return true;
}

bool CExplosion::SetSFX(const std::string& Name)
{
	if (!m_Animation->FindAnimInfo(Name))
		return false;

	SetAnimation(Name);

	m_isReady = true;

	return true;
}


void CExplosion::Update(float DeltaTime)
{
	CEffect::Update(DeltaTime);

	if (!m_isReady)
		SetActive(false);
}

void CExplosion::PostUpdate(float DeltaTime)
{
	CEffect::PostUpdate(DeltaTime);
}

void CExplosion::Render(HDC hDC, float DeltaTime)
{
	CEffect::Render(hDC, DeltaTime);
}
