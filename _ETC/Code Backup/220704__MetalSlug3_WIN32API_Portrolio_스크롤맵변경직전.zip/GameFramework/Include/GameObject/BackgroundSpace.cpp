#include "BackgroundSpace.h"

//�ؽ�ó �ּ� ������� �뵵
#include "../Scene/Scene.h"
#include "../Scene/SceneResource.h"
#include "../Resource/Texture/Texture.h"


CBackgroundSpace::CBackgroundSpace()
{
}

CBackgroundSpace::~CBackgroundSpace()
{
}

bool CBackgroundSpace::Init(CGameObject* Obj)
{
	SetTexture("BackgroundSpace", TEXT("Background/SpaceBackground.bmp"));
	m_Texture = m_Scene->GetSceneResource()->FindTexture("BackgroundSpace");
	SetSize(m_Texture->GetTextureSize());

	return true;
}

void CBackgroundSpace::Start()
{
	CBackground::Start();
}

void CBackgroundSpace::Update(float DeltaTime)
{
	CBackground::Update(DeltaTime);
}

void CBackgroundSpace::Render(HDC hDC, float DeltaTime)
{
	if (!m_Start)
		Start();

	if (m_Texture)
	{
		Vector2 Res = m_Scene->GetCamRes();
		Vector2	Pos = m_Scene->GetCamPos();

		//����� �̹����� '�κ�' ���
		int Top = (int)Pos.y % (int)m_Size.y;
		int Bottom = (int)(Pos.y + Res.y) % (int)m_Size.y;
		int Split = (int)Res.y - Bottom;


		//ī�޶� �̹��� ������ ������ �ʾ��� ���� �ѹ��� ���
		if (Split < 0)
		{
			if (m_Texture->GetColorKeyEnable())
			{
				TransparentBlt(hDC,
					0, 0,
					(int)Res.x, Bottom,
					m_Texture->GetDC(),
					0, Top,
					(int)Res.x, Bottom,
					m_Texture->GetColorKey());

			}
			else
			{
				StretchBlt(hDC,
					0, 0,
					(int)Res.x, Bottom,
					m_Texture->GetDC(),
					0, Top,
					(int)Res.x, Bottom,
					SRCCOPY);
			}
		}

		//ī�޶� �̹��� ������ ������ ���� �߸� �κи�ŭ ������ ���ͼ�
		//2�� ���
		else
		{
			if (m_Texture->GetColorKeyEnable())
			{
				TransparentBlt(hDC,
					0, 0,
					(int)Res.x, Split,
					m_Texture->GetDC(),
					0, Top,
					(int)Res.x, Split,
					m_Texture->GetColorKey());

				TransparentBlt(hDC,
					0, Split,
					(int)Res.x, Bottom,
					m_Texture->GetDC(),
					0, 0,
					(int)Res.x, Bottom,
					m_Texture->GetColorKey());
			}
			else
			{
				StretchBlt(hDC,
					0, 0,
					(int)Res.x, Split,
					m_Texture->GetDC(),
					0, Top,
					(int)Res.x, Split,
					SRCCOPY);

				StretchBlt(hDC,
					0, Split,
					(int)Res.x, Bottom,
					m_Texture->GetDC(),
					0, 0,
					(int)Res.x, Bottom,
					SRCCOPY);
			}
		}
	}
}

void CBackgroundSpace::SetSpeed(float ScrollingSpeed)
{
	float m_ScrollingSpeed = ScrollingSpeed;
}
