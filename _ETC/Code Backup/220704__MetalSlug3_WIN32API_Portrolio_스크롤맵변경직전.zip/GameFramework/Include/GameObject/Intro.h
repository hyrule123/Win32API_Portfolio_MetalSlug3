#pragma once
#include "GameObject.h"
class CIntro :
    public CGameObject
{
};

