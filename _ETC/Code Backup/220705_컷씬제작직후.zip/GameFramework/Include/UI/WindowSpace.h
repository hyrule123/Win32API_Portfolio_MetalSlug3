#pragma once
#include "WidgetWindow.h"
class CWindowSpace :
    public CWidgetWindow
{
    friend class CScene;

protected:
//    CWindowSpace();
//    virtual ~CWindowSpace();
//public:
//    virtual bool Init();
};

