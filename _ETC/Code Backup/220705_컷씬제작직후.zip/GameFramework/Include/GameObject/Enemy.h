#pragma once

#include "Character.h"

class CEnemy : public CCharacter
{
	friend class CScene;

protected:
	CEnemy();
	CEnemy(const CEnemy& Obj);
	virtual ~CEnemy();
public:
	virtual bool Init(CGameObject* Obj = nullptr);


public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	int InflictDamage(int Damage);

protected:
	void CollBeginMouse(const Vector2& Point, class CCollider* Col);
};