#include "Enemy.h"

CEnemy::CEnemy()
{
	SetTypeID<CEnemy>();
}

CEnemy::CEnemy(const CEnemy& Obj):
	CCharacter(Obj)
{
}

CEnemy::~CEnemy()
{
}

bool CEnemy::Init(CGameObject* Obj)
{
	CCharacter::Init(Obj);

	SetRenderLayer(ERenderLayer::Enemy);

	return true;
}


void CEnemy::Update(float DeltaTime)
{
	CCharacter::Update(DeltaTime);
}

void CEnemy::PostUpdate(float DeltaTime)
{
	CCharacter::PostUpdate(DeltaTime);

	////ü�� Ȯ��
	//if (m_HP <= 0.f)
	//	SetActive(false);

}

void CEnemy::Render(HDC hDC, float DeltaTime)
{
	CCharacter::Render(hDC, DeltaTime);
}


int CEnemy::InflictDamage(int Damage)
{
	int DMG = CCharacter::InflictDamage(Damage);

	m_HP -= DMG;

	return DMG;
}

void CEnemy::CollBeginMouse(const Vector2& Point, CCollider* Col)
{

}
