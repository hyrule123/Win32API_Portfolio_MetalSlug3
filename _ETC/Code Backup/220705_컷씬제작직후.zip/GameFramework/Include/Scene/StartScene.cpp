#include "StartScene.h"
#include "../Input.h"


#include "SceneResource.h"


//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"

//���ȭ��
#include "../GameObject\Background.h"

#include "../UI/WindowStart.h"


//ī�޶�

CStartScene::CStartScene()
{
}

CStartScene::~CStartScene()
{
	GetSceneResource()->SoundStop("MainTheme");
}

bool CStartScene::Init()
{
	CScene::Init();


	CreateObject<CBackground>("BackGround");



	////���� ���
	//GetSceneResource()->LoadSound("SFX", "MainTheme", true, "MS3_Into_The_Cosmos.mp3");
	//GetSceneResource()->SetMasterVolume(10);
	//GetSceneResource()->SoundPlay("MainTheme");



	//������ ȣ��
	CreateWidgetWindow<CWindowStart>("WindowStart");



	return true;
}


