#include "MainScene.h"
#include "../Input.h"

//����ϴ� ���ӿ�����Ʈ
#include "../GameObject/AstroSlug.h"
#include "../GameObject/AstroSlugSFX.h"
#include "../GameObject/PlayerSpace.h"
#include "../GameObject/Explosion.h"
#include "../GameObject/Enemy.h"
#include "../GameObject/UFO.h"
#include "../GameObject/BackgroundSpace.h"
#include "../GameObject/PistolHit.h"
#include "../GameObject/Shotgun.h"
#include "../GameObject/AstroBomb.h"
#include "../GameObject/Pistol.h"
#include "../GameObject/RocketLauncher.h"
#include "../GameObject/Laser.h"
#include "../GameObject/AstroHMG.h"
#include "../GameObject/PlayerHMG.h"
#include "../GameObject/SpaceIntro.h"
#include "../GameObject/JustPlay.h"
#include "../GameObject/BackObjects.h"
#include "../GameObject/Meteor.h"
#include "../GameObject/MeteorSmall.h"
#include "../GameObject/MeteorMid.h"
#include "../GameObject/MeteorBig.h"
#include "../GameObject/ProjectileEnemy.h"



//����ϴ� UI
#include "../UI/WindowSpace.h"
#include "../UI/WidgetFadeInOut.h"

#include "SceneResource.h"

//Camera ó��
#include "Camera.h"

//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"

#include "../GameObject/DaiManji.h"


CMainScene::CMainScene():
	m_BackGround(),
	m_PhaseFlags(),
	m_Counter(),
	m_Timer0(),
	m_Timer1(),
	m_Timer2(),
	m_KeyMonsterCounter(),
	m_FirstPhaseEnter(true)
{
}

CMainScene::~CMainScene()
{
}

bool CMainScene::Init()
{
	CScene::Init();




	//ī�޶� �غ�
	GetCamera()->SetRes((float)ORIGINAL_GAME_RES_WIDTH, 
		(float)ORIGINAL_GAME_RES_HEIGHT);
	GetCamera()->SetWorldRes(ORIGINAL_GAME_RES_WIDTH, 
		ORIGINAL_GAME_RES_HEIGHT * 2.f);
	GetCamera()->SetTargetPivot(0.5f, 0.8f);

	//����
	CWindowSpace* WindowSpace = CreateWidgetWindow<CWindowSpace>("WindowSpace");



	//��׶��� 
	m_BackGround = CreateObject<CBackgroundSpace>("BackGround");
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontSilver.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontGold.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/TimeNumber.csv"));


	//���� ���
	GetSceneResource()->LoadSound("SFX", "MainTheme", true, "MS3_Into_The_Cosmos.mp3");
	
	//���ҽ� �̸� �ε� - �ؽ�ó
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontSilver.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/BasicFontGold.csv"));
	m_SceneResource->LoadCSVPreset(TEXT("UI/ScoreNumber.csv"));
	m_SceneResource->LoadTexture("AmmoHUD", TEXT("UI/AmmoHUD.bmp"));
	m_SceneResource->SetColorKey("AmmoHUD");

	//���ҽ� - ����
	m_SceneResource->LoadSound("SFX", "Separation", false, "Intro/Separation.mp3");
	m_SceneResource->LoadSound("SFX", "NoseOpen", false, "Intro/NoseOpen.mp3");
	m_SceneResource->LoadSound("SFX", "AstroThrust", false, "Intro/AstroThrust.mp3");
	m_SceneResource->LoadSound("SFX", "LowPitchThrust", false, "Intro/LowPitchThrust.mp3");
	


	


	CreateOriginalObj<CPlayerSpace>("PlayerSpace");
	CreateOriginalObj<CAstroSlug>("AstroSlug");
	CreateOriginalObj<CAstroSlugSFX>("AstroSlugSFX");
	CreateOriginalObj<CExplosion>("Explosion");
	CreateOriginalObj<CPistolHit>("PistolHit");
	CreateOriginalObj<CShotgun>("Shotgun");
	CreateOriginalObj<CPistol>("Pistol");
	CreateOriginalObj<CRocketLauncher>("RocketLauncher");
	CreateOriginalObj<CAstroBomb>("AstroBomb");
	CreateOriginalObj<CLaser>("Laser");
	CreateOriginalObj<CPlayerHMG>("PlayerHMG");
	CreateOriginalObj<CAstroHMG>("AstroHMG");
	CreateOriginalObj<CUFO>("UFO");
	CreateOriginalObj<CSpaceIntro>("SpaceIntro");
	CreateOriginalObj<CJustPlay>("JustPlay");
	CreateOriginalObj<CMeteor>("Meteor");
	CreateOriginalObj<CMeteorSmall>("Meteor");
	CreateOriginalObj<CMeteorMid>("MeteorMid");
	CreateOriginalObj<CMeteorBig>("MeteorBig");
	CreateOriginalObj< CProjectileEnemy>("ProjectileEnemy");

	CreateObject<CSpaceIntro>("SpaceIntro");


	
	//0������ �غ�
	m_Timer0.InitCooltime(0.3f);
	m_Timer0.EnterCooltime();
	m_Timer1.InitCooltime(0.5f);


	
	//CAstroSlug* Player = CreateObject<CAstroSlug>("AstroSlug");
	//CPlayerSpace* Player = CreateObject<CPlayerSpace>("PlayerSpace");

	////GetCamera()->SetTargetObj(Player);
	//Player->SetPhysicsSimulate(false);
	//Player->SetPos(100.f, 100.f);



	////���� ����
	//CEnemy* Enemy = CreateObject<CEnemy>("Enemy");
	//Enemy->SetPos(200.f, 200.f);
	
	////CreateWidgetWindow<CWindowEnemyHP>("EnemyHPBarWindow");


	



	return true;
}

void CMainScene::Update(float DeltaTime)
{
	CScene::Update(DeltaTime);

	PhaseUpdate(DeltaTime);

	if (m_PhaseFlags)
	{
		//������ 0���� ���ּ� �ټ� ����
		if (m_PhaseFlags <= ESPhase5_UFOPhase2)
		{
			m_Timer1.UpdateCooltime(DeltaTime);
			if (m_Timer1.EnterCooltime())
			{
				int RandObjType = rand() % 4;
				CBackObjects* Obj = CreateObject<CBackObjects>("BackObj");
				Obj->SetEssential((EBackObjType)RandObjType);
			}
		}

		if(m_PhaseFlags <= ESPhase11_BigMeteor3 && m_PhaseFlags > ESPhase5_UFOPhase2)
		{
			m_Timer1.UpdateCooltime(DeltaTime);
			if (m_Timer1.EnterCooltime())
			{
				CMeteorSmall* Meteor = CreateObject< CMeteorSmall>("MeteorSmall");
			}

			if (m_PhaseFlags < ESPhase8_BigMeteor0)
			{
				m_Timer2.UpdateCooltime(DeltaTime);
				if (m_Timer2.EnterCooltime())
				{
					CMeteorMid* Mid = CreateObject<CMeteorMid>("MeteorMid");
					++m_Counter;
					if (m_Counter == 6)
					{
						Mid->SetItemDrop(EItemList::HMG);
					}
					else if (m_Counter % 5 == 0)
					{
						int RandItem = rand() % 15 + 6;
						Mid->SetItemDrop((EItemList)RandItem);
					}
				}
			}
		}
		//else if ()
	}
}

void CMainScene::PostUpdate(float DeltaTime)
{
	CScene::PostUpdate(DeltaTime);
}

void CMainScene::Render(HDC hDC, float DeltaTime)
{
	CScene::Render(hDC, DeltaTime);
}


void CMainScene::PhaseUpdate(float DeltaTime)
{
	if (!m_PhaseFlags)
		return;

	switch (m_PhaseFlags)
	{
	case ESPhase1_Wait:
	{
		//��Ÿ�� ������Ʈ�� ���༭ ���� ȿ���� ����
		if (!m_Timer0.UpdateCooltime(DeltaTime))
		{

		}
		else//1������ �� �׽�Ʈ ����
		{
			CDaiManji* Dai = CreateObject<CDaiManji>("DaiManji");
			Dai->SetEssential(150.f);

			GotoNextPhase();
		}
			
		break;
	}
	case ESPhase2_Wait:
		m_Timer0.InitCooltime(3.f);
		break;
	case ESPhase3_Wait:
		if (m_Timer0.UpdateCooltime(DeltaTime))
			GotoNextPhase();
		break;
	case ESPhase4_UFOSpawn1:
	{
		if (CheckFirstEnter())
		{
			//Ű���� 1����
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
			{
				UFO->SetKeyMonster();
				UFO->SetItemDrop(EItemList::HMG);
			}

			m_KeyMonsterCounter = 1;
		}
		break;
	}
	case ESPhase5_UFOPhase2://Ű���� ������ �Ѿ��
	{
		if (CheckFirstEnter())
		{
			//Ű���� 2���� �����ϰ� ���������� �̵�.
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO2");
			if (UFO)
				UFO->SetKeyMonster();

			m_KeyMonsterCounter = 2;


		}
	}
	break;
	case ESPhase6_1_Wait:
	{
		if (CheckFirstEnter())
		{

			m_Timer0.InitCooltime(5.f);	//������ �Ѿ������ Ÿ�̸�

		}

		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
	}
		break;
	case ESPhase7_Meteor://� ������
	{
		if (CheckFirstEnter())
		{
			//�̹� ������ Ÿ�̸� ����
			m_Timer0.InitCooltime(30.f);	//������ �Ѿ������ Ÿ�̸�
			m_Timer0.EnterCooltime();
			m_Timer1.InitCooltime(0.3f);	//����� ������ Ÿ�̸�
			m_Timer2.InitCooltime(0.5f);	//���� � ������ Ÿ�Ӹ�
			m_Counter = 0;					//Ư�� ��° ���� ��� ������ ���
		}
		
		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
	}
		break;

	case ESPhase8_BigMeteor0://���� � ������
	{
		if (CheckFirstEnter())
		{
			m_Timer0.InitCooltime(3.f);
			m_Timer0.EnterCooltime();

			CMeteorBig* Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(170.f, 170.f);
				Meteor->SetItemDrop(EItemList::Laser);
			}
		}

		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
		break;
	}
	
	case ESPhase9_BigMeteor1://���� � ������
	{
		if (CheckFirstEnter())
		{
			m_Timer0.InitCooltime(5.f);
			m_Timer0.EnterCooltime();

			CMeteorBig* Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(70.f, 70.f);
			}

			Meteor = nullptr;
			Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(260.f, 260.f);
			}
		}

		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
		break;
	}
	case ESPhase10_BigMeteor2://���� � ������
	{
		if (CheckFirstEnter())
		{
			m_Timer0.InitCooltime(5.f);
			m_Timer0.EnterCooltime();

			CMeteorBig* Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(170.f, 170.f);
				Meteor->SetItemDrop(EItemList::Gas);
			}
		}

		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
		break;
	}
	case ESPhase11_BigMeteor3://���� � ������ ������
	{
		if (CheckFirstEnter())
		{
			m_Timer0.InitCooltime(30.f);
			m_Timer0.EnterCooltime();

			CMeteorBig* Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(50.f, 50.f);
				Meteor->SetItemDrop(EItemList::Gas);
			}

			Meteor = nullptr;
			Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(150.f, 150.f);
				Meteor->SetItemDrop(EItemList::Bomb);
			}

			Meteor = nullptr;
			Meteor = CreateObject< CMeteorBig>("Meteor");
			if (Meteor)
			{
				Meteor->SetEssential(250.f, 250.f);
				Meteor->SetItemDrop(EItemList::Rocket);
			}
		}

		if (m_Timer0.UpdateCooltime(DeltaTime))
		{
			GotoNextPhase();
		}
		break;
	}
	case ESPhase12_UFO0:
	{
		if (CheckFirstEnter())
		{
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
			{
				UFO->SetKeyMonster();
			}

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO2");
			if (UFO)
			{
				UFO->SetKeyMonster();
			}

			m_KeyMonsterCounter = 2;
		}
		break;
	}
	case ESPhase13_UFO1:
	{
		if (CheckFirstEnter())
		{
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
			{
				UFO->SetKeyMonster();
			}


			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO2");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO3");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO4");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO5");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO6");

			m_KeyMonsterCounter = 2;
		}
		break;
	}
	case ESPhase14_UFO2:
	{
		if (CheckFirstEnter())
		{
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
				UFO->SetKeyMonster();


			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO2");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO3");
			if (UFO)
				UFO->SetKeyMonster();


			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO4");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO5");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO6");

			m_KeyMonsterCounter = 3;
		}
		break;
	}

	case ESPhase15_UFO3:
	{
		if (CheckFirstEnter())
		{
			CUFO* UFO = CreateObject<CUFO>("UFO1");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO2");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO3");
			if (UFO)
				UFO->SetKeyMonster();

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO4");
			if (UFO)
			{
				UFO->SetKeyMonster();
				UFO->SetItemDrop(EItemList::Shotgun);
			}
				

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO5");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO6");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO7");

			UFO = nullptr;
			UFO = CreateObject<CUFO>("UFO8");

			m_KeyMonsterCounter = 4;
		}
	}
	break;

	case ESPhase16_Meteor:
	{
		if(CheckFirstEnter())
		{
			m_Timer0.InitCooltime(30.f);
			m_Timer1.InitCooltime(0.5f);
			m_Timer2.InitCooltime(0.3f);
			
		}

		if (m_Timer0.UpdateCooltime(DeltaTime))//�̰� ������ �����������
			GotoNextPhase();

		m_Timer1.UpdateCooltime(DeltaTime);
		if (m_Timer1.EnterCooltime())
		{
			CMeteorSmall* Meteor = CreateObject< CMeteorSmall>("MeteorSmall");
		}

		m_Timer2.UpdateCooltime(DeltaTime);
		if (m_Timer2.EnterCooltime())
		{
			CMeteorMid* Mid = CreateObject<CMeteorMid>("MeteorMid");
			++m_Counter;
			if (m_Counter == 6)
			{
				Mid->SetItemDrop(EItemList::HMG);
			}
			else if (m_Counter % 5 == 0)
			{
				int RandItem = rand() % 15 + 6;
				Mid->SetItemDrop((EItemList)RandItem);
			}
		}
		break;
	}




	}

}




void CMainScene::GotoNextPhase()
{
	++m_PhaseFlags;
	m_FirstPhaseEnter = true;
	m_Counter = 0;
}

bool CMainScene::CheckFirstEnter()
{
	if (m_FirstPhaseEnter)
	{
		m_FirstPhaseEnter = false;
		return true;
	}

	return false;
}

void CMainScene::AddMiniUFOCounter(int Num)
{
	m_MiniUFOCounter += Num;
}

int CMainScene::GetMiniUFOCounter() const
{
	return m_MiniUFOCounter;
}


void CMainScene::SetScrollMapSpeed(float Speed)
{
	if(m_BackGround)
		m_BackGround->SetSpeed(Speed);
}

void CMainScene::SetScrollMapSpeedSoft(float AdjustSpeed, float SpeedPerSec)
{
	if (m_BackGround)
		m_BackGround->SetSpeedSoft(AdjustSpeed, SpeedPerSec);
}

void CMainScene::KeyMonsterDead()
{
	--m_KeyMonsterCounter;
	if (m_KeyMonsterCounter <= 0)
		GotoNextPhase();
}




