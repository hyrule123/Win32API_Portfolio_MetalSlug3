#pragma once

#include "Scene.h"

enum ESpacePhase
{
    ESPhase0,
    ESPhase1_Wait,
    ESPhase2_Wait,
    ESPhase3_Wait,
    ESPhase4_UFOSpawn1,
    ESPhase5_UFOPhase2,
    ESPhase6_1_Wait,
    ESPhase7_Meteor,
    ESPhase8_BigMeteor0,
    ESPhase9_BigMeteor1,
    ESPhase10_BigMeteor2,
    ESPhase11_BigMeteor3,
    ESPhase12_UFO0,
    ESPhase13_UFO1,
    ESPhase14_UFO2,
    ESPhase15_UFO3,
    ESPhase16_Meteor
};


class CMainScene :
    public CScene
{
	friend class CSceneManager;

protected:
	CMainScene();
	virtual ~CMainScene();
public:
	virtual bool Init();
    virtual void Update(float DeltaTime);
    virtual void PostUpdate(float DeltaTime);
    virtual void Render(HDC hDC, float DeltaTime);

protected:
    class CBackgroundSpace* m_BackGround;


private://Phase ���� ���� �޼ҵ� ����
    UINT8 m_PhaseFlags;
    CooltimeChecker m_Timer0;
    CooltimeChecker m_Timer1;
    CooltimeChecker m_Timer2;

    INT16 m_Counter;
    INT16 m_KeyMonsterCounter;
    int m_MiniUFOCounter;
    bool m_FirstPhaseEnter;
public:
    void GotoNextPhase();//���� ������ ���Խ� �ݵ�� �� �Լ��� ���� �����Ұ�
    bool CheckFirstEnter();  //���̽� ù���� Ȯ�ο� �Լ�
    void AddMiniUFOCounter(int Num);
    int GetMiniUFOCounter() const;
private:
    void PhaseUpdate(float DeltaTime);

private:


public:
    void SetScrollMapSpeed(float Speed);
    void SetScrollMapSpeedSoft(float AdjustSpeed, float SpeedPerSec);
    void KeyMonsterDead();


};

