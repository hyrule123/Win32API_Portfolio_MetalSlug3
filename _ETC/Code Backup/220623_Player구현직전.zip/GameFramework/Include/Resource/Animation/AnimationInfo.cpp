#include "AnimationInfo.h"

CAnimationInfo::CAnimationInfo() :
	m_Frame(0),
	m_Time(0.f),
	m_FrameTime(0.f),
	m_PlayTime(1.f),
	m_PlayScale(1.f),
	m_Loop(false),
	m_Reverse(false),
	m_ReverseOnce(false),
	m_EndFuncOnce(false),
	m_Layer(0)
{
}

CAnimationInfo::~CAnimationInfo()
{
	size_t size = m_vecNotify.size();

	for (size_t i = 0; i < size; ++i)
	{
		size_t size = m_vecNotify[i].size();
		for (size_t j = 0; j < size; ++j)
		{
			SAFE_DELETE(m_vecNotify[i][j]);
		}
		
	}

}

void CAnimationInfo::Init()
{
	if (m_Reverse)
		m_Frame = (int)m_Sequence->GetFrameCount() - 1;
	else
		m_Frame = 0;


	m_Time = 0.f;
	

	//��Ƽ���� ������ �迭 call ���� �ʱ�ȭ
	size_t size = m_vecNotify.size();
	for (int i = 0; i < size; ++i)
	{
		if (m_vecNotify[i].empty())
			continue;

		size_t _size = m_vecNotify[i].size();

		for (int j = 0; j < _size; ++j)
		{
			m_vecNotify[i][j]->Call = false;
		}
	}

	m_EndFunction.Call = false;
}



void CAnimationInfo::ResetOnce()
{
	if (m_ReverseOnce)
	{
		m_ReverseOnce = false;
		m_Reverse = false;
	}
	if (m_EndFuncOnce)
	{
		m_EndFuncOnce = false;
		DeleteEndFunction();
	}
}

void CAnimationInfo::DeleteEndFunction()
{
	m_EndFunction.Func = nullptr;
	m_EndFunction.Call = false;
}
