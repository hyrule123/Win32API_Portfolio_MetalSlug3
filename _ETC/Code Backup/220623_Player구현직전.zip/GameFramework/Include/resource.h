//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// GameFramework.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDI_ICON1                       101
#define IDD_DIALOG_TILEMAPEDIT          104
#define IDD_DIALOG_ANIMEDIT             104
#define IDC_EDIT_COUNTX                 1005
#define IDC_EDIT_COUNTY                 1006
#define IDC_EDIT_SIZEX                  1007
#define IDC_EDIT_SIZEY                  1008
#define IDC_BUTTON_CREATE               1009
#define IDC_BUTTON_QUIT                 1010
#define IDC_LIST_ANIMSEQ                1011
#define IDC_LIST_SPRITE_FRAME           1012
#define IDC_BUTTON_LOADCSV              1013
#define IDC_BUTTON_ADDFRAME             1014
#define IDC_LIST_PLAYLIST               1014
#define IDC_LIST_TEXTURENAME            1015
#define IDC_BUTTON_RESET                1016
#define IDC_BUTTON_SAVE                 1017
#define IDC_BUTTON_PLAY                 1017
#define IDC_BUTTON_CLEARLIST            1018
#define IDC_EDIT_FRAME_STARTX           1019
#define IDC_EDIT_FRAME_STARTY           1020
#define IDC_EDIT_FRAME_ENDX             1021
#define IDC_EDIT_FRAME_ENDY             1022
#define IDC_EDIT_FRAME_OFFSETX          1023
#define IDC_EDIT_FRAME_OFFSETY          1024
#define IDC_BUTTON_INFOVALUESET         1025
#define IDC_BUTTON_RELOADCSV            1026
#define IDC_CHECK_LOOP                  1028
#define IDC_EDIT_OFFSETX                1029
#define IDC_CHECK_REVERSE               1031
#define IDC_EDIT_PLAYTIME               1032
#define IDC_EDIT_OFFSETY                1034
#define IDC_EDIT_PLAYSCALE              1035
#define IDC_BUTTON_ADDPLAYLIST          1036
#define IDC_EDIT_LAYER                  1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
