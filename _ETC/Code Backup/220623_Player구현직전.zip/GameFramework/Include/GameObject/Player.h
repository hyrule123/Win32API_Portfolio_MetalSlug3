#pragma once
#include "Character.h"

enum class EPlayerSkill
{
	BasicAttack,
	End
};


class CPlayer :
    public CCharacter
{
	friend class CScene;

protected:
	CPlayer();
	CPlayer(const CPlayer& Obj);
	virtual ~CPlayer();

public:
	virtual bool Init(CGameObject* Obj = nullptr);
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	virtual float InflictDamage(float Damage);

private:
	virtual void MoveLeft() = 0;
	virtual void MoveRight() = 0;
	virtual void MoveUp() = 0;
	virtual void MoveDown() = 0;


	virtual void FireGun() = 0;
	virtual void FireBomb() = 0;
	virtual void FireNotify() = 0;
	virtual void AttackEnd() = 0;
};

