#pragma once

#include "../Ref.h"
#include "../Resource/Animation/Animation.h"

class CGameObject : public CRef
{
	friend class CScene;
	friend class CInput;

protected:
	CGameObject();
	CGameObject(const CGameObject& Obj);
	virtual ~CGameObject();
public:
	virtual bool Init(CGameObject* Obj = nullptr);

	//���⼭ �⺻���� ��ġ ���� ���� ���Ŀ� ������ϴ� �������� �������ش�.
	virtual void Start();
	bool m_Start;


protected://��ġ, ũ��
	Vector2 m_Dir;
	Vector2 m_Pos;
	Vector2 m_Size;
	Vector2 m_Pivot;
	float	m_Speed;
	Vector2 m_PrevPos;
	Vector2 m_MoveDist;
public:	//��ġ
	void SetPos(float _x, float _y);
	void SetPos(const Vector2& Vec);
	Vector2 GetPos() const;
	//�̵� ����
	void MoveDir(const Vector2& Dir);
	void MovePos(const Vector2& Pos);
	void MoveAngle(float Angle);
	void MoveValue(const Vector2& MoveValue);
	void SetSize(float _x, float _y);
	void SetSize(const Vector2& Size);
	Vector2 GetSize()	const;
	void SetPivot(float _x, float _y);
	Vector2 GetPivot()	const;


protected://���� ó��
	bool	m_PhysicsSimulate;
	bool	m_Ground;
	float	m_GravityAccel;
	float	m_FallTime;
	float	m_FallStartY;
	bool	m_Jump;
	float	m_JumpVelocity;
	bool	m_SideWallCheck;
public:
	void SetPhysicsSimulate(bool Physics);
	void SetGravityAccel(float Accel);
	void SetJumpVelocity(float JumpVelocity);
	void Jump();
	void CheckMoveLeft();
	void CheckMoveRight();
	void SetSideWallCheck(bool Check);



protected://�ް� ���� �������� ��Ƶ� ���� ������Ʈ
	CSharedPtr<class CWidgetComponent> m_WidgetComponent;
public:
	void CreateWidgetComponent();
	class CWidgetComponent* GetWidgetComponent() const;


protected://��� ������ ����
	float m_Scale;
public:
	float GetScale() const;
	void SetScale(float Scale);


protected://�ҼӰ���
	CScene* m_Scene;
	CGameObject* m_MasterObject;
	std::list<CSharedPtr<CGameObject>> m_SlaveObject;
	ERenderLayer m_RenderLayer;
public:
	//������ ���̾�
	ERenderLayer GetRenderLayer()	const;
	void SetRenderLayer(ERenderLayer Layer);

	//���� ���ӿ�����Ʈ ���
	virtual void AddObj(CGameObject* Obj);

	//�ڽ��� �Ҽӵ� ��
	void SetOwnerScene(CScene* Scene);
	CScene* GetOwnerScene() const;



protected://�� ���ӿ�����Ʈ�� Ÿ�ӽ�����
	float m_TimeScaleObj;
public:
	float GetTimeScaleObj()	const;
	void SetTimeScaleObj(float TimeScaleObj);
	

public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	virtual float InflictDamage(float Damage);


public:
	void SaveFileName(const char* FileName, const std::string& PathName);
	void LoadFileName(const char* FileName, const std::string& PathName);
	void SaveFullPath(const char* FullPath);
	void LoadFullPath(const char* FullPath);
	virtual void Save(FILE* File);
	virtual void Load(FILE* File);


protected:
	//���ҽ�
	CSharedPtr<class CTexture> m_Texture;
	CAnimation* m_Animation;


protected:
	//�浹ü ����Ʈ
	std::list<CSharedPtr<class CCollider>> m_ColliderList;
public:
	bool Culling(const Vector2& PosLT,const Vector2& Size, const Vector2& Res);
	//�ڽſ��� �浹ü�� �߰��Ѵ�.(T -> �浹ü Ÿ��(���)�� ���� Ŭ������
	template <typename T>
	T* AddCollider(const std::string& Name)
	{
		T* Collider = new T;

		if (!Collider->Init())
		{
			SAFE_DELETE(Collider);
			return nullptr;
		}

		Collider->SetName(Name);
		Collider->m_OwnerObj = this;
		Collider->m_Scene = m_Scene;

		m_ColliderList.push_back((class CCollider*)Collider);

		return Collider;
	}



///////////////////////// ANIMATION ////////////////////////
public:
	bool LoadCSVPreset(
		const std::tstring& CSVFileName,
		const std::string& PathName = DATA_PATH
	);


	void CreateAnimation();	//�ִϸ��̼��� �����Ҵ��ϰ� ���� ������Ʈ�� ���� ���
	void ResetAnimation(); //����Ʈ������ ����.

	void AddAnimationInfo(const std::string& AnimName, 
		bool Loop = true,
		float PlayTime = 1.f, float PlayScale = 1.f, 
		bool Reverse = false, int Layer = 0, 
		float OffsetX = 0.f, float OffsetY = 0.f);

	void SetPlayTime(const std::string& AnimName, float PlayTime);
	void SetPlayScale(const std::string& AnimName, float PlayScale);
	void SetPlayLoop(const std::string& AnimName, bool Loop);
	void SetPlayReverse(const std::string& AnimName, bool Reverse, bool Once = false);
	void SetLayer(const std::string& AnimName, int Layer);
	void SetOffset(const std::string& AnimName, float OffsetX, float OffsetY);

	void SetCurrentAnimation(const std::string& AnimName);
	void ChangeAnimation(const std::string& AnimName);
	bool CheckCurrentAnimation(const std::string& AnimName);

	template <typename T>
	void SetEndFunction(const std::string& AnimName, T* Obj, void (T::* Func)())
	{
		if (m_Animation)
			m_Animation->SetEndFunction<T>(AnimName, Obj, Func);

	}

	template <typename T>
	void AddNotify(const std::string& AnimName, int Frame, T* Obj, void(T::* Func)())
	{
		if (m_Animation)
			m_Animation->AddNotify<T>(AnimName, Frame, Obj, Func);
	}
/////////////////////////////////////////////////////////////////////












///////////////////////// Texture ///////////////////////////////
public:
	void SetColorKey(unsigned char r = 255,
		unsigned char g = 0,
		unsigned char b = 255,
		int index = -1);

	void SetTexture(const std::string& Name);
	void SetTexture(class CTexture* Tex);
	void SetTexture(const std::string& Name, const std::tstring& FileName, const std::string& PathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& Name, const std::tstring& FullPath);


	void SetTexture(const std::string& Name, const std::vector<std::tstring>& vecFileName, const std::string& PathName = TEXTURE_PATH);
	void SetTextureFullPath(const std::string& Name, const std::vector<std::tstring>& vecFullPath);

/////////////////////////////////////////////////////////////////////

};
