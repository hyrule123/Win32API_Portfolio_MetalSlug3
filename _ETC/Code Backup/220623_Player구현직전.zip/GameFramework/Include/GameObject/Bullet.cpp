#include "Bullet.h"

//�浹ü
#include "../Collision/ColliderCircle.h"


#include "../../Include/Scene/Scene.h"

//�Ѿ� ����Ʈ ������
#include "Effect.h"
#include "../Scene/SceneResource.h"

CBullet::CBullet() :
	m_Distance(1000.f),
	m_isSet(false)
{
}

CBullet::CBullet(const CBullet& Obj) :
	CGameObject(Obj),
	m_Distance(Obj.m_Distance),
	m_isSet(Obj.m_isSet)
{
}

CBullet::~CBullet()
{
}

bool CBullet::Init(CGameObject* Obj)
{
	CGameObject::Init(Obj);

	m_Speed = 100.f;
	m_Distance = 0.f;

	SetSize(5.f, 5.f);
	SetPivot(0.5f, 0.5f);

	SetTexture("BulletPistol");
	
	//�浹ü ����
	CColliderCircle* Coll = AddCollider<CColliderCircle>("Bullet");
	if (m_MasterObject->GetName() == "Monster")
	{
		Coll->SetCollisionProfile(ECollisionChannel::MonsterAttack);
	}
	else if (m_MasterObject->GetName() == "Player")
	{
		Coll->SetCollisionProfile(ECollisionChannel::PlayerAttack);
	}
	Coll->SetRadius(m_Size.x * m_Pivot.x);
	//Coll->SetOffset(Vector2(10.f, 10.f));

	//ȣ�� �Լ� ����
	Coll->SetColliderBeginFunction(this, &CBullet::CollisionBegin);



	

	return true;
}

void CBullet::Update(float DeltaTime)
{
	CGameObject::Update(DeltaTime);

	m_Distance += m_Speed * DeltaTime;

	MoveDir(m_Dir);

}

void CBullet::PostUpdate(float DeltaTime)
{
	

	//�ı� ������ �����Ǹ� �Ѿ� ����
	//�Ÿ��� ����ų�, �Ѿ� �⺻������ ���� �ʾҴٸ� �׳� ����
	if (DestroyCheck() || !m_isSet)
	{
		SetActive(false);
	}

	CGameObject::PostUpdate(DeltaTime);
}

void CBullet::Render(HDC hDC, float DeltaTime)
{
	CGameObject::Render(hDC, DeltaTime);

	Vector2 RenderLeftTop = m_Pos - (m_Size * m_Pivot) - m_Scene->GetCamPos();

	Ellipse(hDC, (int)RenderLeftTop.x,
		(int)RenderLeftTop.y,
		(int)(RenderLeftTop.x + m_Size.x),
		(int)(RenderLeftTop.y + m_Size.y));
}

void CBullet::SetDamage(float Damage)
{
	m_Damage = Damage;
}

bool CBullet::DestroyCheck()
{
	if (m_Distance >= 1000.f)
 		return true;

	return false;
}

void CBullet::SetSpeedDir(float _x, Vector2 Dir)
{
	m_isSet = true;

	m_Speed = _x;
	m_Dir = Dir;
}

void CBullet::CollisionBegin(CCollider* Src, CCollider* Dest)
{
	CEffect* Effect = m_Scene->CreateObject<CEffect>("BulletSFX");

	Effect->AddAnimationInfo("BulletSFX", "BulletSFX", true, 0.2f);
	Effect->SetRenderLayer(ERenderLayer::Effect);

	Effect->SetPivot(0.5f, 0.5f);
	Effect->SetPos(Src->GetHitPoint());

	Dest->GetOwnerObj()->InflictDamage(m_Damage);

	SetActive(false);
}
