#pragma once
#include "Player.h"


class CPlayerSpaceVehicle :
	public CPlayer
{
	friend class CScene;

protected:


	std::vector<class CColliderBox*> m_Collider;


protected:
	CPlayerSpaceVehicle();
	CPlayerSpaceVehicle(const CPlayerSpaceVehicle& Obj);
	virtual ~CPlayerSpaceVehicle();

public:
	virtual bool Init(CGameObject* Obj = nullptr);
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	virtual float InflictDamage(float Damage);



private:
	void MoveLeft();
	void MoveRight();
	void MoveUp();
	void MoveDown();

	void FireGun();
	void FireBomb();
	void FireNotify();
	void AttackEnd();
};

