#pragma once
#include "GameObject.h"


class CEditViewer :
    public CGameObject
{
    friend class CSceneEdit;
    friend class CScene;

protected:
    CEditViewer();
    CEditViewer(const CGameObject& Obj);
    virtual ~CEditViewer();
public:
    bool Init(CGameObject* Obj = nullptr);



public:
    virtual void Update(float DeltaTime);

    void ViewAnimation(const std::string& AnimName, bool Loop, float PlayTime, float PlayScale, bool Reverse, int Layer, float OffsetX, float OffsetY);

    void GetAnimInfoValue(const std::string& AnimName, bool& Loop, float& PlayTime, float& PlayScale, bool& Reverse, int& Layer, float& OffsetX, float& OffsetY);

    class CAnimation* GetAnimation();

    void Play();

    //void ViewFrame();
};

