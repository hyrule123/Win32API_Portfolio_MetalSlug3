#include "MainScene.h"
#include "../Input.h"

//����ϴ� ���ӿ�����Ʈ
#include "../GameObject/AstroSlug.h"
#include "../GameObject/AstroSlugSFX.h"
#include "../GameObject/PlayerSpace.h"
#include "../GameObject/Explosion.h"
#include "../GameObject/Enemy.h"
#include "../GameObject/UFO.h"
#include "../GameObject/BackgroundSpace.h"
#include "../GameObject/PistolHit.h"
#include "../GameObject/Shotgun.h"
#include "../GameObject/AstroBomb.h"


//����ϴ� UI
#include "../UI/WindowEnemyHP.h"

#include "SceneResource.h"

//Camera ó��
#include "Camera.h"

//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"


CMainScene::CMainScene()
{
}

CMainScene::~CMainScene()
{
}

bool CMainScene::Init()
{
	CScene::Init();


	GetCamera()->SetRes((float)ORIGINAL_GAME_RES_WIDTH, 
		(float)ORIGINAL_GAME_RES_HEIGHT);
	GetCamera()->SetWorldRes(ORIGINAL_GAME_RES_WIDTH, 
		ORIGINAL_GAME_RES_HEIGHT * 2.f);
	GetCamera()->SetTargetPivot(0.5f, 0.8f);

	CreateObject<CBackgroundSpace>("BackGround");



	//���� ���
	GetSceneResource()->LoadSound("SFX", "MainTheme", true, "MS3_Into_The_Cosmos.mp3");
	GetSceneResource()->SetMasterVolume(10);
	GetSceneResource()->SoundPlay("MainTheme");


	//���ҽ� �̸� �ε�
	CreateOriginalObj<CPlayerSpace>("PlayerSpace");
	//CreateObject<CPlayerSpace>();
	CreateOriginalObj<CAstroSlugSFX>("AstroSlugSFX");
	CreateOriginalObj<CExplosion>("Explosion");
	CreateOriginalObj<CPistolHit>("PistolHit");
	CreateOriginalObj<CShotgun>("Shotgun");
	CreateOriginalObj<CAstroBomb>("AstroBomb");

	CreateObject<CUFO>("UFO");
	CAstroSlug* Player = CreateObject<CAstroSlug>("AstroSlug");
	//CPlayerSpace* Player = CreateObject<CPlayerSpace>("PlayerSpace");

	//GetCamera()->SetTargetObj(Player);
	Player->SetPhysicsSimulate(false);
	Player->SetPos(100.f, 100.f);



	////���� ����
	//CEnemy* Enemy = CreateObject<CEnemy>("Enemy");
	//Enemy->SetPos(200.f, 200.f);
	
	////CreateWidgetWindow<CWindowEnemyHP>("EnemyHPBarWindow");






	return true;
}


