#pragma once
#include "Projectile.h"
class CHMG :
    public CProjectile
{
    friend class CScene;

protected:
    CHMG();
    CHMG(const CHMG& Obj);
    virtual ~CHMG();

public:
    virtual bool Init(CGameObject* Obj = nullptr);
    virtual bool LoadResource();
    virtual void SetEssential(Vector2 Dir, Vector2 Pos);



private:
    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

