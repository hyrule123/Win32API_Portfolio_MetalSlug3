#pragma once
#include "Projectile.h"


class CLaser :
    public CProjectile
{
    friend class CScene;

protected:
    int m_Damage;
    bool m_isReady;

    class CColliderLine* m_Coll;
    class CGameObject* m_CollidingObj;
    float m_CollidingObjYPos;  //���� �浹���� ���ӿ�����Ʈ�� y��


protected:
    CLaser();
    CLaser(const CLaser& Obj);
    virtual ~CLaser();

public:
    virtual bool Init(CGameObject* Obj = nullptr);
    virtual void Update(float DeltaTime);
    virtual void PostUpdate(float DeltaTime);
    virtual void Render(HDC hDC, float DeltaTime);
    void SetDamage(int Damage);


    virtual void SetEssential(Vector2 Dir, Vector2 Pos);
    virtual void SetEssential(float DirX, float DirY, float PosX, float PosY);

private:


    //â ���� �Ѿ�� �ı�(�ӽ�)
    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

