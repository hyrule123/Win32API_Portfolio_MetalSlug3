#pragma once
#include "Projectile.h"
class CEnemyProjectile :
    public CProjectile
{
    friend class CScene;

protected:
    CEnemyProjectile();
    CEnemyProjectile(const CEnemyProjectile& Obj);
    virtual ~CEnemyProjectile();

public:
    bool Init(CGameObject* Obj = nullptr);
    bool LoadResource();


private:
    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

