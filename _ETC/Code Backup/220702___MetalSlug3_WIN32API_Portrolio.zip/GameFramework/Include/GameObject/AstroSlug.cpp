#include "AstroSlug.h"

//�÷��̾� �ּ� ����
#include "../GameManager.h"

//�÷��̾� ����
#include "PlayerSpace.h"


//SFX ȣ���
#include "../Scene/Scene.h"
#include "AstroSlugSFX.h"
#include "Explosion.h"
#include "Trail.h"

#include "../Input.h"

#include "../Collision/ColliderBox.h"

//����
#include "Pistol.h"
#include "HMG.h"
#include "RocketLauncher.h"
#include "Shotgun.h"
#include "AstroBomb.h"
#include "Laser.h"

//���÷��� ������
#include "Splash.h"


CAstroSlug::CAstroSlug() :
	m_isSeparate(true),
	m_PartState{ EPartState::Normal },
	m_SyncTimer(),
	m_SyncTimerMax(),
	m_CurrentWeapon(EWeapon::Pistol),
	m_Busy(false),
	m_FireBuffer(),
	m_ExplodeRemainTime(3.f),
	m_FireTurn(),
	m_PistolFireAngle(1),
	m_FireHMG(),
	m_SelfDestruct(),
	m_KnockBack(),
	m_BombTurn(),
	m_BoostOn(),
	m_BoostSFXSide(),
	m_BoostSFXTail(),
	m_BoosterDirSideName{},
	m_BoostDuration(0.5f),
	m_isKeyDown()
{
	SetTypeID<CAstroSlug>();
	m_RenderLayer = ERenderLayer::Slug;
	m_HP = 3;
}

CAstroSlug::CAstroSlug(const CAstroSlug& Obj):
	CPlayer(Obj),
	m_isSeparate(Obj.m_isSeparate),
	m_SyncTimer(),
	m_SyncTimerMax(),
	m_CurrentWeapon(EWeapon::Pistol),
	m_Busy(false),
	m_FireBuffer(),
	m_ExplodeRemainTime(Obj.m_ExplodeRemainTime),
	m_FireTurn(Obj.m_FireTurn),
	m_PistolFireAngle(1),
	m_FireHMG(),
	m_SelfDestruct(),
	m_KnockBack(Obj.m_KnockBack),
	m_BombTurn(Obj.m_BombTurn),
	m_BoostOn(Obj.m_BoostOn),
	m_BoostSFXSide(),
	m_BoostSFXTail(),
	m_BoostDuration(Obj.m_BoostDuration),
	m_isKeyDown(Obj.m_isKeyDown)
{
	m_PartState[0] = Obj.m_PartState[0];
	m_PartState[1] = Obj.m_PartState[1];




	for (int i = 0; i < EBoosterDirSideMax; ++i)
	{
		m_BoosterDirSideName[i] = Obj.m_BoosterDirSideName[i];
	}

	for (int i = 0; i < EBoosterDirTailMax; ++i)
	{
		m_BoosterDirTailName[i] = Obj.m_BoosterDirTailName[i];
	}
}

CAstroSlug::~CAstroSlug()
{
	CInput::GetInst()->DeleteBindClass<CAstroSlug>(this);
}

bool CAstroSlug::LoadResource()
{
	CreateAnimation();
	if(!LoadCSVPreset(TEXT("Player/AstroSlug.csv")))
		return false;

	RegisterAnimName();

	return true;
}

bool CAstroSlug::Init(CGameObject* Obj)
{
	CPlayer::Init();

	//Player�� �ּҸ� CGameManager�� ����Ѵ�.
	CGameManager::GetInst()->SetPlayer(this);

	RegisterInput();

	ChangeAnimation("PlayerRight");

	m_Animation->SetEndFunction<CAstroSlug>
		("LeftPart_Rifle_Get", this, &CAstroSlug::ChangeRifleEnd);
	m_Animation->SetEndFunction<CAstroSlug>
		("RightPart_Rifle_Get", this, &CAstroSlug::ChangeRifleEnd);
	m_Animation->SetEndFunction<CAstroSlug>
		("PlayerTurnLeftToRight", this, &CAstroSlug::PlayerTurnLeftToRightEnd);

	m_Animation->SetEndFunction<CAstroSlug>
		("EjectModeDoor", this, &CAstroSlug::EjectModeDoorEnd);


	//��Ƽ���� ���
	//�� 2�����Ӷ� SFX ȿ�� ���
	m_Animation->AddNotify<CAstroSlug>("EjectModeDoor", 2, this, &CAstroSlug::EjectDoorFrame2Notify);




	//��ġ ����
	SetPos(50.f, 50.f);
	SetSize(36.f, 50.f);
	SetDir(1.f, 0.f);
	SetPivot(0.5f, 1.f);
	SetMaxSpeed(150.f);
	//���ӵ�
	SetDeAccel(0.85f);
	


	//��ų ����
	m_vecCooltime.resize((size_t)EWeapon::MAX);

	for (int i = 0; i < (int)EWeapon::MAX; ++i)
	{
		switch ((EWeapon)i)
		{
		case EWeapon::Pistol:
			m_vecCooltime[(int)EWeapon::Pistol].Cooltime = 0.1f;
			break;
		case EWeapon::HMG:
			m_vecCooltime[(int)EWeapon::HMG].Cooltime = 0.1f;
			break;
		case EWeapon::Shotgun:
			m_vecCooltime[(int)EWeapon::Shotgun].Cooltime = 0.3f;
			break;
		case EWeapon::Rocket:
			m_vecCooltime[(int)EWeapon::Rocket].Cooltime = 0.2f;
			break;
		case EWeapon::Laser:
			m_vecCooltime[(int)EWeapon::Laser].Cooltime = 0.1f;
			break;
		case EWeapon::Bomb:
			m_vecCooltime[(int)EWeapon::Bomb].Cooltime = 0.3f;
			break;
		default:
			break;
		}
	}
	

	//�浹ü
	CColliderBox* Coll = AddCollider<CColliderBox>("AstroColl");
	Coll->SetSize(m_Size);
	Coll->SetPivot(0.5f, 1.f);
	Coll->SetOffset(0.f, -10.f);
	Coll->SetCollisionProfile(ECollisionChannel::Player);


	m_BoostSFXSide = m_Scene->CreateObject<CAstroSlugSFX>("BoostSFXSide", this);
	m_BoostSFXSide->SetEffect(EEffectType::Loop);

	m_BoostSFXTail = m_Scene->CreateObject<CAstroSlugSFX>("BoostSFXTail", this);
	m_BoostSFXTail->SetEffect(EEffectType::Loop);

	//�� �ν��ͺ� �̸��� ���ڿ� �迭�� ���
	m_BoosterDirSideName[SmallBoosterNE] = "SmallBoosterNE";
	m_BoosterDirSideName[SmallBoosterE] = "SmallBoosterE";
	m_BoosterDirSideName[SmallBoosterSE] = "SmallBoosterSE";
	m_BoosterDirSideName[SmallBoosterSW] = "SmallBoosterSW";
	m_BoosterDirSideName[SmallBoosterW] = "SmallBoosterW";
	m_BoosterDirSideName[SmallBoosterNW] = "SmallBoosterNW";
	
	m_BoosterDirTailName[TailBoost1] = "TailBoost1";
	m_BoosterDirTailName[TailBoost2] = "TailBoost2";
	m_BoosterDirTailName[TailSFX] = "TailSFX";
	m_BoosterDirTailName[TailLeft] = "TailLeft";
	m_BoosterDirTailName[TailRight] = "TailRight";
	m_BoosterDirTailName[TailStraight] = "TailStraight";
	m_BoosterDirTailName[TailIdle] = "TailIdle";



	return true;
}

void CAstroSlug::Update(float DeltaTime)
{
	CPlayer::Update(DeltaTime);


	if (m_FireBuffer > 0)
		FireGun();

	if (m_FireHMG > 0)
	{
		if (m_FireHMG % 3 == 0)
			FireHMG();

		--m_FireHMG;
	}

	if (m_isSeparate)
		CheckParts();
	else
		m_Animation->StopAnimation((int)ELayerInfo::Right);

	if (m_HP <= 0)
		Destroy();

	if (m_SelfDestruct)
	{
		SetDir(0.f, -1.f);
		AddImpact(800.f);
	}

	if (m_KnockBack > 0.f)
		m_KnockBack -= DeltaTime;
		

	//�ν���: ���� �״� ���� ����
	if (m_BoostOn)
	{
		for (int i = 0; i < EBoosterDirSideMax; ++i)
		{
			m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[i], m_BoostDuration);
		}
	}


	if (!m_isKeyDown)
	{
		m_BoostSFXTail->ChangeAnimation(m_BoosterDirTailName[TailIdle]);
	}
	CGameManager::GetInst()->DebugTextOut("m_isKeyDown", (int)m_isKeyDown);
	m_isKeyDown = false;


	
}

void CAstroSlug::PostUpdate(float DeltaTime)
{
	CPlayer::PostUpdate(DeltaTime);

	
}

void CAstroSlug::Render(HDC hDC, float DeltaTime)
{
	CPlayer::Render(hDC, DeltaTime);
}



void CAstroSlug::TempDamage()
{
	InflictDamage(1);
}

int CAstroSlug::InflictDamage(int Damage)
{
	m_HP -= Damage;

	//��Ʈ����Ʈ�� ���� �ణ�� �˹� �� �� �ϳ� ���
	KnockBack();
	RifleDrop();
	
	StartReaction(1.f,true, EReactionChannel::InvincibleReaction);
	
	return Damage;
}





void CAstroSlug::CheckParts()
{
	switch (m_PartState[0])
	{
	case EPartState::Normal:
		ChangeAnimContinue("LeftPart_Pistol");
		break;
	case EPartState::NormalRifle:
		ChangeAnimContinue("LeftPart_Rifle");
		break;
	case EPartState::GunGet:
		ChangeAnimation("LeftPart_Rifle_Get");
		break;
	case EPartState::GunDrop:
		SetPlayReverse("LeftPart_Rifle_Get", true, true);
		ChangeAnimation("LeftPart_Rifle_Get");
		break;
	default:
		break;
	}

	switch (m_PartState[1])
	{
	case EPartState::Normal:
		ChangeAnimation("RightPart_Pistol");
		break;
	case EPartState::NormalRifle:
		ChangeAnimation("RightPart_Rifle");
		break;
	case EPartState::GunGet:
		ChangeAnimation("RightPart_Rifle_Get");
		break;
	case EPartState::GunDrop:
		SetPlayReverse("RightPart_Rifle_Get", true, true);
		ChangeAnimation("RightPart_Rifle_Get");
		break;
	default:
		break;
	}

	if (m_PartState[0] <= EPartState::NormalRifle
		&& m_PartState[1] <= EPartState::NormalRifle)
	{
		m_Animation->SyncPlayTime(
			(int)ELayerInfo::LeftorOne,
			(int)ELayerInfo::Right);
	}
}

void CAstroSlug::MoveLeft()
{
	if (m_KnockBack > 0.f)
		return;

	m_isKeyDown = true;

	if (CheckAnimationPlaying("PlayerRight"))
	{
		//��������
		SetPlayReverse("PlayerTurnLeftToRight", true, true);
		ChangeAnimation("PlayerTurnLeftToRight");
	}

	SetDir(-1.f, 0.f);
	MoveDir(m_Dir);

}

void CAstroSlug::MoveRight()
{
	if (m_KnockBack > 0.f)
		return;

	m_isKeyDown = true;

	if (CheckAnimationPlaying("PlayerLeft"))
	{
		ChangeAnimation("PlayerTurnLeftToRight");
	}

	SetDir(1.f, 0.f);
	MoveDir(m_Dir);

}




void CAstroSlug::MoveUp()
{
	if (m_KnockBack > 0.f)
		return;

	m_isKeyDown = true;

	SetDir(0.f, -1.f);
	MoveDir(m_Dir);

}

void CAstroSlug::MoveDown()
{

	if (m_KnockBack > 0.f)
		return;


	m_isKeyDown = true;

	SetDir(0.f, 1.f);
	MoveDir(m_Dir);


	m_BoostSFXTail->ChangeAnimContinue(m_BoosterDirTailName[TailIdle]);
}

void CAstroSlug::KeyDownLeft()
{
	if (m_KnockBack > 0.f)
		return;
	
	m_isKeyDown = true;

	if (m_PartState[1] == EPartState::Normal)
	{
		m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterE], m_BoostDuration);
		m_BoostSFXSide->SetAnimOffset(m_BoosterDirSideName[SmallBoosterE], 16.f, -32.f);
	}
	else if (m_PartState[1] == EPartState::NormalRifle)
	{
		m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterE], m_BoostDuration);
		m_BoostSFXSide->SetAnimOffset(m_BoosterDirSideName[SmallBoosterE], 36.f, -32.f);
	}


	m_BoostSFXTail->ChangeAnimContinue(m_BoosterDirTailName[TailLeft]);
}

void CAstroSlug::KeyDownRight()
{
	if (m_KnockBack > 0.f)
		return;

	m_isKeyDown = true;

	if (m_PartState[0] == EPartState::Normal)
	{
		m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterW], m_BoostDuration);
		m_BoostSFXSide->SetAnimOffset(m_BoosterDirSideName[SmallBoosterW], -16.f, -32.f);
	}
	else if (m_PartState[0] == EPartState::NormalRifle)
	{
		m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterW], m_BoostDuration);
		m_BoostSFXSide->SetAnimOffset(m_BoosterDirSideName[SmallBoosterW], -36.f, -32.f);
	}

	m_BoostSFXTail->ChangeAnimContinue(m_BoosterDirTailName[TailRight]);
}

void CAstroSlug::KeyDownUp()
{
	if (m_KnockBack > 0.f)
		return;


	m_isKeyDown = true;

	m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterSW], m_BoostDuration);
	m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterSE], m_BoostDuration);


	m_BoostSFXTail->ChangeAnimContinue(m_BoosterDirTailName[TailStraight]);
}

void CAstroSlug::KeyDownDown()
{
	if (m_KnockBack > 0.f)
		return;

	m_isKeyDown = true;

	m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterNW], m_BoostDuration);
	m_BoostSFXSide->ChangeAnimationDuration(m_BoosterDirSideName[SmallBoosterNE], m_BoostDuration);


	m_BoostSFXTail->ChangeAnimContinue(m_BoosterDirTailName[TailIdle]);
}

void CAstroSlug::FireGunBuffer()
{
	++m_FireBuffer;
}

void CAstroSlug::FireGun()
{
	//���Է� ���� �ʱ�ȭ
	m_FireBuffer = 0;

	//�ƽ�Ʈ�� �����׿��� �ǽ����� � ���⸦ ���� �߻��.
	if (!m_vecCooltime[(int)EWeapon::Pistol].isCooltime)
	{
		//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ���� �ۼ�
		EnterSkillCoolTIme((int)EWeapon::Pistol);

		CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("GunFireSFX", this);



		//�Ѿ� ������Ʈ ����
		CHMG* HMG = m_Scene->CreateObject<CHMG>("HMG");
		HMG->SetEssential(Vector2((float)m_PistolFireAngle * 0.1f, -1.f), Vector2(m_Pos.x, m_Pos.y - 100.f));

		--m_PistolFireAngle;
		if (m_PistolFireAngle < -1)
			m_PistolFireAngle = 1;
	}

	//�ѱ�:  m_Pos�κ��� ���� -25, -65/���� +25,-65
	switch (m_CurrentWeapon)
	{
	case EWeapon::HMG:
		if (!m_vecCooltime[(int)EWeapon::HMG].isCooltime)
		{
			//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ���� �ۼ�
			EnterSkillCoolTIme((int)EWeapon::HMG);

			
			//�ش� ������ �ش� ������ Ȯ���Ͽ� Update���� �ۼ���.
			m_FireHMG = 8;
		}


		break;
	case EWeapon::Shotgun:
		if (!m_vecCooltime[(int)EWeapon::Shotgun].isCooltime)
		{
			//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ���� �ۼ�
			EnterSkillCoolTIme((int)EWeapon::Shotgun);

			if (m_PartState[m_FireTurn] == EPartState::NormalRifle)
			{
				FireShotgun(m_FireTurn);
			}
			else if (m_PartState[!m_FireTurn] == EPartState::NormalRifle)
			{
				FireShotgun(!m_FireTurn);
			}
		}
		break;
	case EWeapon::Rocket:
		if (!m_vecCooltime[(int)EWeapon::Rocket].isCooltime)
		{
			if (m_FiredRocket >= 2)	//���� �ʿ� 2�� �̻� ������ �߻������ return
				break;
			//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ���� �ۼ�
			EnterSkillCoolTIme((int)EWeapon::Rocket);

			if (m_PartState[m_FireTurn] == EPartState::NormalRifle)
			{
				FireRocket(m_FireTurn);
			}
			else if (m_PartState[!m_FireTurn] == EPartState::NormalRifle)
			{
				FireRocket(!m_FireTurn);
			}
		}
		break;
	case EWeapon::Laser:
		if (!m_vecCooltime[(int)EWeapon::Laser].isCooltime)
		{
			EnterSkillCoolTIme((int)EWeapon::Laser);

			if (m_PartState[m_FireTurn] == EPartState::NormalRifle)
			{
				FireLaser(m_FireTurn);
			}
			if (m_PartState[!m_FireTurn] == EPartState::NormalRifle)
			{
				FireLaser(!m_FireTurn);
			}
		}
		break;
	default:
		break;
	}

}


void CAstroSlug::FireHMG()
{
	//�ش� �޼ҵ�� 2�����ӿ� ���� �߻�ȴ�.(�ణ�� ��)

	if (m_PartState[m_FireTurn] == EPartState::NormalRifle)
	{
		//�ݴ� �������� 
		CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("SideGunFireSFX");

		//���� �ѱ� m_Pos�κ��� -25, -65/+25,-65
		Vector2 Offset = m_Pos;
		if (!m_FireTurn) //����
			Offset.x -= 25.f;
		else
			Offset.x += 25.f;
		Offset.y -= 65.f;

		SFX->SetPos(Offset);

		--m_Bullet;
		if (m_Bullet <= 0)
		{
			m_Bullet = 0;
			RifleDrop();
		}

		//�Ѿ� ������Ʈ ����
		CHMG* HMG = m_Scene->CreateObject<CHMG>("HMG");
		HMG->SetEssential(Vector2(0.f, -1.f), Offset);
	
	}

	//�ݴ� �������� ��ȯ.
	m_FireTurn = !m_FireTurn;
	if (m_FireHMG == 3)
	{
		m_FireTurn = !m_FireTurn;
	}
}

void CAstroSlug::FireShotgun(bool isRight)
{

	//���� �ѱ� m_Pos�κ��� -25, -65/+25,-65
	Vector2 Offset;
	if (!isRight) //����
		Offset.x = -25.f;
	else
		Offset.x = 25.f;
	Offset.y = -65.f;

	--m_Bullet;
	if (m_Bullet <= 0)
	{
		m_Bullet = 0;
		RifleDrop();
	}

	//�Ѿ� ������Ʈ ����
	CShotgun* Shotgun = m_Scene->CreateObject<CShotgun>("Shotgun");
	Shotgun->SetEssential(this, Offset);


	m_FireTurn = !m_FireTurn;
}

void CAstroSlug::FireRocket(bool isRight)
{
	CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("RocketLaunch");

	//���� �ѱ� m_Pos�κ��� -25, -65/+25,-65
	Vector2 Offset = m_Pos;
	if (!isRight) //����
		Offset.x -= 25.f;
	else
		Offset.x += 25.f;
	Offset.y -= 65.f;

	SFX->SetPos(Offset);

	--m_Bullet;
	if (m_Bullet <= 0)
	{
		m_Bullet = 0;
		RifleDrop();
	}

	//�Ѿ� ������Ʈ ����
	CRocketLauncher* Rocket = m_Scene->CreateObject<CRocketLauncher>("Rocket");
	Rocket->SetEssential(Vector2(0.f, -1.f), Offset);

	++m_FiredRocket;	//���� �߻� �� ����. �� ���� CRocketLauncher�� �Ҹ��ڿ��� ������
	m_FireTurn = !m_FireTurn;
}

void CAstroSlug::FireLaser(bool isRight)
{
	CLaser* Laser = m_Scene->CreateObject<CLaser>("Laser");

	Laser->SetEssential(0.f, 1.f, m_Pos.x, m_Pos.y);
}






void CAstroSlug::FireBomb()
{
	CAstroBomb* Bomb = m_Scene->CreateObject<CAstroBomb>("BombRight");
	if (Bomb)
		Bomb->SetEssential(
			m_Pos.x + 10.f, m_Pos.y, m_BombTurn);
	Bomb = nullptr;
	Bomb = m_Scene->CreateObject<CAstroBomb>("BombLeft");
	if (Bomb)
		Bomb->SetEssential(
			m_Pos.x - 10.f, m_Pos.y, !m_BombTurn);

	m_BombTurn = !m_BombTurn;
}

void CAstroSlug::Boost()
{
	m_MaxSpeed = 250.f;
	m_BoostOn = true;
}

void CAstroSlug::BoostEnd()
{
	m_MaxSpeed = 150.f;
	m_BoostOn = false;
}

void CAstroSlug::SelfDestruct()
{
	m_SelfDestruct = true;

	//�켱 �ӵ��� 0����(�÷��̾� Ż�� ���� �ް���)
	SetMaxSpeed(0.f);

	Eject();
}

void CAstroSlug::FireNotify()
{
}

void CAstroSlug::RifleGet()
{
	m_Busy = true;

	//������ ���� �ν��� ����� ������Ų��.
	m_BoostSFXSide->StopAnimation(1);
	m_BoostSFXSide->StopAnimation(4);

	for (int i = 0; i <= 1; ++i)
	{
		if (m_PartState[i] != EPartState::NormalRifle)
			m_PartState[i] = EPartState::GunGet;
	}

}


void CAstroSlug::RifleDrop()
{
	m_BoostSFXSide->StopAnimation(1);
	m_BoostSFXSide->StopAnimation(4);

	//������->���� ������ �� ������ -> ��Ʈ����Ʈ�� �����Ұ�
	if (m_PartState[1] == EPartState::NormalRifle)
	{
		m_Busy = true;
		m_PartState[1] = EPartState::GunDrop;
	}
	else if (m_PartState[0] == EPartState::NormalRifle)
	{
		m_Busy = true;
		m_PartState[0] = EPartState::GunDrop;
	}

	if (m_HP <= 0 || m_Bullet <= 0) //ü�� �� �Ǹ� �Ѵ� ������
	{
		if (m_PartState[1] == EPartState::NormalRifle)
		{
			m_Busy = true;
			m_PartState[1] = EPartState::GunDrop;
		}
		if (m_PartState[0] == EPartState::NormalRifle)
		{
			m_Busy = true;
			m_PartState[0] = EPartState::GunDrop;
		}
	}
}


void CAstroSlug::ChangeRifleEnd()
{
	m_Busy = false;
	
	for (int i = 0; i <= 1; ++i)
	{
		if (m_PartState[i] == EPartState::GunGet)
			m_PartState[i] = EPartState::NormalRifle;
		else if (m_PartState[i] == EPartState::GunDrop)
			m_PartState[i] = EPartState::Normal;
	}
}

void CAstroSlug::PlayerTurnLeftToRightEnd()
{
	CAnimationInfo* Info = m_Animation->FindAnimInfo("PlayerTurnLeftToRight");

	if (!Info)
		return;

	if(Info->GetReverse())
		ChangeAnimation("PlayerLeft");
	else
		ChangeAnimation("PlayerRight");
		
}

void CAstroSlug::Destroy()
{
	m_ExplodeRemainTime -= DELTA_TIME;
	if (m_ExplodeRemainTime < 0.f)
	{
		CExplosion* SFX = m_Scene->CreateObject<CExplosion>("BigExplosion");
		SFX->SetPos(m_Pos);

		CTrail* Trail = m_Scene->CreateObject<CTrail>("Trail");
		Trail->SetPos(m_Pos.x, m_Pos.y + 5.f);
		Trail->SetDir(1.f, 0.f);
		Trail->Trajectory(150.f);
		Trail->SetDuration(0.7f);

		Trail = m_Scene->CreateObject<CTrail>("Trail");
		Trail->SetPos(m_Pos.x, m_Pos.y);
		Trail->SetDir(-1.f, 0.f);
		Trail->Trajectory(150.f);
		Trail->SetDuration(0.7f);

		Trail = m_Scene->CreateObject<CTrail>("Trail");
		Trail->SetDuration(0.7f);
		Trail->SetPos(m_Pos);
		Trail->SetDir(1.f, 1.f);
		Trail->Straight(150.f);

		Trail = m_Scene->CreateObject<CTrail>("Trail");
		Trail->SetDuration(0.7f);
		Trail->SetPos(m_Pos);
		Trail->SetDir(-1.f, 1.f);
		Trail->Straight(150.f);

		//ȭ���� �Ͼ�� 1�����Ӱ� ��ȯ
		CGameManager::GetInst()->SetWhiteOut(2);

		SetActive(false);
	}
		
	//HP�� ���� �������� �ѹ��� �����ϵ��� ���ش�.
	if (m_HP > -10)
	{
		m_HP = -100;
		m_Busy = true;

		//���ӵ��� ũ�� ���߰�
		SetDeAccel(0.96f);

		//�ٸ� ��� �Է�(�ൿ)�� �����ϰ�
		CInput::GetInst()->DeleteBindClass<CAstroSlug>(this);

		//���Ż�⸸ Ű�� ����Ѵ�.
		CInput::GetInst()->AddBindFunction<CAstroSlug>("Jump",
			EInput_Type::Down,
			this, &CAstroSlug::Eject);

		//������ �ٲ��ְ�
		StartReaction(5.f, true, EReactionChannel::HitReaction);

		//��¦���� �ʰ� �������� ���� �����Ѵ�.(�浹�� ��� �־����)
		m_Invincible = 4.f;

		//OUT �޽��� ���.
		CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("SlugOut", this);
		//SFX->SetSFX("SlugOut");
		SFX->SetEffect(EEffectType::Duration);
		SFX->SetDuration(3.f);
		SFX->SetOffset(1.f, -80.f);
	}
}


void CAstroSlug::Eject()
{
	//���� �Է� �Ǵ� ü��0���¿��� �Է��� ������ ���
	if (m_ExplodeRemainTime < 2.5f || m_SelfDestruct)
	{
		//�ð��� �ʹ� ������ Ż�� �ִϸ��̼� ����� �ð��� �߰�����
		if (m_ExplodeRemainTime < 0.5f)
			m_ExplodeRemainTime += 0.5f;

		//Ż�� �ȳ��� off
		CGameObject* SFX = m_Scene->FindObject("SlugOut");
		if(SFX)
			SFX->SetActive(false);

		//Ż���ϴ� ���� ���ּ� ���� ����
		CInput::GetInst()->DeleteBindClass<CAstroSlug>(this);

		//���ӵ� 0
		SetDeAccel(0.f);

		//Ż�� ��� �ִϸ��̼� ���
		m_isSeparate = false;
		ChangeAnimation("EjectMode");
		ChangeAnimation("EjectModeDoor", true);
	}
}

void CAstroSlug::EjectDoorFrame2Notify()
{
	m_Scene->SetCamTarget(nullptr);

	CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("BurningDoorSFX");
	SFX->SetEffect(EEffectType::Once);
	SFX->SetPos(m_Pos);

	SFX = m_Scene->CreateObject<CAstroSlugSFX>("DoorParticle");
	SFX->SetEffect(EEffectType::Once);
	SFX->SetPos(m_Pos);

}

void CAstroSlug::EjectModeDoorEnd()
{
	//�÷��̾� â�� ����� false�� ��ȯ
	StopAnimation((int)ELayerInfo::PlayerWindow);

	//�÷��̾� ����
	CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("DetachedDoor");
	//SFX->SetSFX("DetachedDoor");
	SFX->SetPos(m_Pos);
	SFX->SetDuration(1.5f);
	SFX->SetPhysicsSimulate(true);
	SFX->SetJumpVelocity(20.f);
	SFX->SetGravityAccel(5.f);
	SFX->Jump();

	CPlayerSpace* Player = m_Scene->CreateObject<CPlayerSpace>("PlayerSpace");

	Player->SetPos(m_Pos.x, m_Pos.y - 10.f);
	Player->SlugEjection();


	//���� ����ϰ�� ������ ����
	//���� ������ �÷��̾� Ż���� �Ϸ�Ȱ��̹Ƿ� �ӵ������� Ǯ����
	//�̵��� Update()���� ó��
	if (m_SelfDestruct)
	{
		SetMaxSpeed(600.f);
		SetDeAccel(1.f);

		//�浹ü�� ã�Ƽ� ���� EndFunction���� ��ü
		//�ϴ��� �浹ü�� �ϳ����̹Ƿ� begin�� ���ؼ� ��ü���൵ �ɵ�.
		auto iter = m_listCollider.begin();
		if(iter != m_listCollider.end())
			(*iter)->SetColliderBeginFunction<CAstroSlug>(this, &CAstroSlug::SelfDestructCollBegin);
	}
}



void CAstroSlug::AttackEnd()
{
}

void CAstroSlug::KnockBack()
{
	//��Ʈ����Ʈ�� ���ؼ� �ݴ�������� �˹�
	SetDir(m_Dir * -1);

	
	AddImpact(m_MaxSpeed);
	m_KnockBack = 0.5f;
}

void CAstroSlug::RegisterAnimName()
{
	CAnimationInfo* Info = m_Animation->FindAnimInfo("LeftPart_Pistol");
	if (!Info)
		return;
	m_SyncTimerMax = Info->GetPlayTime();
}

void CAstroSlug::RegisterInput()
{
	//�Է� �ʱ�ȭ
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveLeft",
		EInput_Type::Down,
		this, &CAstroSlug::KeyDownLeft);
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveLeft",
		EInput_Type::Push,
		this, &CAstroSlug::MoveLeft);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveRight",
		EInput_Type::Down,
		this, &CAstroSlug::KeyDownRight);
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveRight",
		EInput_Type::Push,
		this, &CAstroSlug::MoveRight);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveUp",
		EInput_Type::Down,
		this, &CAstroSlug::KeyDownUp);
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveUp",
		EInput_Type::Push,
		this, &CAstroSlug::MoveUp);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveDown",
		EInput_Type::Down,
		this, &CAstroSlug::KeyDownDown);
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveDown",
		EInput_Type::Push,
		this, &CAstroSlug::MoveDown);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("GunFire",
		EInput_Type::Down,
		this, &CAstroSlug::FireGunBuffer);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Bomb",
		EInput_Type::Down,
		this, &CAstroSlug::FireBomb);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Jump",
		EInput_Type::Push,
		this, &CAstroSlug::Boost);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Jump",
		EInput_Type::Up,
		this, &CAstroSlug::BoostEnd);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("SelfDestruct",
		EInput_Type::Down,
		this, &CAstroSlug::SelfDestruct);

	

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug1",
		EInput_Type::Down,
		this, &CAstroSlug::ChangeLaser);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug2",
		EInput_Type::Down,
		this, &CAstroSlug::TempDamage);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug3",
		EInput_Type::Down,
		this, &CAstroSlug::Temp2);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug4",
		EInput_Type::Down,
		this, &CAstroSlug::Temp3);
}


void CAstroSlug::ChangeWeapon(EWeapon Weapon)
{
	//�� ȹ�� �ִϸ��̼� ���
	RifleGet();

	//���� ����
	switch (Weapon)
	{
	case EWeapon::HMG:
		if(m_CurrentWeapon == EWeapon::HMG)
			m_Bullet += 200;
		else
		{
			m_CurrentWeapon = EWeapon::HMG;
			m_Bullet = 200;
		}
		break;
	case EWeapon::Shotgun:
		if (m_CurrentWeapon == EWeapon::Shotgun)
			m_Bullet += 30;
		else
		{
			m_CurrentWeapon = EWeapon::Shotgun;
			m_Bullet = 30;
		}
		break;
	case EWeapon::Rocket:
		if (m_CurrentWeapon == EWeapon::Rocket)
			m_Bullet += 30;
		else
		{
			m_CurrentWeapon = EWeapon::Rocket;
			m_Bullet = 30;
		}
		break;
	case EWeapon::Laser:
		if (m_CurrentWeapon == EWeapon::Laser)
			m_Bullet += 200;
		else
		{
			m_CurrentWeapon = EWeapon::Laser;
			m_Bullet = 200;
		}
		break;
	}
}

void CAstroSlug::ChangeHMG()
{
	ChangeWeapon(EWeapon::HMG);
}

void CAstroSlug::ChangeShotgun()
{
	ChangeWeapon(EWeapon::Shotgun);
}

void CAstroSlug::ChangeRocketLauncher()
{
	ChangeWeapon(EWeapon::Rocket);
}

void CAstroSlug::ChangeLaser()
{
	ChangeWeapon(EWeapon::Laser);
}

void CAstroSlug::SelfDestructCollBegin(CCollider* Src, CCollider* Dest)
{
	m_ExplodeRemainTime = -1.f;

	CSplash* Splash = m_Scene->CreateObject<CSplash>("Splash");
	Splash->SetEssential(m_Pos, Vector2(0.f, -100.f), 50.f, ECollisionChannel::PlayerAttack, 400);

	Destroy();
}

void CAstroSlug::Temp2()
{
	StartReaction(1.f, true, EReactionChannel::HitReaction);
}

void CAstroSlug::Temp3()
{
	StartReaction(1.f, false, EReactionChannel::InvincibleReaction);
}
