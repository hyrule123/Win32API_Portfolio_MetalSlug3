#include "Pistol.h"

//�浹ü
#include "../Collision/ColliderCircle.h"


#include "../../Include/Scene/Scene.h"

//�Ѿ� ����Ʈ ������
#include "Effect.h"
#include "../Scene/SceneResource.h"

CPistol::CPistol() :
	m_Distance(1000.f),
	m_isSet(false)
{
}

CPistol::CPistol(const CPistol& Obj) :
	CProjectile(Obj),
	m_Distance(Obj.m_Distance),
	m_isSet(Obj.m_isSet)
{
}

CPistol::~CPistol()
{
}

bool CPistol::Init(CGameObject* Obj)
{
	CGameObject::Init(Obj);

	m_Speed = 100.f;
	m_Distance = 0.f;

	SetSize(5.f, 5.f);
	SetPivot(0.5f, 0.5f);

	SetTexture("BulletPistol");

	//�浹ü ����
	CColliderCircle* Coll = AddCollider<CColliderCircle>("Bullet");
	if (m_MasterObject->GetName() == "Monster")
	{
		Coll->SetCollisionProfile(ECollisionChannel::MonsterAttack);
	}
	else if (m_MasterObject->GetName() == "Player")
	{
		Coll->SetCollisionProfile(ECollisionChannel::PlayerAttack);
	}
	Coll->SetRadius(m_Size.x * m_Pivot.x);
	//Coll->SetOffset(Vector2(10.f, 10.f));

	//ȣ�� �Լ� ����
	Coll->SetColliderBeginFunction(this, &CPistol::CollisionBegin);





	return true;
}

void CPistol::Update(float DeltaTime)
{
	CGameObject::Update(DeltaTime);

	m_Distance += m_Speed * DeltaTime;

	MoveDir(m_Dir);

}

void CPistol::PostUpdate(float DeltaTime)
{
	//�ı� ������ �����Ǹ� �Ѿ� ����
	//�Ÿ��� ����ų�, �Ѿ� �⺻������ ���� �ʾҴٸ� �׳� ����
	if (DestroyCheck() || !m_isSet)
	{
		SetActive(false);
	}

	CGameObject::PostUpdate(DeltaTime);
}

void CPistol::Render(HDC hDC, float DeltaTime)
{
	CGameObject::Render(hDC, DeltaTime);

	Vector2 RenderLeftTop = m_Pos - (m_Size * m_Pivot) - m_Scene->GetCamPos();

	Ellipse(hDC, (int)RenderLeftTop.x,
		(int)RenderLeftTop.y,
		(int)(RenderLeftTop.x + m_Size.x),
		(int)(RenderLeftTop.y + m_Size.y));
}

void CPistol::SetDamage(int Damage)
{
	m_Damage = Damage;
}

bool CPistol::DestroyCheck()
{
	if (m_Distance >= 400.f)
		return true;

	return false;
}

void CPistol::SetSpeedDir(float _x, Vector2 Dir)
{
	m_isSet = true;

	m_Speed = _x;
	m_Dir = Dir;
}

void CPistol::CollisionBegin(CCollider* Src, CCollider* Dest)
{
	CEffect* Effect = m_Scene->CreateObject<CEffect>("BulletSFX");

	Effect->AddAnimationInfo("BulletSFX", 0.1f);
	Effect->SetRenderLayer(ERenderLayer::Effect);

	Effect->SetPivot(0.5f, 0.5f);
	Effect->SetPos(Src->GetHitPoint());

	Dest->GetOwnerObj()->InflictDamage(m_Damage);

	SetActive(false);
}

