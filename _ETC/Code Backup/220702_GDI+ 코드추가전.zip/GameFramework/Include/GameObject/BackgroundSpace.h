#pragma once
#include "Background.h"

//����ũ��
class CBackgroundSpace :
    public CBackground
{
    friend class CScene;

protected:
    CBackgroundSpace();
    ~CBackgroundSpace();
public:
    bool Init(CGameObject* Obj = nullptr);
    void Start();


public:
    void Update(float DeltaTime);
    void Render(HDC hDC, float DeltaTime);
};


