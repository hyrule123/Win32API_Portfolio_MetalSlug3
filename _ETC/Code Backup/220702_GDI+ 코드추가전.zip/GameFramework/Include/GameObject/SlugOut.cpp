#include "SlugOut.h"

CSlugOut::CSlugOut()
{
	SetTypeID<CSlugOut>();
}

CSlugOut::CSlugOut(const CSlugOut& Obj):
	CEffect(Obj)
{
}

CSlugOut::~CSlugOut()
{
}

bool CSlugOut::Init(CGameObject* Obj)
{
	CEffect::Init(Obj);

	return true;
}

bool CSlugOut::LoadResource()
{
	LoadCSVPreset(TEXT("SlugOut.csv"));

	return true;
}

void CSlugOut::Update(float DeltaTime)
{
	CEffect::Update(DeltaTime);
}

void CSlugOut::PostUpdate(float DeltaTime)
{
}

void CSlugOut::Render(HDC hDC, float DeltaTime)
{
}
