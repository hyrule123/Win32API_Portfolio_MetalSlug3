#pragma once
#include "Player.h"

enum class EPartState
{
	Normal,
	NormalRifle,
	GunGet,
	GunDrop
};


enum class EDir
{
	Left,
	Right,
	Straight,
	Idle
};

enum class ELayerInfo
{
	BackSFX,
	LeftorOne,
	Right,
	PlayerWindow,
	GunFireSFX,
	SideGun1,
	SideGun2,
	FrontSFX
};

class CAstroSlug :
	public CPlayer
{
	friend class CScene;

protected:
	CAstroSlug();
	CAstroSlug(const CAstroSlug& Obj);
	virtual ~CAstroSlug();
public:
	virtual bool LoadResource();
	virtual bool Init(CGameObject* Obj = nullptr);


	bool m_isSeparate; //�и��� �ִϸ��̼����� �ƴ��� Ȯ��
	EPartState m_PartState[2]; //0=��, 1 = ��
	float m_SyncTimer;//�ð��� ����ؼ� ��/���� �ִϸ��̼��� ��ũ��Ŵ
	float m_SyncTimerMax;

	EWeapon m_CurrentWeapon;
	bool m_Busy;

	int m_FireBuffer; //���Է� ����
	float m_KnockBack;



private:
	void CheckParts();


	void MoveLeft();
	void MoveRight();

	void MoveUp();
	void MoveDown();

	void FireGunBuffer();
	void FireGun();
	void AttackEnd();

	void FireBomb();
	void FireNotify();

	void RifleGet();
	void RifleDrop();
	void ChangeRifleEnd();

	void PlayerTurnLeftToRightEnd();

	void Destroy();
	void DestroyEnd();

public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);

	void TempDamage();
	virtual int InflictDamage(int Damage);

private:
	void KnockBack();
	void RegisterAnimName();
	void RegisterInput();


	void Temp1();
	void Temp2();
	void Temp3();
};

