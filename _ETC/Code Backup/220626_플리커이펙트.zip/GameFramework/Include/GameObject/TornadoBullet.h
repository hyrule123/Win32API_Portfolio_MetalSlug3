#pragma once
#include "GameObject.h"

class CTornadoBullet :
    public CGameObject
{
    friend class CScene;

private:
    float m_Distance;
    bool m_isSet;

    //ȸ�� �ݰ�
    float m_RotatingRadius;

    //ȸ�� �ӵ�
    float m_RotatingAngleSpeed;

    //���� ǥ�õǴ� �Ѿ��� �߽���
    Vector2 m_RotatingBulletCenter;

    //���� ����
    float m_RotatingAngle;


protected:
    CTornadoBullet();
    CTornadoBullet(const CTornadoBullet& Obj);
    virtual ~CTornadoBullet();

public:
    bool Init(CGameObject* Obj = nullptr);
    void Update(float DeltaTime);
    void PostUpdate(float DeltaTime);
    void Render(HDC hDC, float DeltaTime);


    //â ���� �Ѿ�� �ı�(�ӽ�)
    bool DestroyCheck();

    void SetSpeedDir(float _x, Vector2 Dir)
    {
        m_isSet = true;

        m_Speed = _x;
        m_Dir = Dir;
    }
};

