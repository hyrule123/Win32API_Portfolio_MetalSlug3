#include "AstroSlug.h"

//�÷��̾� �ּ� ����
#include "../GameManager.h"

//SFX ȣ���
#include "../Scene/Scene.h"
#include "AstroSlugSFX.h"

#include "../Input.h"

#include "../Collision/ColliderBox.h"

CAstroSlug::CAstroSlug() :
	m_isSeparate(true),
	m_PartState{ EPartState::Normal },
	m_SyncTimer(),
	m_SyncTimerMax(),
	m_CurrentWeapon(EWeapon::Pistol),
	m_Busy(false),
	m_FireBuffer(),
	m_KnockBack()
{
	SetTypeID<CAstroSlug>();
	m_HP = 3;
}

CAstroSlug::CAstroSlug(const CAstroSlug& Obj):
	CPlayer(Obj),
	m_isSeparate(Obj.m_isSeparate),
	m_SyncTimer(),
	m_SyncTimerMax(),
	m_CurrentWeapon(EWeapon::Pistol),
	m_Busy(false),
	m_FireBuffer(),
	m_KnockBack()
{
	m_PartState[0] = Obj.m_PartState[0];
	m_PartState[1] = Obj.m_PartState[1];
}

CAstroSlug::~CAstroSlug()
{
}

bool CAstroSlug::LoadResource()
{
	CreateAnimation();
	if(!LoadCSVPreset(TEXT("AstroSlug.csv")))
		return false;
	RegisterAnimName();

	return true;
}

bool CAstroSlug::Init(CGameObject* Obj)
{
	CPlayer::Init();

	//Player�� �ּҸ� CGameManager�� ����Ѵ�.
	CGameManager::GetInst()->SetPlayer(this);


	RegisterInput();

	ChangeAnimation("PlayerRight");

	m_Animation->SetEndFunction<CAstroSlug>
		("LeftPart_Rifle_Get", this, &CAstroSlug::ChangeRifleEnd);
	m_Animation->SetEndFunction<CAstroSlug>
		("RightPart_Rifle_Get", this, &CAstroSlug::ChangeRifleEnd);
	m_Animation->SetEndFunction<CAstroSlug>
		("PlayerTurnLeftToRight", this, &CAstroSlug::PlayerTurnLeftToRightEnd);


	//��ġ ����
	SetPos(50.f, 50.f);
	SetSize(10.f, 20.f);
	SetDir(1.f, 0.f);
	SetPivot(0.5f, 1.f);
	SetScale(1.f);
	SetSpeed(100.f);


	//��ų ����
	m_SkillCoolTimeSet.resize((size_t)EWeapon::MAX);

	for (int i = 0; i < (int)EWeapon::MAX; ++i)
	{
		switch ((EWeapon)i)
		{
		case EWeapon::Pistol:
			m_SkillCoolTimeSet[(int)EWeapon::Pistol].CoolTime = 0.1f;
			break;
		case EWeapon::HMG:
			m_SkillCoolTimeSet[(int)EWeapon::HMG].CoolTime = 0.1f;
			break;
		case EWeapon::ShotGun:
			m_SkillCoolTimeSet[(int)EWeapon::ShotGun].CoolTime = 0.1f;
			break;
		case EWeapon::Rocket:
			m_SkillCoolTimeSet[(int)EWeapon::Rocket].CoolTime = 0.1f;
			break;
		case EWeapon::Laser:
			m_SkillCoolTimeSet[(int)EWeapon::Laser].CoolTime = 0.1f;
			break;
		case EWeapon::Bomb:
			m_SkillCoolTimeSet[(int)EWeapon::Bomb].CoolTime = 0.1f;
			break;
		default:
			break;
		}
	}
	

	//�浹ü
	//CColliderBox* Coll = AddCollider<CColliderBox>("AstroColl");
	//Coll->SetSize(36.f, 50.f);
	//Coll->SetPivot(0.5f, 1.f);
	//Coll->SetOffset(0.f, -5.f);

	return true;
}

void CAstroSlug::Update(float DeltaTime)
{
	CPlayer::Update(DeltaTime);

	if (fabs(m_KnockBack) >= FLT_EPSILON)
	{
		SetNoMove(true);

		MoveValue(Vector2(m_KnockBack, 0.f));

		m_KnockBack /= 2.f;

		if (m_KnockBack <= 0.5f)
			m_KnockBack = 0.f;
	}
	else
		SetNoMove(false);

	if (m_FireBuffer)
		FireGun();

	if (m_isSeparate)
		CheckParts();
	else
		m_Animation->StopCurrentAnim((int)ELayerInfo::Right);

	if (m_HP <= 0)
		Destroy();





}

void CAstroSlug::PostUpdate(float DeltaTime)
{
	CPlayer::PostUpdate(DeltaTime);


}

void CAstroSlug::Render(HDC hDC, float DeltaTime)
{
	CPlayer::Render(hDC, DeltaTime);
}

void CAstroSlug::TempDamage()
{
	InflictDamage(1);
}

int CAstroSlug::InflictDamage(int Damage)
{
	m_HP -= Damage;

	//��Ʈ����Ʈ�� ���� �ణ�� �˹� �� �� �ϳ� ���
	KnockBack();
	RifleDrop();
	
	StartFlicker(1.f, EReactionChannel::InvincibleReaction);
	
	
	

	return Damage;
}





void CAstroSlug::CheckParts()
{
	switch (m_PartState[0])
	{
	case EPartState::Normal:
		ChangeAnimContinue("LeftPart_Pistol");
		break;
	case EPartState::NormalRifle:
		ChangeAnimContinue("LeftPart_Rifle");
		break;
	case EPartState::GunGet:
		ChangeAnimation("LeftPart_Rifle_Get");
		break;
	case EPartState::GunDrop:
		SetPlayReverse("LeftPart_Rifle_Get", true, true);
		ChangeAnimation("LeftPart_Rifle_Get");
		break;
	default:
		break;
	}

	switch (m_PartState[1])
	{
	case EPartState::Normal:
		ChangeAnimation("RightPart_Pistol");
		break;
	case EPartState::NormalRifle:
		ChangeAnimation("RightPart_Rifle");
		break;
	case EPartState::GunGet:
		ChangeAnimation("RightPart_Rifle_Get");
		break;
	case EPartState::GunDrop:
		SetPlayReverse("RightPart_Rifle_Get", true, true);
		ChangeAnimation("RightPart_Rifle_Get");
		break;
	default:
		break;
	}

	if (m_PartState[0] <= EPartState::NormalRifle
		&& m_PartState[1] <= EPartState::NormalRifle)
	{
		m_Animation->SyncPlayTime(
			(int)ELayerInfo::LeftorOne,
			(int)ELayerInfo::Right);
	}
}

void CAstroSlug::MoveLeft()
{
	if (CheckCurrentAnimation("PlayerRight"))
	{
		SetPlayReverse("PlayerTurnLeftToRight", true, true);
		ChangeAnimation("PlayerTurnLeftToRight");
	}


	
	SetDir(-1.f, 0.f);
	MoveDir(m_Dir);

}

void CAstroSlug::MoveRight()
{
	if (CheckCurrentAnimation("PlayerLeft"))
	{
		ChangeAnimation("PlayerTurnLeftToRight");
	}
	

	SetDir(1.f, 0.f);
	MoveDir(m_Dir);
}




void CAstroSlug::MoveUp()
{
	SetDir(0.f, -1.f);
	MoveDir(m_Dir);
}

void CAstroSlug::MoveDown()
{
	SetDir(0.f, 1.f);
	MoveDir(m_Dir);
}

void CAstroSlug::FireGunBuffer()
{
	++m_FireBuffer;
}

void CAstroSlug::FireGun()
{
	//���Է� ���� �ʱ�ȭ
	m_FireBuffer = 0;

	//�ƽ�Ʈ�� �����׿��� �ǽ����� � ���⸦ ���� �߻��.
	if (!m_SkillCoolTimeSet[(int)EWeapon::Pistol].isCoolTime)
	{
		//��Ÿ���� �ƴϸ� ��Ÿ������ �ٲٴ� �޼ҵ带 ȣ���ϰ� ���� �ۼ�
		EnterSkillCoolTIme((int)EWeapon::Pistol);

		CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("GunFire", this);
		SFX->SetSFX("GunFireSFX");

	}

	switch (m_CurrentWeapon)
	{
	case EWeapon::HMG:
		break;
	case EWeapon::ShotGun:
		break;
	case EWeapon::Rocket:
		break;
	case EWeapon::Laser:
		break;
	default:
		break;
	}

}




void CAstroSlug::FireBomb()
{
}

void CAstroSlug::FireNotify()
{
}

void CAstroSlug::RifleGet()
{
	m_Busy = true;

	for (int i = 0; i <= 1; ++i)
	{
		if (m_PartState[i] != EPartState::NormalRifle)
			m_PartState[i] = EPartState::GunGet;
	}

}


void CAstroSlug::RifleDrop()
{
	//������->���� ������ �� ������
	if (m_PartState[1] == EPartState::NormalRifle)
	{
		m_Busy = true;
		m_PartState[1] = EPartState::GunDrop;
	}
	else if (m_PartState[0] == EPartState::NormalRifle)
	{
		m_Busy = true;
		m_PartState[0] = EPartState::GunDrop;
	}
}


void CAstroSlug::ChangeRifleEnd()
{
	m_Busy = false;
	
	for (int i = 0; i <= 1; ++i)
	{
		if (m_PartState[i] == EPartState::GunGet)
			m_PartState[i] = EPartState::NormalRifle;
		else if (m_PartState[i] == EPartState::GunDrop)
			m_PartState[i] = EPartState::Normal;
	}
}

void CAstroSlug::PlayerTurnLeftToRightEnd()
{
	CAnimationInfo* Info = m_Animation->FindAnimInfo("PlayerTurnLeftToRight");

	if (!Info)
		return;

	if(Info->GetReverse())
		ChangeAnimation("PlayerLeft");
	else
		ChangeAnimation("PlayerRight");
		
}

void CAstroSlug::Destroy()
{
	if (m_HP > -10)
	{
		m_Busy = true;
		SetSpeed(0.f);

		m_HP = -100;

		CAstroSlugSFX* SFX = m_Scene->CreateObject<CAstroSlugSFX>("OutMessage", this);
		SFX->SetSFX("SlugOut");
		SFX->SetEffect(EEffectType::Duration);
		SFX->SetDuration(3.f);
		SFX->SetOffset(1.f, -70.f);
	}
}

void CAstroSlug::DestroyEnd()
{
	m_Busy = false;
}

void CAstroSlug::AttackEnd()
{
}

void CAstroSlug::KnockBack()
{
	m_KnockBack = 5.f;
}

void CAstroSlug::RegisterAnimName()
{
	CAnimationInfo* Info = m_Animation->FindAnimInfo("LeftPart_Pistol");
	if (!Info)
		return;
	m_SyncTimerMax = Info->GetPlayTime();
}

void CAstroSlug::RegisterInput()
{
	//�Է� �ʱ�ȭ
	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveLeft",
		Input_Type::Push,
		this, &CAstroSlug::MoveLeft);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveRight",
		Input_Type::Push,
		this, &CAstroSlug::MoveRight);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveUp",
		Input_Type::Push,
		this, &CAstroSlug::MoveUp);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("MoveDown",
		Input_Type::Push,
		this, &CAstroSlug::MoveDown);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("GunFire",
		Input_Type::Down,
		this, &CAstroSlug::FireGunBuffer);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Bomb",
		Input_Type::Push,
		this, &CAstroSlug::FireBomb);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug1",
		Input_Type::Down,
		this, &CAstroSlug::RifleGet);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug2",
		Input_Type::Down,
		this, &CAstroSlug::Temp1);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug3",
		Input_Type::Down,
		this, &CAstroSlug::Temp2);

	CInput::GetInst()->AddBindFunction<CAstroSlug>("Debug4",
		Input_Type::Down,
		this, &CAstroSlug::Temp3);
}

void CAstroSlug::Temp1()
{
	StartFlicker(1.f, EReactionChannel::Normal);
}

void CAstroSlug::Temp2()
{
	StartFlicker(1.f, EReactionChannel::HitReaction);
}

void CAstroSlug::Temp3()
{
	StartFlicker(1.f, EReactionChannel::InvincibleReaction);
}
