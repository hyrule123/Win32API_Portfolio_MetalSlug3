#pragma once

#include "Projectile.h"

class CPistol :
    public CProjectile
{
    friend class CScene;

private:
    float m_Distance;
    bool m_isSet;

    int m_Damage;


protected:
    CPistol();
    CPistol(const CPistol& Obj);
    virtual ~CPistol();

public:
    bool Init(CGameObject* Obj = nullptr);
    void Update(float DeltaTime);
    void PostUpdate(float DeltaTime);
    void Render(HDC hDC, float DeltaTime);

    void SetDamage(int Damage);


    //â ���� �Ѿ�� �ı�(�ӽ�)
    bool DestroyCheck();

    void SetSpeedDir(float _x, Vector2 Dir);

    void CollisionBegin(class CCollider* Src, class CCollider* Dest);
};

