#pragma once
#include "Effect.h"

class CSlugOut :
    public CEffect
{
	friend class CScene;

protected:
	CSlugOut();
	CSlugOut(const CSlugOut& Obj);
	virtual ~CSlugOut();

public:
	virtual bool Init(CGameObject* Obj = nullptr);


protected:
	virtual bool LoadResource();

public:
	virtual void Update(float DeltaTime);
	virtual void PostUpdate(float DeltaTime);
	virtual void Render(HDC hDC, float DeltaTime);
};

