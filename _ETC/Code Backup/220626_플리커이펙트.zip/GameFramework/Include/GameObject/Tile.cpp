
#include "Tile.h"
#include "../Resource/Texture/Texture.h"
#include "../Scene/Scene.h"
#include "../Scene/Camera.h"
#include "../Scene/SceneManager.h"

//Ÿ�� �ε� �� �ʿ�.
#include "../Scene/SceneResource.h"

//����Ʈ ����� ��� �ȳ� ���ݵ� ǥ�����ش�.
#include "../GameManager.h"

CTile::CTile() :
	m_Option(ETileOption::Normal),
	m_Scene(nullptr),
	m_Owner(nullptr),
	m_IndexX(0),
	m_IndexY(0),
	m_Index(0),
	m_TileFrame(0),
	m_Render(true)
{
}

CTile::~CTile()
{
}

void CTile::Save(FILE* File)
{
	fwrite(&m_Option, sizeof(ETileOption), 1, File);
	fwrite(&m_Pos, sizeof(Vector2), 1, File);
	fwrite(&m_Size, sizeof(Vector2), 1, File);

	fwrite(&m_IndexX, sizeof(int), 1, File);
	fwrite(&m_IndexY, sizeof(int), 1, File);
	fwrite(&m_Index, sizeof(int), 1, File);
	fwrite(&m_TileFrame, sizeof(int), 1, File);

	fwrite(&m_StartFrame, sizeof(Vector2), 1, File);
	fwrite(&m_EndFrame, sizeof(Vector2), 1, File);
	fwrite(&m_Render, sizeof(bool), 1, File);
	fwrite(&m_SideCollision, sizeof(bool), 1, File);

	bool	Texture = false;

	if (m_Texture)
		Texture = true;

	fwrite(&Texture, sizeof(bool), 1, File);

	if (m_Texture)
		m_Texture->Save(File);
}

void CTile::Load(FILE* File)
{
	fread(&m_Option, sizeof(ETileOption), 1, File);
	fread(&m_Pos, sizeof(Vector2), 1, File);
	fread(&m_Size, sizeof(Vector2), 1, File);

	fread(&m_IndexX, sizeof(int), 1, File);
	fread(&m_IndexY, sizeof(int), 1, File);
	fread(&m_Index, sizeof(int), 1, File);
	fread(&m_TileFrame, sizeof(int), 1, File);

	fread(&m_StartFrame, sizeof(Vector2), 1, File);
	fread(&m_EndFrame, sizeof(Vector2), 1, File);
	fread(&m_Render, sizeof(bool), 1, File);
	fread(&m_SideCollision, sizeof(bool), 1, File);

	bool	Texture = false;

	fread(&Texture, sizeof(bool), 1, File);

	if (Texture)
		m_Texture = m_Scene->GetSceneResource()->LoadTexture(File);
}

ETileOption CTile::GetOption() const
{
	return m_Option;
}

const Vector2& CTile::GetPos() const
{
	return m_Pos;
}

const Vector2& CTile::GetSize() const
{
	return m_Size;
}

void CTile::SetTileInfo(const Vector2& Pos, const Vector2& Size,
	int IndexX, int IndexY, int Index, CTexture* Texture)
{
	m_Texture = Texture;
	m_Pos = Pos;
	m_Size = Size;
	m_IndexX = IndexX;
	m_IndexY = IndexY;
	m_Index = Index;
}

void CTile::SetFrame(const Vector2& Start, const Vector2& End)
{
	m_StartFrame = Start;
	m_EndFrame = End;
}

void CTile::SetTileOption(ETileOption Option)
{
	m_Option = Option;
}


void CTile::SetSideCollision(bool SideCollision)
{
	m_SideCollision = SideCollision;
}

bool CTile::GetSideCollision() const
{
	return m_SideCollision;
}

void CTile::SetTileRender(bool Render)
{
	m_Render = Render;
}


void CTile::Render(HDC hDC)
{

	if (m_Render)//�ش� Ÿ���� Render()�� true�� ��쿡�� ���.
	{

		Vector2	Pos;
		Vector2	CameraPos;
		Vector2	Resolution;



		if (m_Scene)
		{
			CameraPos = m_Scene->GetCamera()->GetPos();
			Resolution = m_Scene->GetCamera()->GetRes();
			Pos = m_Pos - m_Scene->GetCamera()->GetPos();
		}
		else
		{
			CScene* Scene = CSceneManager::GetInst()->GetScene();
			CameraPos = Scene->GetCamera()->GetPos();
			Pos = m_Pos - CameraPos;
			Resolution = Scene->GetCamera()->GetRes();
		}

		if (m_Texture)
		{
			if (m_Texture->GetColorKeyEnable())
			{
				if (m_Texture->GetTextureType() == ETextureType::Sprite)
				{
					TransparentBlt(hDC, (int)Pos.x, (int)Pos.y,
						(int)m_Size.x, (int)m_Size.y, m_Texture->GetDC(),
						(int)m_StartFrame.x, (int)m_StartFrame.y,
						(int)m_Size.x, (int)m_Size.y, m_Texture->GetColorKey());
				}

				else
				{
					TransparentBlt(hDC, (int)Pos.x, (int)Pos.y,
						(int)m_Size.x, (int)m_Size.y, m_Texture->GetDC(m_TileFrame),
						0, 0,
						(int)m_Size.x, (int)m_Size.y, m_Texture->GetColorKey(m_TileFrame));
				}
			}

			else
			{
				if (m_Texture->GetTextureType() == ETextureType::Sprite)
				{
					StretchBlt(hDC, (int)Pos.x, (int)Pos.y,
						(int)m_Size.x, (int)m_Size.y, m_Texture->GetDC(),
						(int)m_StartFrame.x, (int)m_StartFrame.y,
						(int)m_Size.x, (int)m_Size.y,
						SRCCOPY);
				}

				else
				{
					StretchBlt(hDC, (int)Pos.x, (int)Pos.y,
						(int)m_Size.x, (int)m_Size.y,
						m_Texture->GetDC(m_TileFrame),
						0, 0,
						(int)m_Size.x, (int)m_Size.y,
						SRCCOPY);
				}
			}
		}
	}

	//�̵� ���� ���ο� ���� �ٸ� �׵θ��� �׸���
	CGameManager* GameManager = CGameManager::GetInst();
	if (GameManager->GetEditMode())
	{
		Vector2	Pos;
		Vector2	CameraPos;
		Vector2	Resolution;

		if (m_Scene)
		{
			CameraPos = m_Scene->GetCamera()->GetPos();
			Resolution = m_Scene->GetCamera()->GetRes();
			Pos = m_Pos - m_Scene->GetCamera()->GetPos();
		}
		else
		{
			CScene* Scene = CSceneManager::GetInst()->GetScene();
			CameraPos = Scene->GetCamera()->GetPos();
			Pos = m_Pos - CameraPos;
			Resolution = Scene->GetCamera()->GetRes();
		}

		HBRUSH Brush;

		switch (m_Option)
		{
		case ETileOption::Normal:
			Brush = GameManager->GetBrush(EBrushType::Green);
			break;
		case ETileOption::Blocked:
			Brush = GameManager->GetBrush(EBrushType::Red);
			break;
		default:
			Brush = GameManager->GetBrush(EBrushType::Black);
			break;
		}
		
		RECT rc;
		rc.left = (long)Pos.x;
		rc.top = (long)Pos.y;
		rc.right = (long)(Pos.x + m_Size.x);
		rc.bottom = (long)(Pos.y + m_Size.y);

		FrameRect(hDC, &rc, Brush);
	}

}


