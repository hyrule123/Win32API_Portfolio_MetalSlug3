#include "MainScene.h"
#include "../Input.h"

//����ϴ� ���ӿ�����Ʈ
#include "../GameObject/AstroSlug.h"
#include "../GameObject/AstroSlugSFX.h"
#include "../GameObject/PlayerSpace.h"
#include "../GameObject/Monster.h"
#include "../GameObject/SolBullet.h"
#include "../GameObject/TornadoBullet.h"
#include "../GameObject/BackgroundSpace.h"


//Ÿ�ϸ�
#include "../GameObject/TileMap.h"

//����ϴ� UI
#include "../UI/WindowMonsterHP.h"

#include "SceneResource.h"

//Camera ó��
#include "Camera.h"

//�ʱ�ȭ �� �ػ� �޾ƿ��� �뵵
#include "../GameManager.h"


CMainScene::CMainScene()
{
}

CMainScene::~CMainScene()
{
}

bool CMainScene::Init()
{
	CScene::Init();


	GetCamera()->SetRes((float)ORIGINAL_GAME_RES_WIDTH, 
		(float)ORIGINAL_GAME_RES_HEIGHT);
	GetCamera()->SetWorldRes(ORIGINAL_GAME_RES_WIDTH, 
		ORIGINAL_GAME_RES_HEIGHT * 2.f);
	GetCamera()->SetTargetPivot(0.5f, 0.5f);

	CreateObject<CBackgroundSpace>("BackGround");



	//���� ���
	GetSceneResource()->LoadSound("SFX", "MainTheme", true, "MS3_Into_The_Cosmos.mp3");
	GetSceneResource()->SetMasterVolume(10);
	GetSceneResource()->SoundPlay("MainTheme");


	//�÷��̾� �̸� �ε�
	CreateOriginalObj<CPlayerSpace>("PlayerSpace");
	//CreateObject<CPlayerSpace>();
	CreateOriginalObj<CAstroSlugSFX>("AstroSlugSFX");

	CAstroSlug* Player = CreateObject<CAstroSlug>("AstroSlug");

	GetCamera()->SetTargetObj(Player);
	Player->SetPhysicsSimulate(false);
	Player->SetPos(100.f, 100.f);
	Player->SetSideWallCheck(false);



	////���� ����
	//CMonster* Monster = CreateObject<CMonster>("Monster");
	//Monster->SetPos(200.f, 200.f);
	
	////CreateWidgetWindow<CWindowMonsterHP>("MonsterHPBarWindow");



	//Ÿ�ϸ� ����
	//CTileMap* TileMap = CreateObject<CTileMap>("TileMap");
	//TileMap->LoadFileName("Save.tmp", MAP_PATH);


	return true;
}


